import Comparator.Statement

/-! Joseph Van Name's question about iterating roots of rank-into-rank embeddings.
Source: https://mathoverflow.net/questions/221720 . The quantifiers range over
genuine elementary self-embeddings of the membership structure of a rank. -/
open FirstOrder FirstOrder.Language LaverTables

namespace VanName

inductive UnaryTerm
  | var
  | ap (left right : UnaryTerm)
  | comp (left right : UnaryTerm)

noncomputable def UnaryTerm.eval {lam : Ordinal.{0}}
    (t : UnaryTerm) (j : VSet lam → VSet lam) : VSet lam → VSet lam :=
  match t with
  | .var => j
  | .ap a b => app (a.eval j) (b.eval j)
  | .comp a b => a.eval j ∘ b.eval j

def RootChain (lam : Ordinal.{0}) (t : ℕ → UnaryTerm) : Prop :=
  ∃ J : ℕ → VSet lam ↪ₑ[setLang] VSet lam,
    (∀ n, ∃ x, J n x ≠ x) ∧
    ∀ n, (J n : VSet lam → VSet lam) =
      app ((t n).eval (J (n+1))) (J (n+1))

/-- Relative possibility at a cardinal means that a nontrivial self-embedding
already exists at a cardinal height. The first clause asks for equivalence of
existence, across all cardinal heights. The other two clauses ask for
nonexistence at every cardinal height, including the single-term variant. -/
def Classification : Prop :=
  ((∃ (c : Cardinal.{0}) (j : VSet c.ord ↪ₑ[setLang] VSet c.ord), ∃ x, j x ≠ x) ↔
    ∃ (c : Cardinal.{0}) (t : ℕ → UnaryTerm), RootChain c.ord t) ∧
  (∀ (c : Cardinal.{0}) (t : ℕ → UnaryTerm), (Set.range t).Finite → ¬ RootChain c.ord t) ∧
  (∀ (c : Cardinal.{0}) (t : UnaryTerm), ¬ RootChain c.ord (fun _ => t))

end VanName

import Mathlib.Data.Finset.Lattice.Fold
import Mathlib.Order.WellFounded
import Mathlib.Tactic.NthRewrite

/-! The finite-term obstruction in MathOverflow 221720. The algebra of nonidentity
rank-into-rank embeddings is represented by its action on ordinals. Its elementary
embedding and critical-point laws are explicit hypotheses of this theorem. -/
namespace FiniteRoots

inductive Term
  | var | app (a b : Term) | comp (a b : Term)
  deriving DecidableEq

/-- The shift eventually induced on the generator's critical sequence. -/
def Term.shift : Term → ℕ
  | .var => 1
  | .app _ b => b.shift
  | .comp a b => b.shift + a.shift

def Term.threshold : Term → ℕ
  | .var => 0
  | .app a b => max a.threshold b.threshold + a.shift
  | .comp a b => max a.threshold b.threshold

lemma Term.shift_pos (T : Term) : 0 < T.shift := by
  induction T with
  | var => decide
  | app a b ia ib => exact ib
  | comp a b ia ib => simp only [Term.shift]; omega

structure Action (E O : Type*) [LinearOrder O] where
  act : E → O → O
  app : E → E → E
  comp : E → E → E
  crit : E → O
  inc : ∀ a, StrictMono (act a)
  extensive : ∀ a x, x ≤ act a x
  moves : ∀ a, crit a < act a (crit a)
  compose : ∀ a b x, act (comp a b) x = act a (act b x)
  apply_intertwines : ∀ a b x, act (app a b) (act a x) = act a (act b x)
  critical_apply : ∀ a b, crit (app a b) = act a (crit b)

variable {E O : Type*} [LinearOrder O] (M : Action E O)

def eval : Term → E → E
  | .var, j => j
  | .app a b, j => M.app (eval a j) (eval b j)
  | .comp a b, j => M.comp (eval a j) (eval b j)

def iter (f : O → O) : ℕ → O → O
  | 0, x => x
  | n+1, x => f (iter f n x)

lemma intertwine_iter (a b : E) (r : ℕ) (x : O) :
    iter (M.act (M.app a b)) r (M.act a x) = M.act a (iter (M.act b) r x) := by
  induction r with
  | zero => rfl
  | succ r ih => simp only [iter, ih, M.apply_intertwines]

def point (j : E) (k : ℕ) := iter (M.act j) k (M.crit j)

lemma point_strict (j : E) (k : ℕ) : point M j k < point M j (k+1) := by
  induction k with
  | zero => exact M.moves j
  | succ k ih => exact M.inc j ih

/-- Every term acts as an exact positive translation sufficiently far along the
critical sequence. In the application case, use the preimage under the left
factor to put the ordinal into the range of the intertwining identity. -/
lemma eventual_shift (T : Term) (j : E) (k : ℕ) (hk : T.threshold ≤ k) :
    M.act (eval M T j) (point M j k) = point M j (k+T.shift) := by
  induction T generalizing k with
  | var => rfl
  | comp a b ia ib =>
    simp only [Term.threshold] at hk
    rw [eval, M.compose, ib _ (by omega), ia _ (by omega), Term.shift, Nat.add_assoc]
  | app a b ia ib =>
    simp only [Term.threshold] at hk
    let l := k - a.shift
    have lplus : l + a.shift = k := by dsimp [l]; omega
    have ha : a.threshold ≤ l := by dsimp [l]; omega
    have hb : b.threshold ≤ l := by dsimp [l]; omega
    have hat : a.threshold ≤ l+b.shift := by omega
    calc
      M.act (eval M (.app a b) j) (point M j k) =
          M.act (M.app (eval M a j) (eval M b j)) (M.act (eval M a j) (point M j l)) := by
            rw [ia _ ha, lplus]; rfl
      _ = M.act (eval M a j) (M.act (eval M b j) (point M j l)) := M.apply_intertwines _ _ _
      _ = point M j (l+b.shift+a.shift) := by rw [ib _ hb, ia _ hat]
      _ = point M j (k+(.app a b : Term).shift) := by
        congr 1; simp only [Term.shift]; omega

lemma term_moves (T : Term) (j : E) (k : ℕ) (hk : T.threshold ≤ k) :
    point M j k < M.act (eval M T j) (point M j k) := by
  rw [eventual_shift M T j k hk]
  exact (strictMono_nat_of_lt_succ (point_strict M j)) (Nat.lt_add_of_pos_right T.shift_pos)

lemma point_app (a j : E) (k : ℕ) : point M (M.app a j) k = M.act a (point M j k) := by
  simp only [point, M.critical_apply, intertwine_iter]

/-- An infinite root chain using a finite menu of unary terms cannot exist. -/
theorem no_finite_term_chain [WellFoundedLT O] (S : Finset Term)
    (t : ℕ → Term) (covered : ∀ n, t n ∈ S) (j : ℕ → E) :
    ¬ (∀ n, j n = M.app (eval M (t n) (j (n+1))) (j (n+1))) := by
  intro root
  let k := S.sup Term.threshold
  have desc (n : ℕ) : point M (j (n+1)) k < point M (j n) k := by
    conv_rhs => rw [root n]
    rw [point_app]
    exact term_moves M _ _ _ (Finset.le_sup (covered n))
  exact (wellFounded_iff_isEmpty_descending_chain.mp wellFounded_lt).elim
    ⟨fun n => point M (j n) k, desc⟩

end FiniteRoots
#print axioms FiniteRoots.no_finite_term_chain

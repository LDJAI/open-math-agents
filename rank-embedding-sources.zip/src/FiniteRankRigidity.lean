import LaverTables.Foundations.Elementarity
import Mathlib.SetTheory.Cardinal.Aleph
import Mathlib.Data.Fintype.Card

open FirstOrder FirstOrder.Language LaverTables
open scoped Cardinal

namespace VanName

theorem surjective_rank_embedding_fixed {lam : Ordinal.{0}}
    (j : VSet lam ↪ₑ[setLang] VSet lam) (hs : Function.Surjective j) : ∀ x, j x = x := by
  have H (v : ZFSet.{0}) : ∀ hv : v.rank < lam,
      (j (⟨v,hv⟩ : VSet lam)).val = v := by
    induction v using ZFSet.inductionOn with
    | h v ih =>
      intro hv
      let x : VSet lam := ⟨v,hv⟩
      apply ZFSet.ext
      intro y
      constructor
      · intro hy
        have hylt : y.rank < lam := (ZFSet.rank_lt_of_mem hy).trans (j x).2
        let yy : VSet lam := ⟨y,hylt⟩
        obtain ⟨u,hu⟩ := hs yy
        have hum : u.val ∈ v := (ElementaryEmbedding.mem_iff j u x).mp (by simpa only [hu] using hy)
        have he := ih u.val hum u.2
        have hyu : y = u.val := (congrArg Subtype.val hu).symm.trans he
        exact hyu ▸ hum
      · intro hy
        let yy : VSet lam := ⟨y,(ZFSet.rank_lt_of_mem hy).trans hv⟩
        have he : (j yy).val = y := ih y hy yy.2
        have hm := (ElementaryEmbedding.mem_iff j yy x).mpr hy
        rwa [he] at hm
  intro x
  exact VSet.ext (H x.1 x.2)

theorem finite_natural_rank (n : ℕ) : Finite (VSet (n : Ordinal.{0})) := by
  let e : VSet (n : Ordinal.{0}) ≃ (ZFSet.vonNeumann (n : Ordinal.{0})).toSet :=
    { toFun := fun x => ⟨x.1, vSet_val_mem_vonNeumann x⟩
      invFun := fun x => ⟨x.1, rank_lt_of_mem_vonNeumann x.2⟩
      left_inv := fun _ => rfl
      right_inv := fun _ => rfl }
  have hc : Cardinal.mk ((ZFSet.vonNeumann (n : Ordinal.{0})).toSet) =
      Cardinal.lift.{1} (ZFSet.vonNeumann (n : Ordinal.{0})).card := ZFSet.cardinalMk_coe_sort
  apply Cardinal.mk_lt_aleph0_iff.mp
  rw [Cardinal.mk_congr e, hc, ZFSet.card_vonNeumann, Cardinal.preBeth_nat]
  simp

theorem limit_of_nontrivial_cardinal_embedding (c : Cardinal.{0})
    (j : VSet c.ord ↪ₑ[setLang] VSet c.ord) (hn : ∃ x, j x ≠ x) : Order.IsSuccLimit c.ord := by
  apply Cardinal.isSuccLimit_ord
  by_contra! h
  obtain ⟨n, rfl⟩ := Cardinal.lt_aleph0.mp h
  have hfin : Finite (VSet (n : Cardinal.{0}).ord) := by simpa using finite_natural_rank n
  let := hfin
  obtain ⟨x,hx⟩ := hn
  exact hx (surjective_rank_embedding_fixed j (Finite.surjective_of_injective j.injective) x)

end VanName
#print axioms VanName.limit_of_nontrivial_cardinal_embedding

import GraphCongruence
import LaverGraphRead
import LaverTables.Algebra.Application

open FirstOrder FirstOrder.Language LaverTables Order
namespace VanName
variable {lam : Ordinal.{0}}

open scoped Classical in
noncomputable def totalApp (hl : IsSuccLimit lam) {δ : ℕ → Ordinal.{0}}
    (hlt : ∀ n, δ n < lam) (hcof : ∀ θ < lam, ∃ n, θ ≤ δ n)
    (a b : VSet lam ↪ₑ[setLang] VSet lam) : VSet lam ↪ₑ[setLang] VSet lam :=
  if ha : ∃ x, a x ≠ x then appEmbedding hl a b ha hlt hcof else b

theorem totalApp_coe_of_nontrivial (hl : IsSuccLimit lam) {δ : ℕ → Ordinal.{0}}
    (hlt : ∀ n, δ n < lam) (hcof : ∀ θ < lam, ∃ n, θ ≤ δ n)
    (a b : VSet lam ↪ₑ[setLang] VSet lam) (ha : ∃ x, a x ≠ x) :
    (totalApp hl hlt hcof a b : VSet lam → VSet lam) = app ⇑a ⇑b := by
  rw [totalApp, dif_pos ha]; rfl

theorem totalApp_coe (hl : IsSuccLimit lam) {δ : ℕ → Ordinal.{0}}
    (hlt : ∀ n, δ n < lam) (hcof : ∀ θ < lam, ∃ n, θ ≤ δ n)
    (a b : VSet lam ↪ₑ[setLang] VSet lam) :
    (totalApp hl hlt hcof a b : VSet lam → VSet lam) = app ⇑a ⇑b := by
  classical
  by_cases ha : ∃ x, a x ≠ x
  · exact totalApp_coe_of_nontrivial hl hlt hcof a b ha
  · rw [totalApp, dif_neg ha]
    have he : (⇑a : VSet lam → VSet lam) = id := funext fun x => by
      by_contra h; exact ha ⟨x,h⟩
    rw [he]
    exact (app_id hl b).symm

/-- On every bounded domain Vγ, the whole output graph of an application
already occurs in one image of a bounded input graph. -/
theorem uniform_output_graph (hl : IsSuccLimit lam) {δ : ℕ → Ordinal.{0}}
    (hlt : ∀ n, δ n < lam) (hcof : ∀ θ < lam, ∃ n, θ ≤ δ n)
    (a b : VSet lam ↪ₑ[setLang] VSet lam) {γ : Ordinal.{0}} (hγ : γ < lam) :
    ∃ θ, ∃ hθ : θ < lam, ∀ x : VSet lam, x.val.rank < γ →
      ZFSet.pair x.val ((totalApp hl hlt hcof a b) x).val ∈
        (a ⟨graphInter ⇑b θ,(rank_graphInter_le ⇑b θ).trans_lt hθ⟩).val := by
  classical
  let c := totalApp hl hlt hcof a b
  let β := max γ (mapOrd ⇑c γ)
  have hβ : β < lam := max_lt hγ (LaverTables.ElementaryEmbedding.mapOrd_lt c hγ)
  let θ := succ (succ β)
  have hθ : θ < lam := hl.succ_lt (hl.succ_lt hβ)
  refine ⟨θ,hθ,fun x hx => ?_⟩
  have hr : (c x).val.rank < β := by
    rw [LaverTables.ElementaryEmbedding.rank_apply c hl]
    exact (LaverTables.ElementaryEmbedding.mapOrd_lt_mapOrd c hx hγ).trans_le (le_max_right _ _)
  have hpair : (ZFSet.pair x.val (c x).val).rank < θ := by
    rw [rank_pair']
    exact succ_lt_succ (succ_lt_succ (max_lt (hx.trans_le (le_max_left _ _)) hr))
  let p : VSet lam := ⟨ZFSet.pair x.val (c x).val,hpair.trans hθ⟩
  by_cases ha : ∃ z, a z ≠ z
  · have hω := LaverTables.ElementaryEmbedding.omega0_lt_of_nontrivial a hl ha
    have hp : p ∈ classApply ⇑a (graphClass hl ⇑b) := by
      apply (pair_mem_classApply_graphClass hl ⇑a ⇑b x (c x)).2
      have he : c x = app ⇑a ⇑b x := congrFun (totalApp_coe_of_nontrivial hl hlt hcof a b ha) x
      rw [he]
      exact LaverTables.ElementaryEmbedding.app_mem_stage a hl hω hlt hcof ⇑b x
    have hs := (LaverTables.ElementaryEmbedding.classApply_inter_stage a hl (graphClass hl ⇑b) hθ p).1
      ⟨hp,hpair.trans_le (LaverTables.ElementaryEmbedding.le_mapOrd a hθ)⟩
    rwa [classInterElem_graphClass] at hs
  · have aid : ∀ z,a z = z := fun z => Classical.byContradiction (fun hh => ha ⟨z,hh⟩)
    let g : VSet lam := ⟨graphInter ⇑b θ,(rank_graphInter_le ⇑b θ).trans_lt hθ⟩
    change ZFSet.pair x.val (c x).val ∈ (a g).val
    rw [aid g]
    have cb : c = b := by dsimp [c]; rw [totalApp, dif_neg ha]
    change ZFSet.pair x.val (c x).val ∈ graphInter ⇑b θ
    apply ZFSet.mem_sep.mpr
    exact ⟨ZFSet.mem_vonNeumann.mpr hpair,x,by rw [cb]⟩

/-- Joint continuity of the actual application operation in the topology of
agreement on rank segments, at all pairs including the identity. -/
theorem totalApp_continuous_rank (hl : IsSuccLimit lam) {δ : ℕ → Ordinal.{0}}
    (hlt : ∀ n, δ n < lam) (hcof : ∀ θ < lam, ∃ n, θ ≤ δ n)
    (a b : VSet lam ↪ₑ[setLang] VSet lam) {γ : Ordinal.{0}} (hγ : γ < lam) :
    ∃ η < lam, ∀ a' b' : VSet lam ↪ₑ[setLang] VSet lam,
      RankAgree ⇑a ⇑a' η → RankAgree ⇑b ⇑b' η →
      RankAgree ⇑(totalApp hl hlt hcof a b) ⇑(totalApp hl hlt hcof a' b') γ := by
  obtain ⟨θ,hθ,hs⟩ := uniform_output_graph hl hlt hcof a b hγ
  refine ⟨succ θ,hl.succ_lt hθ,fun a' b' ha hb x hx => ?_⟩
  have hg : graphInter ⇑b θ = graphInter ⇑b' θ :=
    graphInter_congr (fun z hz => hb z (hz.trans (lt_succ θ)))
  let g : VSet lam := ⟨graphInter ⇑b θ,(rank_graphInter_le ⇑b θ).trans_lt hθ⟩
  have hgg : g = (⟨graphInter ⇑b' θ,(rank_graphInter_le ⇑b' θ).trans_lt hθ⟩ : VSet lam) :=
    VSet.ext hg
  have ha' := ha g ((rank_graphInter_le ⇑b θ).trans_lt (lt_succ θ))
  have hp := hs x hx
  change _ ∈ (a g).val at hp
  rw [ha',hgg] at hp
  rw [show totalApp hl hlt hcof a' b' x = app ⇑a' ⇑b' x from
    congrFun (totalApp_coe hl hlt hcof a' b') x]
  exact (app_value_of_graph_mem hl hlt hcof a' ⇑b' hθ hp).symm

end VanName

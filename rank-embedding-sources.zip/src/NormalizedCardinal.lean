import LaverTables.Algebra.CardBridge
import LaverTables.Algebra.WitnessRestriction

namespace VanName
open LaverTables FirstOrder
open scoped FirstOrder

/-- A cofinal supremum of initial ordinals is initial, applied to the
critical sequence of the chosen rank-into-rank embedding. -/
theorem cardinal_height {lam : Ordinal.{0}} {j : VSet lam ↪ₑ[setLang] VSet lam}
    (hl : Order.IsSuccLimit lam) (hj : ∃ z, j z ≠ z) (hg : GoodWitness ⇑j) :
    lam.card.ord = lam := by
  refine le_antisymm (Cardinal.ord_card_le _) ?_
  calc
    lam = deltaOf ⇑j := hg.symm
    _ ≤ lam.card.ord := by
      apply ciSup_le
      intro n
      calc
        kappaSeq ⇑j n = (kappaSeq ⇑j n).card.ord := (hg.card_ord_kappaSeq hl hj n).symm
        _ ≤ lam.card.ord := Cardinal.ord_le_ord.mpr
          (Ordinal.card_le_card (LaverTables.ElementaryEmbedding.kappaSeq_lt j hl hj n).le)

/-- From the customary ordinal-height I3 axiom, extract an actual cardinal
height and a cofinal critical sequence at that height. -/
theorem exists_cardinal_good_witness (hi : I3) :
    ∃ c : Cardinal.{0}, Order.IsSuccLimit c.ord ∧
      ∃ j : VSet c.ord ↪ₑ[setLang] VSet c.ord, (∃ z, j z ≠ z) ∧ GoodWitness ⇑j := by
  have hgood : ∃ lam : Ordinal.{0}, Order.IsSuccLimit lam ∧
      ∃ j : VSet lam ↪ₑ[setLang] VSet lam, (∃ z, j z ≠ z) ∧ GoodWitness ⇑j := by
    obtain ⟨lam,hl,j,hj⟩ := hi
    rcases (deltaOf_le j hl hj).lt_or_eq with hδ | hg
    · exact ⟨_,isSuccLimit_deltaOf j hl hj,restrictEmbedding j hl hj hδ,
        restrict_nontrivial j hl hj hδ,goodWitness_restrict j hl hj hδ⟩
    · exact ⟨_,hl,j,hj,hg⟩
  obtain ⟨lam,hl,j,hj,hg⟩ := hgood
  refine ⟨lam.card, ?_⟩
  rw [cardinal_height hl hj hg]
  exact ⟨hl,j,hj,hg⟩

#print axioms VanName.exists_cardinal_good_witness
end VanName

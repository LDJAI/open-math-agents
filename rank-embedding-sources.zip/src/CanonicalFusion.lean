import CanonicalSquares
import RankwiseFusion
import RankIntoRankStatement
import LaverTables.Algebra.CardBridge

namespace VanName
open FirstOrder Filter LaverTables
open scoped FirstOrder

def squareTerm : ℕ → UnaryTerm
  | 0 => .var
  | n+1 => .ap (squareTerm n) (squareTerm n)

abbrev BelowAgreement {lam : Ordinal.{0}} (δ : Ordinal.{0}) (e f : EndRank lam) : Prop :=
  ∀ x : VSet lam, x.val.rank < δ → e x = f x

private theorem eval_squareTerm {lam : Ordinal.{0}} (hl : Order.IsSuccLimit lam)
    (j : EndRank lam) (hj : ∃ x, j x ≠ x) (hg : GoodWitness ⇑j)
    (A : EndRank lam → EndRank lam → EndRank lam)
    (hA : ∀ a b : EndRank lam, (∃ z, a z ≠ z) → ⇑(A a b) = app ⇑a ⇑b)
    (e : EndRank lam) (he : ∃ x, e x ≠ x) (m : ℕ) :
    (squareTerm m).eval ⇑e = ⇑(bsq A m e) := by
  induction m with
  | zero => rfl
  | succ m ih =>
    change app ((squareTerm m).eval ⇑e) ((squareTerm m).eval ⇑e) =
      ⇑(A (bsq A m e) (bsq A m e))
    rw [ih,hA _ _ (square_nt hl j hj hg A hA e he m)]

theorem roots_of_good {lam : Ordinal.{0}} (hl : Order.IsSuccLimit lam)
    (j : EndRank lam) (hj : ∃ x, j x ≠ x) (hg : GoodWitness ⇑j)
    (A : EndRank lam → EndRank lam → EndRank lam)
    (hA : ∀ a b : EndRank lam, (∃ z, a z ≠ z) → ⇑(A a b) = app ⇑a ⇑b)
    (hc : ∀ (a b : EndRank lam) δ, δ < lam → ∃ θ < lam,
      ∀ (a' b' : EndRank lam), BelowAgreement θ a a' → BelowAgreement θ b b' →
        BelowAgreement δ (A a b) (A a' b')) : ∃ t, RootChain lam t := by
  obtain ⟨v,hv⟩ := hj
  have hj : ∃ x, j x ≠ x := ⟨v,hv⟩
  let κ := kappaSeq ⇑j
  have hκmon : Monotone κ := (LaverTables.ElementaryEmbedding.kappaSeq_strictMono j hl hj).monotone
  have hκlt := LaverTables.ElementaryEmbedding.kappaSeq_lt j hl hj
  have hκ (δ : Ordinal.{0}) (hδ : δ < lam) : ∃ k, δ < κ k := by
    obtain ⟨k,hk⟩ := hg.kappaSeq_cof (Order.succ δ) (hl.succ_lt hδ)
    exact ⟨k,(Order.lt_succ _).trans_le hk⟩
  obtain ⟨k,hk⟩ := hκ v.val.rank v.property
  let U (i : ℕ) : Set (VSet lam) := {x | x.val.rank < κ (k+i)}
  have hU : Monotone U := by
    intro n m h x hx
    exact hx.trans_le (hκmon (by omega : k+n ≤ k+m))
  have cover (x : VSet lam) : ∃ i, x ∈ U i := by
    obtain ⟨i,hi⟩ := hκ x.val.rank x.property
    exact ⟨i,hi.trans_le (hκmon (by omega : i ≤ k+i))⟩
  have appCont (F G : EndRank lam → EndRank lam)
      (hF : Restrictions.ContinuousOnRanks U F) (hG : Restrictions.ContinuousOnRanks U G) :
      Restrictions.ContinuousOnRanks U (fun e => A (F e) (G e)) := by
    intro e r
    obtain ⟨θ,hθ,ht⟩ := hc (F e) (G e) _ (hκlt (k+r))
    obtain ⟨i,hi⟩ := hκ θ hθ
    have hθi := hi.trans_le (hκmon (by omega : i ≤ k+i))
    obtain ⟨s,hs⟩ := hF e i
    obtain ⟨t,ht'⟩ := hG e i
    refine ⟨max s t, ?_⟩
    intro e' he
    apply ht
    · intro y hy
      exact hs e' (fun z hz => he z (hU (le_max_left _ _) hz)) y (hy.trans hθi)
    · intro y hy
      exact ht' e' (fun z hz => he z (hU (le_max_right _ _) hz)) y (hy.trans hθi)
  have idCont : Restrictions.ContinuousOnRanks U (id : EndRank lam → EndRank lam) :=
    fun e r => ⟨r,fun b h => h⟩
  have sqCont (n : ℕ) : Restrictions.ContinuousOnRanks U (bsq A n) := by
    induction n with
    | zero => exact idCont
    | succ n ih => exact appCont _ _ ih ih
  let S := fun m (e : EndRank lam) => A (bsq A m e) e
  have hS (m : ℕ) : Restrictions.ContinuousOnRanks U (S m) := appCont _ id (sqCont m) idCont
  have hSeed (r : ℕ) : ∀ᶠ m in atTop, Restrictions.Agree U r j (S m j) := by
    obtain ⟨N,hN⟩ := root_maps_approach hl j hj hg A hA _ (hκlt (k+r))
    exact eventually_atTop.2 ⟨N,fun m hm x hx => (hN m hm x hx).symm⟩
  obtain ⟨m,z,_,hz,hstep⟩ := Restrictions.exists_backward_orbit U S hS j hSeed hU cover
  have hn (i : ℕ) : ∃ x, z i x ≠ x := by
    refine ⟨v,fun he => hv ?_⟩
    exact (hz i v (hk.trans_le (hκmon (by omega : k ≤ k+i)))).symm.trans he
  refine ⟨fun i => squareTerm (m i),z,hn,fun i => ?_⟩
  rw [eval_squareTerm hl j hj hg A hA _ (hn (i+1))]
  change ⇑(z i) = app ⇑(bsq A (m i) (z (i+1))) ⇑(z (i+1))
  exact (congrArg (fun e : EndRank lam => (e : VSet lam → VSet lam)) (hstep i)).trans
    (hA _ _ (square_nt hl j hj hg A hA _ (hn (i+1)) (m i)))

end VanName

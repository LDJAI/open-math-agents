import OMAStatements.S_mo_221720
import RankIntoRankStatement

open FirstOrder FirstOrder.Language
namespace VanName.SiteBridge
open OMA.S_mo_221720

def toLaver : setLang →ᴸ LaverTables.setLang where
  onFunction := fun {_} f => nomatch f
  onRelation := fun {_} r => by cases r; exact .mem

def fromLaver : LaverTables.setLang →ᴸ setLang where
  onFunction := fun {_} f => nomatch f
  onRelation := fun {_} r => by cases r; exact .mem

local instance instanceLaver (lam : Ordinal.{0}) : LaverTables.setLang.Structure (VSet lam) :=
  LaverTables.vSetStructure lam

local instance toLaverExpansion (lam : Ordinal.{0}) : toLaver.IsExpansionOn (VSet lam) where
  map_onFunction := fun {_} f => nomatch f
  map_onRelation R := by cases R; intro v; rfl

local instance fromLaverExpansion (lam : Ordinal.{0}) : fromLaver.IsExpansionOn (VSet lam) where
  map_onFunction := fun {_} f => nomatch f
  map_onRelation R := by cases R; intro v; rfl

def exportE {lam : Ordinal.{0}} (j : LaverTables.VSet lam ↪ₑ[LaverTables.setLang] LaverTables.VSet lam) :
    VSet lam ↪ₑ[setLang] VSet lam where
  toFun := j
  map_formula' := by
    intro n φ v
    have h := j.map_formula (toLaver.onFormula φ) v
    exact (toLaver.realize_onFormula (M := VSet lam) φ).symm.trans
      (h.trans <| toLaver.realize_onFormula (M := VSet lam) φ)

def importE {lam : Ordinal.{0}} (j : VSet lam ↪ₑ[setLang] VSet lam) :
    LaverTables.VSet lam ↪ₑ[LaverTables.setLang] LaverTables.VSet lam where
  toFun := j
  map_formula' := by
    intro n φ v
    have h := j.map_formula (fromLaver.onFormula φ) v
    exact (fromLaver.realize_onFormula (M := VSet lam) φ).symm.trans
      (h.trans <| fromLaver.realize_onFormula (M := VSet lam) φ)

def exportT : VanName.UnaryTerm → OMA.S_mo_221720.UnaryTerm
  | .var => .var
  | .comp a b => .comp (exportT a) (exportT b)
  | .ap a b => .ap (exportT a) (exportT b)

def importT : OMA.S_mo_221720.UnaryTerm → VanName.UnaryTerm
  | .var => .var
  | .comp a b => .comp (importT a) (importT b)
  | .ap a b => .ap (importT a) (importT b)

theorem sameApp {lam : Ordinal.{0}} (a b : VSet lam → VSet lam) :
    app a b = LaverTables.app a b := rfl

theorem exportT_eval {lam : Ordinal.{0}} (f : VSet lam → VSet lam) (t : VanName.UnaryTerm) :
    (exportT t).eval f = t.eval f := by
  induction t <;> simp_all [exportT, VanName.UnaryTerm.eval, OMA.S_mo_221720.UnaryTerm.eval] <;> rfl

theorem importT_eval {lam : Ordinal.{0}} (f : VSet lam → VSet lam) (t : OMA.S_mo_221720.UnaryTerm) :
    (importT t).eval f = t.eval f := by
  induction t <;> simp_all [importT, VanName.UnaryTerm.eval, OMA.S_mo_221720.UnaryTerm.eval] <;> rfl

theorem exportChain {lam : Ordinal.{0}} {t : ℕ → VanName.UnaryTerm} (h : VanName.RootChain lam t) :
    OMA.S_mo_221720.RootChain lam (exportT ∘ t) := by
  obtain ⟨J,hn,he⟩ := h
  refine ⟨fun n => exportE (J n),hn,fun n => ?_⟩
  change ⇑(J n) = app ((exportT (t n)).eval ⇑(J (n+1))) ⇑(J (n+1))
  exact (he n).trans (congrArg (fun z : VSet lam → VSet lam => LaverTables.app z (J (n+1)))
    (exportT_eval (lam := lam) (J (n+1)) (t n)).symm)

theorem importChain {lam : Ordinal.{0}} {t : ℕ → OMA.S_mo_221720.UnaryTerm} (h : OMA.S_mo_221720.RootChain lam t) :
    VanName.RootChain lam (importT ∘ t) := by
  obtain ⟨J,hn,he⟩ := h
  refine ⟨fun n => importE (J n),hn,fun n => ?_⟩
  change ⇑(J n) = LaverTables.app ((importT (t n)).eval ⇑(J (n+1))) ⇑(J (n+1))
  rw [importT_eval, ← sameApp]
  exact he n

theorem toSite (h : VanName.Classification) : type_of% @OMA.S_mo_221720.main := by
  obtain ⟨hp,hf,hs⟩ := h
  refine ⟨⟨?_,?_⟩,?_,?_⟩
  · rintro ⟨c,j,x,hx⟩
    obtain ⟨d,t,ht⟩ := hp.mp ⟨c,importE j,x,hx⟩
    exact ⟨d,exportT ∘ t,exportChain ht⟩
  · rintro ⟨c,t,ht⟩
    obtain ⟨d,j,x,hx⟩ := hp.mpr ⟨c,importT ∘ t,importChain ht⟩
    exact ⟨d,exportE j,x,hx⟩
  · intro c t hfinite hchain
    apply hf c (importT ∘ t) _ (importChain hchain)
    rw [Set.range_comp]
    exact hfinite.image _
  · intro c t hc
    exact hs c (importT t) (importChain hc)

#print axioms toSite
end VanName.SiteBridge

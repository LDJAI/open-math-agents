import LaverTables.Algebra.Inaccessible
import LaverTables.Algebra.WitnessRestriction

/-! Critical sequences of repeated application squares and eventual agreement of their roots. -/
namespace VanName
open FirstOrder LaverTables
open scoped FirstOrder
variable {lam : Ordinal.{0}}

abbrev EndRank (lam : Ordinal.{0}) := VSet lam ↪ₑ[setLang] VSet lam

def bsq (A : EndRank lam → EndRank lam → EndRank lam) : ℕ → EndRank lam → EndRank lam
  | 0 => id
  | n+1 => fun e => A (bsq A n e) (bsq A n e)

variable (hl : Order.IsSuccLimit lam)
variable (j : EndRank lam) (hj : ∃ x, j x ≠ x) (hg : GoodWitness ⇑j)
variable (A : EndRank lam → EndRank lam → EndRank lam)
variable (hA : ∀ a b : EndRank lam, (∃ z, a z ≠ z) → ⇑(A a b) = app ⇑a ⇑b)

include hl hj hg hA
theorem square_nt (e : EndRank lam) (he : ∃ z, e z ≠ z) (m : ℕ) :
    ∃ z, bsq A m e z ≠ z := by
  induction m with
  | zero => exact he
  | succ n ih =>
    change ∃ z, (⇑(A (bsq A n e) (bsq A n e))) z ≠ z
    rw [hA _ _ ih]
    exact hg.app_nontrivial hl hj _ _ ih ih

private theorem square_shift1 (e : EndRank lam) (he : ∃ z, e z ≠ z) (k : ℕ) :
    kappaSeq ⇑(A e e) k = mapOrd ⇑e (kappaSeq ⇑e k) := by
  induction k with
  | zero =>
    change critOf ⇑(A e e) = mapOrd ⇑e (critOf ⇑e)
    rw [hA _ _ he]
    exact hg.critOf_app hl hj _ _ he he
  | succ k ih =>
    change mapOrd ⇑(A e e) (kappaSeq ⇑(A e e) k) = _
    rw [ih, hA e e he]
    exact mapOrd_app_mapOrd hl e e he (LaverTables.ElementaryEmbedding.kappaSeq_lt j hl hj)
      hg.kappaSeq_cof (LaverTables.ElementaryEmbedding.kappaSeq_lt e hl he k)

theorem bsq_sequence (m k : ℕ) : kappaSeq ⇑(bsq A m j) k = kappaSeq ⇑j (m+k) := by
  induction m generalizing k with
  | zero => simp [bsq]
  | succ m ih =>
    have hE := square_nt hl j hj hg A hA j hj m
    change kappaSeq ⇑(A (bsq A m j) (bsq A m j)) k = _
    rw [square_shift1 hl j hj hg A hA _ hE k]
    change kappaSeq ⇑(bsq A m j) (k+1) = _
    simpa only [Nat.succ_add, Nat.add_succ] using ih (k+1)

theorem bsq_agrees (δ : Ordinal.{0}) (hδ : δ < lam) :
    ∃ K, ∀ m ≥ K, ∀ x : VSet lam, x.val.rank < δ → bsq A m j x = x := by
  obtain ⟨K,hK⟩ := hg.kappaSeq_cof δ hδ
  refine ⟨K,fun m hm x hx => ?_⟩
  apply LaverTables.ElementaryEmbedding.apply_eq_of_rank_lt_critOf _ hl (square_nt hl j hj hg A hA j hj m)
  have hc : critOf ⇑(bsq A m j) = kappaSeq ⇑j m := by
    simpa only [kappaSeq, Nat.add_zero] using bsq_sequence hl j hj hg A hA m 0
  rw [hc]
  exact hx.trans_le (hK.trans ((LaverTables.ElementaryEmbedding.kappaSeq_strictMono j hl hj).monotone hm))

theorem root_maps_approach (δ : Ordinal.{0}) (hδ : δ < lam) :
    ∃ K, ∀ m ≥ K, ∀ x : VSet lam, x.val.rank < δ → A (bsq A m j) j x = j x := by
  obtain ⟨K,hK⟩ := bsq_agrees hl j hj hg A hA (mapOrd ⇑j δ)
    (LaverTables.ElementaryEmbedding.mapOrd_lt j hδ)
  refine ⟨K,fun m hm x hx => ?_⟩
  have he := square_nt hl j hj hg A hA j hj m
  have hy : (j x).val.rank < mapOrd ⇑j δ := by
    rw [LaverTables.ElementaryEmbedding.rank_apply j hl x]
    exact LaverTables.ElementaryEmbedding.mapOrd_lt_mapOrd j hx hδ
  have hx' := hK m hm x (hx.trans_le (LaverTables.ElementaryEmbedding.le_mapOrd j hδ))
  change (⇑(A (bsq A m j) j)) x = j x
  rw [hA _ _ he]
  calc
    app ⇑(bsq A m j) ⇑j x = app ⇑(bsq A m j) ⇑j (bsq A m j x) := congrArg _ hx'.symm
    _ = bsq A m j (j x) := hg.app_apply_apply hl hj _ he _ _
    _ = j x := hK m hm (j x) hy

end VanName

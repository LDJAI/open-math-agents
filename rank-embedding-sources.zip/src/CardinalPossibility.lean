import CanonicalPositive
import FiniteRankRigidity

namespace VanName
open FirstOrder LaverTables

/-- Existence of Van Name's unrestricted root chain is exactly equivalent to
the naturally necessary existence of a nontrivial rank-to-rank embedding at
a cardinal height. -/
theorem cardinal_root_possibility :
    (∃ (c : Cardinal.{0}) (j : VSet c.ord ↪ₑ[setLang] VSet c.ord), ∃ x, j x ≠ x) ↔
    ∃ (c : Cardinal.{0}) (t : ℕ → UnaryTerm), RootChain c.ord t := by
  constructor
  · rintro ⟨c,j,hj⟩
    exact positive_of_I3 ⟨c.ord,limit_of_nontrivial_cardinal_embedding c j hj,j,hj⟩
  · rintro ⟨c,t,z,hz,_⟩
    exact ⟨c,z 0,hz 0⟩

#print axioms VanName.cardinal_root_possibility
end VanName

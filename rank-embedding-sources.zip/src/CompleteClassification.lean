import CardinalPossibility
import FiniteCardinalRoots

/-- Complete classification for Joseph Van Name's three rank-embedding root questions. -/
theorem VanName.complete_classification : VanName.Classification :=
  ⟨VanName.cardinal_root_possibility, VanName.finite_cardinal_roots, VanName.fixed_cardinal_roots⟩

#print axioms VanName.complete_classification

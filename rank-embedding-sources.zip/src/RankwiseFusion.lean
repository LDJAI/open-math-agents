import ElementaryLimits

/-! Direct fusion on genuinely elementary maps of a first-order structure, with uniform
control on a given cover. The output stays equal to the base embedding on a prescribed stage. -/
open FirstOrder Filter
open scoped FirstOrder

namespace VanName.Restrictions

variable {L : Language} {M : Type*} [L.Structure M]
abbrev E (L : Language) (M : Type*) [L.Structure M] := M ↪ₑ[L] M
abbrev Agree (U : ℕ → Set M) (k : ℕ) (f g : E L M) :=
  ∀ x ∈ U k, f x = g x

def ContinuousOnRanks (U : ℕ → Set M) (F : E L M → E L M) :=
  ∀ x r, ∃ s, ∀ y, Agree U s x y → Agree U r (F x) (F y)

private theorem compose {U : ℕ → Set M} {F G : E L M → E L M}
    (hF : ContinuousOnRanks U F) (hG : ContinuousOnRanks U G) :
    ContinuousOnRanks U (F ∘ G) := by
  intro x r
  obtain ⟨s,hs⟩ := hF (G x) r
  obtain ⟨t,ht⟩ := hG x s
  exact ⟨t,fun y hy => hs (G y) (ht y hy)⟩

private structure Stage (U : ℕ → Set M) (n : ℕ) (L : Language) [L.Structure M] where
  rows : ℕ → E L M → E L M
  continuous : ∀ i, ContinuousOnRanks U (rows i)

variable (U : ℕ → Set M) (S : ℕ → E L M → E L M)
variable (hS : ∀ m, ContinuousOnRanks U (S m))
variable (x : E L M) (hx : ∀ r, ∀ᶠ m in atTop, Agree U r x (S m x))

include hx

private theorem choose_step {n : ℕ} (st : Stage U n L) :
    ∃ m ≥ n, ∀ i ≤ n, Agree U n (st.rows i x) (st.rows i (S m x)) := by
  have h (i : Fin (n+1)) : ∀ᶠ m in atTop, Agree U n (st.rows i x) (st.rows i (S m x)) := by
    obtain ⟨s,hs⟩ := st.continuous i x n
    exact (hx s).mono fun m hm => hs _ hm
  obtain ⟨m,hm,hi⟩ := ((eventually_ge_atTop n).and (Filter.eventually_all.2 h)).exists
  exact ⟨m,hm,fun i hi' => hi ⟨i,Nat.lt_succ_of_le hi'⟩⟩

include hS

private noncomputable def build : (n : ℕ) → Stage U n L
  | 0 => ⟨fun _ => id, fun _ _ r => ⟨r,fun _ h => h⟩⟩
  | n+1 =>
    let st := build n
    let m := (choose_step U S x hx st).choose
    { rows := fun i => if i ≤ n then st.rows i ∘ S m else id
      continuous := fun i => by
        split
        · exact compose (st.continuous i) (hS m)
        · exact fun _ r => ⟨r,fun _ h => h⟩ }

private noncomputable def index (n : ℕ) := (choose_step U S x hx (build U S hS x hx n)).choose

private theorem future {n i : ℕ} (h : n ≤ i) :
    (build U S hS x hx n).rows i = id := by
  cases n with
  | zero => rfl
  | succ n => simp [build,show ¬ i ≤ n by omega]

private theorem successor {n i : ℕ} (hi : i ≤ n) :
    (build U S hS x hx (n+1)).rows i = (build U S hS x hx n).rows i ∘ S (index U S hS x hx n) := by
  simp [build,hi,index]

private theorem shift {n i : ℕ} (hi : i < n) (y : E L M) :
    (build U S hS x hx n).rows i y =
    S (index U S hS x hx i) ((build U S hS x hx n).rows (i+1) y) := by
  induction n generalizing y with
  | zero => omega
  | succ n ih =>
    by_cases he : i = n
    · subst i
      rw [successor U S hS x hx le_rfl, future U S hS x hx le_rfl, future U S hS x hx le_rfl]
      rfl
    · rw [successor U S hS x hx (by omega),successor U S hS x hx (by omega)]
      exact ih (by omega) _

private theorem row_step (n i : ℕ) :
    Agree U n ((build U S hS x hx n).rows i x) ((build U S hS x hx (n+1)).rows i x) := by
  by_cases hi : i ≤ n
  · rw [successor U S hS x hx hi]
    exact (choose_step U S x hx (build U S hS x hx n)).choose_spec.2 i hi
  · rw [future U S hS x hx (by omega),future U S hS x hx (by omega)]
    exact fun _ _ => rfl

private theorem row_tail (hU : Monotone U) (r i : ℕ) {n : ℕ} (hn : r ≤ n) :
    Agree U r ((build U S hS x hx r).rows i x) ((build U S hS x hx n).rows i x) := by
  induction n, hn using Nat.le_induction with
  | base => exact fun _ _ => rfl
  | succ n hn ih => exact fun y hy => (ih y hy).trans (row_step U S hS x hx n i y (hU hn hy))

/-- An elementary backwards orbit, with explicit agreement on stage i at row i.
Continuity and convergence are stated entirely in terms of restriction to the cover. -/
theorem exists_backward_orbit (hU : Monotone U) (cover : ∀ y, ∃ r, y ∈ U r) :
    ∃ (m : ℕ → ℕ) (z : ℕ → E L M), (∀ i, i ≤ m i) ∧
      (∀ i, Agree U i (z i) x) ∧ ∀ i, z i = S (m i) (z (i+1)) := by
  let a := fun n i => (build U S hS x hx n).rows i x
  have hlim (i) : ∃ e : E L M, ∀ r, ∃ k : ℕ, ∀ n ≥ k, Agree U r (a n i) e := by
    apply VanName.exists_limit_on_cover U cover (fun n => a n i)
    intro r
    refine ⟨r,fun n hn p hp y hy => ?_⟩
    exact (row_tail U S hS x hx hU r i hn y hy).symm.trans (row_tail U S hS x hx hU r i hp y hy)
  choose z hz using hlim
  refine ⟨index U S hS x hx,z,fun i => (choose_step U S x hx _).choose_spec.1,?_,?_⟩
  · intro i y hy
    obtain ⟨k,hk⟩ := hz i i
    let n := max k i
    have he := row_tail U S hS x hx hU i i (le_max_right k i) y hy
    rw [future U S hS x hx le_rfl] at he
    exact (hk n (le_max_left k i) y hy).symm.trans he.symm
  · intro i
    apply DFunLike.ext
    intro y
    obtain ⟨r,hr⟩ := cover y
    obtain ⟨s,hs⟩ := hS (index U S hS x hx i) (z (i+1)) r
    obtain ⟨k,hk⟩ := hz i r
    obtain ⟨l,hl⟩ := hz (i+1) s
    let n := max (i+1) (max k l)
    have hin : i < n := by dsimp [n]; omega
    have hkn : k ≤ n := by dsimp [n]; omega
    have hln : l ≤ n := by dsimp [n]; omega
    have hc := hs (a n (i+1)) (fun b hb => (hl n hln b hb).symm) y hr
    have he := congrArg (fun e : E L M => e y) (shift U S hS x hx hin x)
    exact (hk n hkn y hr).symm.trans (he.trans hc.symm)

#print axioms VanName.Restrictions.exists_backward_orbit
end VanName.Restrictions

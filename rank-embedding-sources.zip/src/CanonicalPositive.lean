import CanonicalApplication
import CanonicalFusion
import NormalizedCardinal

namespace VanName
open FirstOrder LaverTables
open scoped FirstOrder

/-- Relative possibility uses only I3, expressed in the canonical set-theoretic library. -/
theorem positive_of_I3 (H : I3) :
    ∃ (c : Cardinal.{0}) (t : ℕ → UnaryTerm), RootChain c.ord t := by
  obtain ⟨c,hl,j,hj,hg⟩ := exists_cardinal_good_witness H
  have hlt := LaverTables.ElementaryEmbedding.kappaSeq_lt j hl hj
  have hcof := hg.kappaSeq_cof
  exact ⟨c,roots_of_good hl j hj hg (totalApp hl hlt hcof)
    (totalApp_coe_of_nontrivial hl hlt hcof)
    (fun a b δ (hδ : δ < c.ord) => totalApp_continuous_rank hl hlt hcof a b hδ)⟩

#print axioms VanName.positive_of_I3
end VanName

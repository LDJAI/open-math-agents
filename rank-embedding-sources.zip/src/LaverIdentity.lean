import LaverTables.Foundations.FormulaLib

namespace VanName
open LaverTables FirstOrder
open scoped FirstOrder
variable {lam : Ordinal.{0}}

theorem graphInter_pair_value (f : VSet lam → VSet lam)
    {x y : VSet lam} {θ : Ordinal.{0}} (hp : ZFSet.pair x.val y.val ∈ graphInter f θ) : f x = y := by
  obtain ⟨w,hw⟩ := (ZFSet.mem_sep.mp hp).2
  have h := ZFSet.pair_inj.mp hw
  exact Subtype.ext ((congrArg (fun v : VSet lam => (f v).val) (Subtype.ext h.1)).trans h.2.symm)

theorem app_id (hlam : Order.IsSuccLimit lam) (f : VSet lam → VSet lam) : app id f = f := by
  classical
  funext x
  let z := ZFSet.pair x.val (f x).val
  have hz : z.rank < lam := rank_pair_lt hlam x.property (f x).property
  let P := fun y : VSet lam => ∃ θ : Ordinal.{0}, ∃ hθ : θ < lam,
        ZFSet.pair x.val y.val ∈ (id ⟨graphInter f θ, (rank_graphInter_le f θ).trans_lt hθ⟩ : VSet lam).val
  have hex : P (f x) := by
    refine ⟨Order.succ z.rank,hlam.succ_lt hz,?_⟩
    change z ∈ graphInter f (Order.succ z.rank)
    exact ZFSet.mem_sep.mpr ⟨ZFSet.mem_vonNeumann_succ z, ⟨x,rfl⟩⟩
  have hunt : ∃! y, P y := by
    refine ⟨f x,hex,?_⟩
    rintro y ⟨_,_,hp⟩
    exact (graphInter_pair_value f hp).symm
  rw [app,dif_pos hunt]
  exact hunt.unique hunt.choose_spec.1 hex

#print axioms VanName.app_id
end VanName

import LaverTables.Foundations.FormulaLib

open FirstOrder FirstOrder.Language LaverTables
namespace VanName
variable {lam : Ordinal.{0}}

def RankAgree (f g : VSet lam → VSet lam) (θ : Ordinal.{0}) : Prop :=
  ∀ x : VSet lam, x.val.rank < θ → f x = g x

theorem graphInter_congr {a b : VSet lam → VSet lam} {θ : Ordinal.{0}}
    (hab : RankAgree a b θ) : graphInter a θ = graphInter b θ := by
  apply ZFSet.ext
  intro z
  simp only [graphInter, ZFSet.mem_sep, ZFSet.mem_vonNeumann]
  apply and_congr_right
  intro hz
  constructor
  · rintro ⟨x, rfl⟩
    exact ⟨x, by rw [hab x ((rank_lt_rank_pair_left _ _).trans hz)]⟩
  · rintro ⟨x, rfl⟩
    exact ⟨x, by rw [hab x ((rank_lt_rank_pair_left _ _).trans hz)]⟩

end VanName

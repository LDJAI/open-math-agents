import ActualFiniteTerms
import FiniteRankRigidity
import ArbitraryHeight

open FirstOrder FirstOrder.Language LaverTables

namespace VanName

/-- The finite-menu obstruction at every cardinal height, with no cofinality
assumption on the ambient height. -/
theorem finite_cardinal_roots (c : Cardinal.{0}) (t : ℕ → UnaryTerm)
    (ht : (Set.range t).Finite) : ¬ RootChain c.ord t := by
  classical
  rintro ⟨J, nontrivial, root⟩
  have hlam := limit_of_nontrivial_cardinal_embedding c (J 0) (nontrivial 0)
  let S := (ht.image UnaryTerm.toFiniteRoot).toFinset
  let k := S.sup FiniteRoots.Term.threshold
  have desc (n : ℕ) : kappaSeq ⇑(J (n+1)) k < kappaSeq ⇑(J n) k := by
    have hmem : (t n).toFiniteRoot ∈ S :=
      (Set.Finite.mem_toFinset _).2 ⟨t n, ⟨n,rfl⟩, rfl⟩
    let j : FiniteRoots.Actual.Nontriv c.ord := ⟨J (n+1),nontrivial (n+1)⟩
    have hh := FiniteRoots.Actual.step_growth_any_height hlam (t n).toFiniteRoot j k (Finset.le_sup hmem)
    rw [root n]
    simpa only [j, UnaryTerm.toFiniteRoot_eval] using hh
  exact (wellFounded_iff_isEmpty_descending_chain.mp wellFounded_lt).elim
    ⟨fun n => kappaSeq ⇑(J n) k, desc⟩

/-- The fixed-term version follows by taking a singleton menu. -/
theorem fixed_cardinal_roots (c : Cardinal.{0}) (t : UnaryTerm) :
    ¬ RootChain c.ord (fun _ => t) :=
  finite_cardinal_roots c _ (Set.finite_singleton t |>.subset (by rintro _ ⟨_, rfl⟩; rfl))

end VanName
#print axioms VanName.finite_cardinal_roots
#print axioms VanName.fixed_cardinal_roots

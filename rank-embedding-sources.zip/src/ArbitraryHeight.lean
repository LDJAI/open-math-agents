import ActualFiniteTerms
import LaverTables.Algebra.DeltaZeroApp

/-!
# Finite menus of roots at arbitrary limit heights

For a single possible generator j, let δ be the supremum of its critical
sequence. If δ is below the height, canonical restriction preserves the raw
evaluation of every unary term. The critical sequence of the root application
therefore agrees with the sequence computed at the restricted, cofinal height.
This comparison is made separately for each generator in the chain.
-/

namespace FiniteRoots.Actual

open FirstOrder FirstOrder.Language LaverTables

variable {lam : Ordinal.{0}}

theorem raw_mem (T : Term) (j : VSet lam → VSet lam) : IterMem j (raw T j) := by
  induction T with
  | var => exact IterMem.base
  | app a b ha hb => exact IterMem.app ha hb
  | comp a b ha hb => exact IterMem.comp ha hb

theorem raw_restricts (hl : Order.IsSuccLimit lam) (j : Nontriv lam)
    (hd : deltaOf ⇑j.1 < lam) (T : Term) :
    RestrictsTo j.1 hd (raw T ⇑j.1)
      (raw T ⇑(restrictEmbedding j.1 hl j.2 hd)) := by
  induction T with
  | var => exact restrictsTo_restrictEmbedding hl j.2 hd
  | comp a b ha hb => exact RestrictsTo.comp hd ha hb
  | app a b ha hb =>
    have hpres := (iterMem_dz3_absorbs hl (raw_mem a ⇑j.1)).1
    exact restrictsTo_app hl j.2 hd (raw_mem a _) ha hb hpres.subPres (hpres.funcPres hl)

/-- Every finite entry of the critical sequence survives restriction when
the lower map is a nontrivial elementary embedding. -/
theorem kappa_agrees (hl : Order.IsSuccLimit lam) (j : Nontriv lam)
    (hd : deltaOf ⇑j.1 < lam) {f : VSet lam → VSet lam}
    (e : VSet (deltaOf ⇑j.1) ↪ₑ[setLang] VSet (deltaOf ⇑j.1))
    (hR : RestrictsTo j.1 hd f ⇑e) (he : ∃ x, e x ≠ x) (k : ℕ) :
    kappaSeq f k = kappaSeq ⇑e k := by
  have hdlim := isSuccLimit_deltaOf j.1 hl j.2
  induction k with
  | zero =>
    exact hR.critOf_eq hd (ElementaryEmbedding.critOf_lt_mapOrd e hdlim he)
      (ElementaryEmbedding.critOf_lt e hdlim he)
  | succ k ih =>
    change mapOrd f (kappaSeq f k) = mapOrd ⇑e (kappaSeq ⇑e k)
    rw [ih]
    exact hR.mapOrd_eq hd (ElementaryEmbedding.kappaSeq_lt e hdlim he k)

/-- The same syntactic threshold works with no countable cofinality
assumption on the ambient height. -/
theorem step_growth_any_height (hl : Order.IsSuccLimit lam) (T : Term)
    (j : Nontriv lam) (k : ℕ) (hk : T.threshold ≤ k) :
    kappaSeq ⇑j.1 k < kappaSeq (app (raw T ⇑j.1) ⇑j.1) k := by
  rcases (deltaOf_le j.1 hl j.2).lt_or_eq with hd | hg
  · let j' : Nontriv (deltaOf ⇑j.1) :=
      ⟨restrictEmbedding j.1 hl j.2 hd, restrict_nontrivial j.1 hl j.2 hd⟩
    have hl' := isSuccLimit_deltaOf j.1 hl j.2
    have hg' : GoodWitness ⇑j'.1 := goodWitness_restrict j.1 hl j.2 hd
    have hlow := step_growth hl' (ElementaryEmbedding.kappaSeq_lt j'.1 hl' j'.2)
      hg'.kappaSeq_cof T j' k hk
    let R : Term := .app T .var
    have hR : RestrictsTo j.1 hd (raw R ⇑j.1) (raw R ⇑j'.1) := raw_restricts hl j hd R
    obtain ⟨e, he, hnt⟩ := hg'.iterMem_elementary hl' j'.2 (raw_mem R ⇑j'.1)
    have hnt' : ∃ x, e x ≠ x := by rw [he]; exact hnt
    have hR' : RestrictsTo j.1 hd (raw R ⇑j.1) ⇑e := he.symm ▸ hR
    have hseq := kappa_agrees hl j hd e hR' hnt' k
    rw [he] at hseq
    change kappaSeq ⇑j.1 k < kappaSeq (raw R ⇑j.1) k
    rw [hseq, ← kappaSeq_restrict j.1 hl j.2 hd k]
    exact hlow
  · exact step_growth hl (ElementaryEmbedding.kappaSeq_lt j.1 hl j.2)
      (GoodWitness.kappaSeq_cof hg) T j k hk

theorem no_finite_menu_any_height (hl : Order.IsSuccLimit lam) (S : Finset Term)
    (t : ℕ → Term) (covered : ∀ n, t n ∈ S)
    (J : ℕ → VSet lam ↪ₑ[setLang] VSet lam) (hne : ∀ n, ∃ x, J n x ≠ x) :
    ¬ (∀ n, ⇑(J n) = app (raw (t n) ⇑(J (n+1))) ⇑(J (n+1))) := by
  intro h
  let k := S.sup Term.threshold
  have desc (n : ℕ) : kappaSeq ⇑(J (n+1)) k < kappaSeq ⇑(J n) k := by
    rw [h n]
    exact step_growth_any_height hl (t n) ⟨J (n+1), hne (n+1)⟩ k (Finset.le_sup (covered n))
  exact (wellFounded_iff_isEmpty_descending_chain.mp wellFounded_lt).elim
    ⟨fun n => kappaSeq ⇑(J n) k, desc⟩

end FiniteRoots.Actual

#print axioms FiniteRoots.Actual.no_finite_menu_any_height

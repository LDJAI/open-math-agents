import Mathlib.ModelTheory.ElementaryMaps
import Mathlib.Order.Filter.AtTopBot.Finite
import Mathlib.SetTheory.ZFC.VonNeumann

/-! Closure of actual elementary embeddings under eventual agreement, including on the
von Neumann rank segments in the first-order language of membership. -/

open FirstOrder Filter
open scoped FirstOrder

namespace VanName

universe u

variable {L : Language} {M N : Type*} [L.Structure M] [L.Structure N]

/-- Pointwise eventual agreement with elementary maps transfers every formula
to the limit, since every first-order formula is tested on a finite tuple. -/
def elementaryOfEventuallyEqual {ι : Type*} {l : Filter ι} [l.NeBot]
    (seq : ι → M ↪ₑ[L] N) (f : M → N)
    (h : ∀ x, ∀ᶠ i in l, seq i x = f x) : M ↪ₑ[L] N where
  toFun := f
  map_formula' := by
    intro n φ v
    have ht : ∀ᶠ i in l, ∀ k : Fin n, seq i (v k) = f (v k) :=
      Filter.eventually_all.2 fun k => h (v k)
    obtain ⟨i,hi⟩ := ht.exists
    have hv : (seq i : M → N) ∘ v = f ∘ v := funext hi
    rw [← hv]
    exact (seq i).map_formula φ v

/-- Completeness for uniform agreement on any countable cover. No compactness,
cardinality bounds, or closure under the language's functions are required of the cover. -/
theorem exists_limit_on_cover (stage : ℕ → Set M)
    (cover : ∀ x, ∃ r, x ∈ stage r) (seq : ℕ → M ↪ₑ[L] N)
    (h : ∀ r, ∃ k : ℕ, ∀ i ≥ k, ∀ j ≥ k, ∀ x ∈ stage r, seq i x = seq j x) :
    ∃ e : M ↪ₑ[L] N, ∀ r, ∃ k : ℕ, ∀ i ≥ k, ∀ x ∈ stage r, seq i x = e x := by
  classical
  choose cutoff hc using h
  choose layer hl using cover
  let f : M → N := fun x => seq (cutoff (layer x)) x
  have hf (x : M) : ∀ᶠ i in atTop, seq i x = f x :=
    eventually_atTop.2 ⟨cutoff (layer x), fun i hi =>
      hc (layer x) i hi _ le_rfl x (hl x)⟩
  refine ⟨elementaryOfEventuallyEqual seq f hf, ?_⟩
  intro r
  refine ⟨cutoff r, ?_⟩
  intro i hi x hx
  change seq i x = seq (cutoff (layer x)) x
  let j := max (cutoff r) (cutoff (layer x))
  exact (hc r i hi j (le_max_left _ _) x hx).trans
    (hc (layer x) j (le_max_right _ _) _ le_rfl x (hl x))

/-- One binary relation and no function symbols. -/
inductive MembershipRelation : ℕ → Type
  | mem : MembershipRelation 2

def membershipLanguage : Language := ⟨fun _ => Empty, MembershipRelation⟩

/-- The underlying collection of the actual von Neumann level. -/
abbrev RankLevel (height : Ordinal.{u}) := {x : ZFSet.{u} // x ∈ ZFSet.vonNeumann height}

instance (height : Ordinal.{u}) : membershipLanguage.Structure (RankLevel height) where
  funMap z := nomatch z
  RelMap | .mem => fun v => (v 0).1 ∈ (v 1).1

/-- A rankwise Cauchy sequence of elementary self-embeddings of the actual membership
structure (V_height, ∈) has a rankwise limit which is again elementary. -/
theorem rank_limit (height : Ordinal.{u}) (level : ℕ → Ordinal.{u})
    (cofinal : ∀ α < height, ∃ r, α < level r)
    (seq : ℕ → RankLevel height ↪ₑ[membershipLanguage] RankLevel height)
    (cauchy : ∀ r, ∃ k : ℕ, ∀ i ≥ k, ∀ j ≥ k, ∀ x : RankLevel height,
      x.1 ∈ ZFSet.vonNeumann (level r) → seq i x = seq j x) :
    ∃ e : RankLevel height ↪ₑ[membershipLanguage] RankLevel height,
      ∀ r, ∃ k : ℕ, ∀ i ≥ k, ∀ x : RankLevel height,
        x.1 ∈ ZFSet.vonNeumann (level r) → seq i x = e x := by
  apply exists_limit_on_cover (fun r => {x : RankLevel height | x.1 ∈ ZFSet.vonNeumann (level r)}) _ seq cauchy
  intro x
  obtain ⟨r,hr⟩ := cofinal (ZFSet.rank x.1) (ZFSet.mem_vonNeumann.mp x.2)
  exact ⟨r, ZFSet.mem_vonNeumann.mpr hr⟩

#print axioms VanName.elementaryOfEventuallyEqual
#print axioms VanName.exists_limit_on_cover
#print axioms VanName.rank_limit
end VanName

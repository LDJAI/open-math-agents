import LaverIdentity
import LaverTables.Algebra.Transfer

namespace VanName
open LaverTables FirstOrder
open scoped FirstOrder
variable {lam : Ordinal.{0}}

theorem app_value_of_graph_mem
    (hlam : Order.IsSuccLimit lam) {δseq : ℕ → Ordinal.{0}}
    (hδlt : ∀ n, δseq n < lam) (hδcof : ∀ θ < lam, ∃ n, θ ≤ δseq n)
    (a : VSet lam ↪ₑ[setLang] VSet lam) (f : VSet lam → VSet lam)
    {x y : VSet lam} {θ : Ordinal.{0}} (hθ : θ < lam)
    (hp : ZFSet.pair x.val y.val ∈
        (a ⟨graphInter f θ, (rank_graphInter_le f θ).trans_lt hθ⟩).val) :
    app (⇑a) f x = y := by
  classical
  by_cases ha : ∃ w, a w ≠ w
  · have H := LaverTables.ElementaryEmbedding.app_exists_unique a hlam
      (LaverTables.ElementaryEmbedding.omega0_lt_of_nontrivial a hlam ha) hδlt hδcof f x
    rw [app,dif_pos H]
    exact H.unique H.choose_spec.1 ⟨θ,hθ,hp⟩
  · have he : (⇑a : VSet lam → VSet lam) = id := by
      funext w
      exact not_ne_iff.mp (fun hn => ha ⟨w,hn⟩)
    rw [he,app_id hlam f]
    change ZFSet.pair x.val y.val ∈ ((⇑a : VSet lam → VSet lam) _).val at hp
    rw [he] at hp
    exact graphInter_pair_value f hp

#print axioms VanName.app_value_of_graph_mem
end VanName

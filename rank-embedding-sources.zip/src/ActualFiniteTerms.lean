import FiniteTermShifts
import RankIntoRankStatement
import LaverTables.Algebra.GoodWitness

/-! Concrete application of the finite-menu obstruction to actual elementary
embeddings of the rank `VSet lam`. The only assumptions are that `lam` is a
limit ordinal and that the displayed sequence is cofinal below it. -/
namespace FiniteRoots.Actual

open FirstOrder FirstOrder.Language LaverTables

abbrev Nontriv (lam : Ordinal.{0}) :=
  {j : VSet lam ↪ₑ[setLang] VSet lam // ∃ z, j z ≠ z}

variable {lam : Ordinal.{0}} (hlam : Order.IsSuccLimit lam)
  {δ : ℕ → Ordinal.{0}} (hδ : ∀ n, δ n < lam) (hcof : ∀ θ < lam, ∃ n, θ ≤ δ n)

noncomputable def algebra : Action (Nontriv lam) (Set.Iio lam) where
  act j a := ⟨mapOrd ⇑j.1 a.1, ElementaryEmbedding.mapOrd_lt j.1 a.2⟩
  app a b := ⟨appEmbedding hlam a.1 b.1 a.2 hδ hcof,
    app_nontrivial hlam a.1 b.1 a.2 b.2 hδ hcof⟩
  comp a b := ⟨a.1.comp b.1, comp_nontrivial hlam a.1 b.1 b.2⟩
  crit a := ⟨critOf ⇑a.1, ElementaryEmbedding.critOf_lt a.1 hlam a.2⟩
  inc j _ b hab := ElementaryEmbedding.mapOrd_lt_mapOrd j.1 hab b.2
  extensive j a := ElementaryEmbedding.le_mapOrd j.1 a.2
  moves a := ElementaryEmbedding.critOf_lt_mapOrd a.1 hlam a.2
  compose a b x := Subtype.ext (mapOrd_comp a.1 b.1 x.2)
  apply_intertwines a b x := Subtype.ext (mapOrd_app_mapOrd hlam a.1 b.1 a.2 hδ hcof x.2)
  critical_apply a b := Subtype.ext (critOf_app hlam a.1 b.1 a.2 b.2 hδ hcof)

/-- Interpret both term constructors directly by Laver application and ordinary
function composition on the actual hierarchy of sets. -/
noncomputable def raw : Term → (VSet lam → VSet lam) → (VSet lam → VSet lam)
  | .var, j => j
  | .app a b, j => LaverTables.app (raw a j) (raw b j)
  | .comp a b, j => raw a j ∘ raw b j

lemma coe_eval (T : Term) (j : Nontriv lam) :
    ⇑(eval (algebra hlam hδ hcof) T j).1 = raw T ⇑j.1 := by
  induction T with
  | var => rfl
  | app a b ia ib =>
    change LaverTables.app ⇑(eval (algebra hlam hδ hcof) a j).1
      ⇑(eval (algebra hlam hδ hcof) b j).1 = _
    rw [ia, ib]; rfl
  | comp a b ia ib =>
    change (⇑(eval (algebra hlam hδ hcof) a j).1 ∘ ⇑(eval (algebra hlam hδ hcof) b j).1) = _
    rw [ia, ib]; rfl

include hlam hδ hcof in
/-- No fixed finite collection of terms supports a backward chain of nonidentity
elementary rank-into-rank embeddings at a height of countable cofinality. -/
theorem no_actual_finite_term_chain (S : Finset Term) (t : ℕ → Term)
    (covered : ∀ n, t n ∈ S) (J : ℕ → VSet lam ↪ₑ[setLang] VSet lam)
    (hne : ∀ n, ∃ x, J n x ≠ x) :
    ¬ (∀ n, ⇑(J n) = LaverTables.app (raw (t n) ⇑(J (n+1))) ⇑(J (n+1))) := by
  intro root
  let M := algebra hlam hδ hcof
  let j (n : ℕ) : Nontriv lam := ⟨J n, hne n⟩
  apply no_finite_term_chain M S t covered j
  intro n
  apply Subtype.ext
  apply DFunLike.ext
  intro x
  change J n x = LaverTables.app ⇑(eval M (t n) (j (n+1))).1 ⇑(J (n+1)) x
  rw [coe_eval]
  exact congrFun (root n) x

lemma point_val (j : Nontriv lam) (k : ℕ) :
    (point (algebra hlam hδ hcof) j k).val = kappaSeq ⇑j.1 k := by
  induction k with
  | zero => rfl
  | succ k ih =>
    change mapOrd ⇑j.1 (point (algebra hlam hδ hcof) j k).val = mapOrd ⇑j.1 (kappaSeq ⇑j.1 k)
    rw [ih]

include hlam hδ hcof in
/-- One concrete root step increases every sufficiently late critical ordinal. -/
theorem step_growth (T : Term) (j : Nontriv lam) (k : ℕ) (hk : T.threshold ≤ k) :
    kappaSeq ⇑j.1 k < kappaSeq (LaverTables.app (raw T ⇑j.1) ⇑j.1) k := by
  let M := algebra hlam hδ hcof
  have hg := term_moves M T j k hk
  rw [← point_app M (eval M T j) j k] at hg
  change (point M j k).val < (point M (M.app (eval M T j) j) k).val at hg
  rw [point_val, point_val] at hg
  change kappaSeq ⇑j.1 k < kappaSeq (LaverTables.app ⇑(eval M T j).1 ⇑j.1) k at hg
  rwa [coe_eval] at hg

end FiniteRoots.Actual

namespace VanName

open FirstOrder FirstOrder.Language LaverTables

def UnaryTerm.toFiniteRoot : UnaryTerm → FiniteRoots.Term
  | .var => .var
  | .ap a b => .app a.toFiniteRoot b.toFiniteRoot
  | .comp a b => .comp a.toFiniteRoot b.toFiniteRoot

lemma UnaryTerm.toFiniteRoot_eval {lam : Ordinal.{0}} (t : UnaryTerm) (j : VSet lam → VSet lam) :
    FiniteRoots.Actual.raw t.toFiniteRoot j = t.eval j := by
  induction t with
  | var => rfl
  | ap a b ia ib => simp only [toFiniteRoot, FiniteRoots.Actual.raw, eval, ia, ib]
  | comp a b ia ib => simp only [toFiniteRoot, FiniteRoots.Actual.raw, eval, ia, ib]

theorem no_finite_root_chain_at_omega_cofinal_height {lam : Ordinal.{0}}
    (hlam : Order.IsSuccLimit lam) {δ : ℕ → Ordinal.{0}} (hδ : ∀ n, δ n < lam)
    (hcof : ∀ θ < lam, ∃ n, θ ≤ δ n) (t : ℕ → UnaryTerm) (ht : (Set.range t).Finite) :
    ¬ RootChain lam t := by
  classical
  rintro ⟨J, hn, root⟩
  let S := (ht.image UnaryTerm.toFiniteRoot).toFinset
  apply FiniteRoots.Actual.no_actual_finite_term_chain hlam hδ hcof S
    (fun n => (t n).toFiniteRoot) ?_ J hn
  · intro n
    simpa only [UnaryTerm.toFiniteRoot_eval] using root n
  · intro n
    exact (Set.Finite.mem_toFinset _).2 ⟨t n, ⟨n,rfl⟩, rfl⟩

end VanName
#print axioms FiniteRoots.Actual.no_actual_finite_term_chain

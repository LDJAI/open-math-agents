import RankIntoRankStatement

/-! Finite sets of term functions and finite menus of representing expressions
give exactly the same root-chain existence question. -/
open FirstOrder LaverTables

namespace VanName

/-- The actual unary operation on elementary self-embeddings denoted by a term.
The result is coerced to its action on points. -/
noncomputable def UnaryTerm.onEmbeddings (lam : Ordinal.{0}) (t : UnaryTerm)
    (j : VSet lam ↪ₑ[setLang] VSet lam) : VSet lam → VSet lam := t.eval j

theorem root_chain_with_finitely_many_functions_iff (lam : Ordinal.{0}) :
    (∃ t : ℕ → UnaryTerm, (Set.range fun n => (t n).onEmbeddings lam).Finite ∧ RootChain lam t) ↔
      ∃ u : ℕ → UnaryTerm, (Set.range u).Finite ∧ RootChain lam u := by
  classical
  constructor
  · rintro ⟨t,ht,J,hne,hchain⟩
    let F := fun n => (t n).onEmbeddings lam
    let repr := fun f => t (Function.invFun F f)
    let u := repr ∘ F
    have hu : (Set.range u).Finite := by
      rw [show Set.range u = repr '' Set.range F from Set.range_comp _ _]
      exact ht.image _
    refine ⟨u,hu,J,hne,?_⟩
    intro n
    have hf : F (Function.invFun F (F n)) = F n :=
      Function.invFun_eq ⟨n,rfl⟩
    have he := congrFun hf (J (n+1))
    change (u n).eval (J (n+1)) = (t n).eval (J (n+1)) at he
    rw [he]
    exact hchain n
  · rintro ⟨u,hu,hj⟩
    refine ⟨u,?_,hj⟩
    change (Set.range (UnaryTerm.onEmbeddings lam ∘ u)).Finite
    rw [Set.range_comp]
    exact hu.image _

#print axioms VanName.root_chain_with_finitely_many_functions_iff
end VanName

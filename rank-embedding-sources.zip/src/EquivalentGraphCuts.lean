import LaverTables.Algebra.ClassExtension

/-! Van Name writes application using domain restrictions. The Laver formalization
cuts the rank of graph pairs. For genuine elementary embeddings the two directed
families are cofinal in one another, and their image unions are identical. -/

namespace VanName.GraphCuts
open FirstOrder LaverTables Order
open scoped FirstOrder
variable {lam : Ordinal.{0}}

abbrev End (lam : Ordinal.{0}) := VSet lam ↪ₑ[setLang] VSet lam

noncomputable def bound (g : End lam) (θ : Ordinal.{0}) :=
  succ (succ (max θ (mapOrd ⇑g θ)))

theorem bound_lt (hl : IsSuccLimit lam) (g : End lam) {θ : Ordinal.{0}} (hθ : θ < lam) :
    bound g θ < lam :=
  hl.succ_lt (hl.succ_lt (max_lt hθ (LaverTables.ElementaryEmbedding.mapOrd_lt g hθ)))

noncomputable def domainCut (g : End lam) (θ : Ordinal.{0}) :=
  (graphInter ⇑g (bound g θ)).sep fun p => ∃ x : VSet lam, x.val.rank < θ ∧
    p = ZFSet.pair x.val (g x).val

theorem domainCut_mem_iff (hl : IsSuccLimit lam) (g : End lam) {θ : Ordinal.{0}} (hθ : θ < lam)
    (p : ZFSet.{0}) : p ∈ domainCut g θ ↔ ∃ x : VSet lam, x.val.rank < θ ∧
    p = ZFSet.pair x.val (g x).val := by
  refine ⟨fun h => (ZFSet.mem_sep.mp h).2, ?_⟩
  rintro ⟨x,hx,rfl⟩
  apply ZFSet.mem_sep.mpr
  refine ⟨ZFSet.mem_sep.mpr ⟨ZFSet.mem_vonNeumann.mpr ?_, ⟨x,rfl⟩⟩, ⟨x,hx,rfl⟩⟩
  rw [rank_pair',bound]
  apply succ_lt_succ (succ_lt_succ _)
  apply max_lt (hx.trans_le (le_max_left _ _))
  rw [LaverTables.ElementaryEmbedding.rank_apply g hl]
  exact (LaverTables.ElementaryEmbedding.mapOrd_lt_mapOrd g hx hθ).trans_le (le_max_right _ _)

theorem domainCut_rank (hl : IsSuccLimit lam) (g : End lam) {θ : Ordinal.{0}} (hθ : θ < lam) :
    (domainCut g θ).rank < lam :=
  (ZFSet.rank_mono ZFSet.sep_subset).trans_lt
    ((rank_graphInter_le g _).trans_lt (bound_lt hl g hθ))

theorem pairCut_subset_domainCut (hl : IsSuccLimit lam) (g : End lam) {θ : Ordinal.{0}}
    (hθ : θ < lam) : graphInter ⇑g θ ⊆ domainCut g θ := by
  intro p hp
  obtain ⟨hpθ,x,rfl⟩ := ZFSet.mem_sep.mp hp
  apply (domainCut_mem_iff hl g hθ _).mpr
  exact ⟨x,(rank_lt_rank_pair_left _ _).trans (ZFSet.mem_vonNeumann.mp hpθ),rfl⟩

/-- The graph defined in the source question equals the one used in the Lean statement,
for every ordered pair and, more generally, for every candidate graph element. -/
theorem image_union_iff (hl : IsSuccLimit lam) (a g : End lam) (p : ZFSet.{0}) :
    (∃ θ : Ordinal.{0}, ∃ hθ : θ < lam,
       p ∈ (a ⟨domainCut g θ,domainCut_rank hl g hθ⟩).val) ↔
    (∃ θ : Ordinal.{0}, ∃ hθ : θ < lam,
       p ∈ (a ⟨graphInter ⇑g θ,(rank_graphInter_le g θ).trans_lt hθ⟩).val) := by
  constructor
  · rintro ⟨θ,hθ,hp⟩
    refine ⟨bound g θ,bound_lt hl g hθ,?_⟩
    have hsub : domainCut g θ ⊆ graphInter ⇑g (bound g θ) := by
      unfold domainCut
      exact ZFSet.sep_subset
    exact (LaverTables.ElementaryEmbedding.apply_subset_iff a _ _).mpr hsub hp
  · rintro ⟨θ,hθ,hp⟩
    refine ⟨θ,hθ,?_⟩
    exact (LaverTables.ElementaryEmbedding.apply_subset_iff a _ _).mpr
      (pairCut_subset_domainCut hl g hθ) hp

#print axioms VanName.GraphCuts.image_union_iff
end VanName.GraphCuts

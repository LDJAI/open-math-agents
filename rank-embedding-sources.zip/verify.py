#!/usr/bin/env python3
"""Compile the public Lean statements, proofs and their pinned dependencies from source."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
FC_REV = "9097e2f90e66d2f6244209cb1c07f7120d17ec53"
LAVER_REV = "1f5ee8c0f6dee8fe25f8971371ff6533dca0a707"
ALLOWED = {"propext", "Classical.choice", "Quot.sound"}

def output(*args, cwd, env=None):
    return subprocess.check_output(args, cwd=cwd, env=env, text=True).strip()

def pinned(repo, expected):
    actual = output("git", "rev-parse", "HEAD", cwd=repo)
    if actual != expected:
        raise SystemExit(f"Checkout {repo} is at {actual}. Required commit {expected}.")

def build(work, fc, upstream):
    pinned(fc, FC_REV)
    pinned(upstream, LAVER_REV)
    lean = output("lake", "env", "which", "lean", cwd=fc)
    print(output(lean, "--version", cwd=fc), flush=True)
    paths = output("lake", "env", "printenv", "LEAN_PATH", cwd=fc).split(os.pathsep)
    env = os.environ.copy()
    env["LEAN_PATH"] = os.pathsep.join([str(work)] + [str((fc / p).resolve()) for p in paths if p])
    shutil.copytree(HERE / "src", work, dirs_exist_ok=True)
    compat = json.loads((HERE / "dependency-compatibility.json").read_text())
    built = set()
    def compile_module(name):
        if name in built:
            return
        source = Path(*name.split(".")).with_suffix(".lean")
        local = work / source
        upstream_module = name.startswith(("LaverTables.", "Comparator."))
        if upstream_module:
            data = output("git", "show", f"{LAVER_REV}:{source.as_posix()}", cwd=upstream) + "\n"
            if name == "Comparator.Statement":
                # Retain the original set-theoretic definitions. The next section starts
                # the unrelated Peano Arithmetic development, which imports Foundation.
                data = data.split("/-! ## Provable totality in Peano Arithmetic", 1)[0] + "\nend LaverTables\n"
                data = data.replace("import Foundation.FirstOrder.Arithmetic.Schemata", "")
            entry = compat.get(source.as_posix())
            if entry:
                lines = data.splitlines(keepends=True)
                for start, end, replacements in reversed(entry["changes"]):
                    lines[start:end] = replacements
                data = "".join(lines)
                if hashlib.sha256(data.encode()).hexdigest() != entry["sha256"]:
                    raise ValueError(f"Compatibility edit did not match {source}")
            local.parent.mkdir(parents=True, exist_ok=True)
            local.write_text(data)
        for dep in re.findall(r"^import ([\w.]+)", local.read_text(), re.M):
            if not dep.startswith("Mathlib"):
                compile_module(dep)
        print(f"Checking {name}", flush=True)
        flags = ["-DautoImplicit=false", "-DrelaxedAutoImplicit=false"] if upstream_module else []
        result = subprocess.run([lean, *flags, "-o", str(source.with_suffix(".olean")), str(source)],
                                cwd=work, env=env, capture_output=True, text=True)
        if result.returncode:
            raise RuntimeError(result.stdout + result.stderr)
        built.add(name)
    verify = [("BergerDisproof","OMA.disproof"), ("MeyerowitzDisproof","OMA.disproof"),
              ("VanNameSolution","OMA.solution")]
    for name, declaration in verify:
        compile_module(name)
        audit = work / "CheckAxioms.lean"
        audit.write_text(f"import {name}\n#print axioms {declaration}\n")
        result = output(lean, audit.name, cwd=work, env=env)
        print(result, flush=True)
        match = re.search(r"depends on axioms: \[([^\]]*)\]", result)
        if not match or not set(match[1].split(", ")).issubset(ALLOWED):
            raise RuntimeError(f"Unexpected axiom audit for {declaration}")
    for extra in ("EquivalentGraphCuts", "SemanticMenu"):
        compile_module(extra)
    print(f"Verified three exact statement types using {len(built)} source modules.", flush=True)

if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("formal_conjectures", type=Path, help="Pinned formal-conjectures checkout with Mathlib built")
    p.add_argument("laver_table", type=Path, help="Pinned frenzymath/LaverTable checkout")
    a = p.parse_args()
    with tempfile.TemporaryDirectory(prefix="rank-root-check-") as work:
        build(Path(work), a.formal_conjectures.resolve(), a.laver_table.resolve())

# Reproduce the three Lean results

The build checks the complete classification for Joseph Van Name's rank-into-rank embedding question, the disproof of Raphael Berger's proposed velocity-field classification, and the disproof of Aaron Meyerowitz's graph-tiling converse. The proof modules use the types of the three submitted Left To Solve statements. Upstream review of those translations is separate from kernel verification.

## Reproduce the check

Start with Python 3, Git, and Lean's elan toolchain manager on your PATH. Fetch the two repositories at these revisions, install the pinned toolchain and Mathlib cache, then run the script from the extracted archive. The script accepts absolute or relative checkout paths.

```sh
git clone https://github.com/google-deepmind/formal-conjectures
git -C formal-conjectures checkout 9097e2f90e66d2f6244209cb1c07f7120d17ec53
git clone https://github.com/frenzymath/LaverTable
git -C LaverTable checkout 1f5ee8c0f6dee8fe25f8971371ff6533dca0a707
(cd formal-conjectures && lake exe cache get)
python3 verify.py formal-conjectures LaverTable
```

The verifier creates an empty directory, compiles each relevant source module, and checks the axioms of each final declaration. All three use only `propext`, `Classical.choice`, and `Quot.sound`. `verification.log` records the successful fresh build on Lean 4.33.1. The OMAStatements files contain the statement placeholder required by the catalogue. Each submitted mathematical proof is checked independently of that placeholder, including its axiom dependencies.

## Read the result

* `src/VanNameSolution.lean` is the entry point for the rank-embedding classification. `SiteBridge` connects the standalone statement to the concrete mathematics. `CompleteClassification` assembles the three conclusions. `CanonicalFusion` and `RankwiseFusion` give the unrestricted construction. `FiniteTermShifts` and `FiniteCardinalRoots` give the finite-menu obstruction.
* `src/EquivalentGraphCuts.lean` and `src/SemanticMenu.lean` check two interpretation details in the rank-embedding question.
* `src/BergerDisproof.lean` and `src/MeyerowitzDisproof.lean` are the other two proof entry points.
* FrenzyMath's September 2026 [LaverTable formalization](https://github.com/frenzymath/LaverTable/tree/1f5ee8c0f6dee8fe25f8971371ff6533dca0a707) supplies the underlying facts about rank embeddings and Laver application. The verifier reads those sources from your pinned checkout. It applies the small Lean 4.33.1 changes in `dependency-compatibility.json` and omits the unrelated arithmetic section of `Comparator.Statement` from the build.

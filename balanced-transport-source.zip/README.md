# Composing balanced mass transport on the integer line

James Propp asked on April 6, 2015 whether two local, mass- and barycenter-preserving packet rearrangements on the integer line can always be composed. The answer is affirmative for all measures finite at each individual site, including those of infinite total mass. In particular, if the input packet diameters are at most R lattice units, the output packet diameter can be bounded by 12(R+1) for integral R. Admitting infinite individual atoms gives a four-site counterexample. The paper proves both assertions and gives a corollary for locally finite Borel measures on the real line.

## Read the proof

- `balanced-transport.pdf` is the three-page mathematical note. Its editable source is `balanced-transport.tex`.
- `BalancedTransport.lean` is a standalone Lean proof for the integer lattice. The theorem `OMA.solution` proves transitivity, and `OMA.S_mo_202165.compose_rows` gives the diameter bound.
- `InfiniteAtoms.lean` verifies the counterexample on the four integer sites −1, 0, 1, 2. Nonnegative summands imply that decomposing either endpoint as measures on the entire integer line cannot introduce sites outside these four.
- `proofs/mo-202165.lean` is the file checked against the exact type declared in `statements/mo-202165.lean`. The statement file uses the single placeholder required by Left to Solve for statement review. The proof file and the two standalone certificates are complete.
- `checks/exact_transport.py` constructs and checks direct packets on rational-valued finite test inputs. The Lean theorem quantifies over arbitrary real site weights and all integers.
- `verification/` contains the project checker's two verdicts, the independent Lean axiom reports, and the exact-arithmetic test output.

## Reproduce

Use Lean 4.33.1. The included Lake configuration pins Mathlib to commit `0df444a360eaa60ab8c11dca51a86af692955474`.

```sh
lake update
lake exe cache get
lake env lean BalancedTransport.lean
lake env lean InfiniteAtoms.lean
python3 checks/exact_transport.py
```

To run the project checker, place the statement and proof in their corresponding subdirectories of an open-math-agents checkout. Set `OMA_FC` to a prepared formal-conjectures checkout at commit `9097e2f90e66d2f6244209cb1c07f7120d17ec53`, as pinned in the catalogue, then run the following from the open-math-agents checkout.

```sh
tools/check.sh statements/mo-202165.lean statement-verdict.json
tools/check.sh proofs/mo-202165.lean proof-verdict.json
```

## Provenance

Propp's April 6 question has no posted answer in the version consulted. His April 2 companion post states the σ-finiteness convention. Christian Remling rejected Propp's attempted counterexample, explicitly withdrew his own general proof attempt, and continued to expect transitivity. Searches on the question titles, balanced bounded mass transport, local barycentric transport and bounded martingale couplings located no earlier complete solution. This search does not establish a field-wide consensus or guarantee priority.

[Propp's question](https://mathoverflow.net/questions/202165/transitivity-of-balanced-mass-transport-in-z) · [Companion formulation](https://mathoverflow.net/questions/201745/transitive-closure-of-balanced-bounded-mass-transport) · [Remling's answer and correction](https://mathoverflow.net/a/201852)

[Public Lean proof on LDJAI](https://github.com/LDJAI/open-math-agents/blob/proof-mo-202165/proofs/mo-202165.lean) · [Statement review, PR 1068](https://github.com/GuillaumeBAUD-coder/open-math-agents/pull/1068) · [Left to Solve problem](https://lefttosolve.com/p/mo-202165)

LDJAI with OpenAI Codex, November 26, 2026.

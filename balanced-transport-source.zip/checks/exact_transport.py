"""Construct and check Propp compositions for finite inputs, using exact rational arithmetic.

Run: python3 checks/exact_transport.py
The proof for arbitrary locally finite measures appears in BalancedTransport.lean.
"""
from collections import defaultdict
from fractions import Fraction as Q
import random


def clean(measure):
    return {x: weight for x, weight in measure.items() if weight}


def add(measures):
    out = defaultdict(Q)
    for factor, measure in measures:
        for x, mass in measure.items():
            out[x] += factor * mass
    return clean(out)


def moments(measure):
    return sum(measure.values(), Q()), sum((x * m for x, m in measure.items()), Q())


def prefix(rows, threshold):
    return add((1, row) for i, row in rows.items() if i <= threshold)


def blend_at(first, second, c, h):
    left = (c + h, c + 2*h, c + 5*h)
    right = (c, c + 3*h, c + 4*h)
    stats = []
    for j, (l, u) in enumerate(zip(left, right)):
        sign = -1 if j == 1 else 1
        gap = add([(sign, prefix(first, l)), (-sign, prefix(second, u))])
        assert all(m > 0 and c + 2*j*h < x < c + 2*(j+1)*h for x, m in gap.items())
        stats.append(moments(gap))
    masses, firsts = zip(*stats)
    if 0 in masses:
        selected = masses.index(0)
        weights = tuple(Q(j == selected) for j in range(3))
        mode = "zero"
    else:
        b0, b1, b2 = (z / m for m, z in stats)
        assert b0 < b1 < b2
        raw = ((b2 - b1) / masses[0], (b2 - b0) / masses[1], (b1 - b0) / masses[2])
        weights = tuple(x / sum(raw) for x in raw)
        mode = "three"
    assert sum(weights) == 1 and min(weights) >= 0
    for values in (masses, firsts):
        assert weights[0]*values[0] - weights[1]*values[1] + weights[2]*values[2] == 0
    return left, right, weights, mode


def mixed_prefix(rows, thresholds, weights):
    return add((w, prefix(rows, t)) for t, w in zip(thresholds, weights))


def compose(a, b, c_rows, d, r, s):
    """Paired inputs share row indices within each stage. Return certified direct packets."""
    for left, right, width in ((a, b, r), (c_rows, d, s)):
        for i in left.keys() | right.keys():
            v, w = left.get(i, {}), right.get(i, {})
            assert moments(v) == moments(w)
            assert all(i <= x <= i + width and mass >= 0 for row in (v, w) for x, mass in row.items())
    assert add((1, v) for v in b.values()) == add((1, v) for v in c_rows.values())
    ends = [x for rows in (a, d) for row in rows.values() for x in row]
    if not ends:
        return [], defaultdict(int)
    h = max(r, s) + 1
    length = 6*h
    low, high = min(ends) // length - 2, max(ends) // length + 1
    previous = None
    out = []
    modes = defaultdict(int)
    for k in range(low, high + 1):
        origin = k * length
        l, u, weights, mode = blend_at(b, c_rows, origin, h)
        modes[mode] += 1
        a_prefix = mixed_prefix(a, l, weights)
        d_prefix = mixed_prefix(d, u, weights)
        if previous is not None:
            old_a, old_d = previous
            v = add([(1, a_prefix), (-1, old_a)])
            w = add([(1, d_prefix), (-1, old_d)])
            assert all(m > 0 for row in (v, w) for m in row.values())
            assert moments(v) == moments(w)
            if v:
                assert all(origin-length <= x <= origin+length for x in v.keys() | w.keys())
                out.append((v, w))
        previous = a_prefix, d_prefix
    for index, rows in ((0, a), (1, d)):
        assert add((1, pair[index]) for pair in out) == add((1, row) for row in rows.values())
    return out, modes


def partition_columns(source, width, rng):
    rows = defaultdict(dict)
    for x, m in source.items():
        cuts = sorted([0, 17] + [rng.randrange(18) for _ in range(width)])
        for j in range(width + 1):
            share = m * Q(cuts[j+1] - cuts[j], 17)
            if share:
                rows[x-j][x] = share
    return dict(rows)


def rearrange(rows, width, rng):
    """Move a rational share of each atom to the row's two endpoints with the same mean."""
    if width == 0:
        return rows.copy()
    out = {}
    for i, row in rows.items():
        v = defaultdict(Q)
        for x, mass in row.items():
            share = Q(rng.randrange(8), 7)
            v[x] += mass * (1-share)
            v[i] += mass * share * Q(i+width-x, width)
            v[i+width] += mass * share * Q(x-i, width)
        out[i] = clean(v)
    return out


def main():
    rng = random.Random(202165)
    counts = defaultdict(int)
    tests = 0
    for r in range(4):
        for s in range(4):
            for pattern in range(3):
                middle = {}
                for x in range(-55, 79):
                    if pattern == 1 and x % 7 in (2, 3, 4):
                        continue
                    num = (abs(x)+1)**3 if pattern == 2 else rng.randrange(12)
                    if num:
                        middle[x] = Q(num, rng.randrange(1, 9))
                b = partition_columns(middle, r, rng)
                c = partition_columns(middle, s, rng)
                _, modes = compose(rearrange(b, r, rng), b, c, rearrange(c, s, rng), r, s)
                for mode, n in modes.items():
                    counts[mode] += n
                tests += 1
    assert compose({}, {}, {}, {}, 0, 0)[0] == []
    assert counts["zero"] > 0 and counts["three"] > 0
    print(f"{tests+1} endpoint and packet checks passed. Boundaries with a zero error: {counts['zero']}.")
    print(f"Boundaries with three nonzero errors: {counts['three']}. All arithmetic exact.")


if __name__ == "__main__":
    main()

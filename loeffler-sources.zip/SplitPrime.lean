import Mathlib.Data.ZMod.Basic
import Mathlib.Tactic.NormNum.Prime

/-! Concrete splitting certificate for the octic generator in Loeffler's question.
The chosen generator y satisfies ((y²+1)⁴ − 10(y²+1)² + 1) = 0.
All eight roots are simple since this monic polynomial has degree eight. -/
namespace LoefflerSplit

def roots : List (ZMod 1609) := [549,-549,664,-664,722,-722,33,-33]

def octic {R : Type*} [CommRing R] (y : R) : R := (y^2+1)^4 - 10*(y^2+1)^2 + 1

theorem primeCertificate : Nat.Prime 1609 := by norm_num

theorem rootsCertificate :
    roots.Nodup ∧ roots.length = 8 ∧ roots.all (fun z => decide (octic z = 0)) = true := by
  decide

#print axioms primeCertificate
#print axioms rootsCertificate

end LoefflerSplit

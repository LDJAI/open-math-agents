import LoeCharacters
import SplitPrime
#print axioms LoeUnits.universal_char_minor
#print axioms LoefflerSplit.primeCertificate
#print axioms LoefflerSplit.rootsCertificate

import LoefflerDisproof
#print axioms OMA.disproof
#print axioms Loeffler.exact_minor

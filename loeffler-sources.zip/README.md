# Reproduce Loeffler’s regulator counterexample

The single-file proof is LoefflerDisproof.lean. It begins with the proposed catalogue statement module and then imports only Mathlib modules. The proof file passes the catalogue’s proof linter when checked with the proposed statement present. The statement contains the one placeholder required by the catalogue. The final proof uses only propext, Classical.choice and Quot.sound, as logged in single-file-audit.log.

A clean build uses Lean 4.33.1 from the following pinned checkout of formal-conjectures. Install Python 3, Git and the elan toolchain manager, then run these commands beside verify.py.

```sh
git clone https://github.com/google-deepmind/formal-conjectures
git -C formal-conjectures checkout 9097e2f90e66d2f6244209cb1c07f7120d17ec53
(cd formal-conjectures && lake exe cache get)
python3 verify.py formal-conjectures
```

OMA.disproof refutes the full proposed statement for a concrete octic number field. Loeffler.exact_minor constructs a singular maximal minor at each prime using the explicit logarithm series on algebraic units. LoeUnits.universal_char_minor proves a separate structural result for all unit bases and all logarithmic characters. SplitPrime.lean checks that 1609 is prime and verifies all eight roots modulo that prime of the explicitly specified radical field’s monic octic polynomial. The two fields and their distinct roles are explained in the research note. The six-of-seventy exact count for the radical field is a proof in ordinary mathematics.

[Original question](https://mathoverflow.net/questions/119202/variant-of-leopoldts-conjecture) · [Left To Solve listing](https://lefttosolve.com/p/mo-119202) · [LDJAI research note](https://github.com/LDJAI/open-math-agents/blob/research/constructive-counterexamples-20261126/Loeffler.md)

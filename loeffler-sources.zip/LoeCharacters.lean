import LoefflerColumns
import LoefflerEmbeddings
import LoeUnits

open NumberField Module

namespace LoeUnits
noncomputable section
variable {F K L : Type*} [Field F] [NumberField F] [Field K] [NumberField K] [Field L] [CharZero L]

/-- Independent of the basis of units and of the choice of logarithmic character. -/
theorem char_minor (ℓ : Lˣ →* Multiplicative L) (f : F →+* K)
    (bF : Basis (Fin 3) ℤ (FreeUnits F)) (bK : Basis (Fin 4) ℤ (FreeUnits K))
    (s : Fin 4 → (K →+* L))
    (h01 : ∀ x : F, s 0 (f x) = s 1 (f x)) (h23 : ∀ x : F, s 2 (f x) = s 3 (f x)) :
    (Matrix.of fun i j => evalChar ℓ (s i) (bK j)).det = 0 := by
  let M : Matrix (Fin 4) (Fin 4) L := Matrix.of fun i j => evalChar ℓ (s i) (bK j)
  let C := coeff L f bF bK
  have paired (i k : Fin 4) (h : ∀ x : F, s i (f x) = s k (f x)) (j : Fin 3) :
      (M*C) i j = (M*C) k j := by
    change (Matrix.of (fun i t => evalChar ℓ (s i) (bK t)) * coeff L f bF bK) i j =
      (Matrix.of (fun i t => evalChar ℓ (s i) (bK t)) * coeff L f bF bK) k j
    rw [eval_mul_coeff, eval_mul_coeff, evalChar_restrict, evalChar_restrict]
    exact congrArg (fun v : F →+* L => evalChar ℓ v (bF j)) (RingHom.ext h)
  exact LoefflerMinor.paired_columnAnn M C (coeff_independent L f bF bK) (paired 0 1 h01) (paired 2 3 h23)

/-- The obstruction holds simultaneously for every logarithmic character and every
fundamental system of global units. The four embedding rows depend only on the tower. -/
theorem universal_char_minor [Algebra F K] [FiniteDimensional F K] [IsAlgClosed L]
    (hdeg : 2 ≤ Module.finrank ℚ F) (hrel : Module.finrank F K = 2)
    (hF : NumberField.Units.rank F = 3) :
    ∃ s : Fin 4 ↪ (K →+* L),
      ∀ (ℓ : Lˣ →* Multiplicative L) (u : Fin 4 → (𝓞 K)ˣ)
        (b : Basis (Fin 4) ℤ (FreeUnits K)),
        (∀ j, Additive.ofMul (QuotientGroup.mk (u j) : (𝓞 K)ˣ ⧸ NumberField.Units.torsion K) = b j) →
        (Matrix.of fun i j => (ℓ (embUnit (s i) (u j))).toAdd).det = 0 := by
  obtain ⟨s,hs,ht⟩ := LoefflerEmbeddings.four_embeddings F K L hdeg hrel
  refine ⟨s, fun ℓ u b hu => ?_⟩
  have hz := char_minor ℓ (algebraMap F K)
    ((NumberField.Units.basisModTorsion F).reindex (finCongr hF)) b s hs ht
  simpa only [← hu, evalChar_mk] using hz

end
end LoeUnits

#print axioms LoeUnits.universal_char_minor

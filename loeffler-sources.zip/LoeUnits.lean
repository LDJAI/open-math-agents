import Mathlib.NumberTheory.NumberField.Units.DirichletTheorem
import Mathlib.LinearAlgebra.LinearIndependent.BaseChange
import Mathlib.Data.Matrix.Mul

open NumberField Module
open scoped Matrix

namespace LoeUnits
noncomputable section
variable {F K : Type*} [Field F] [Field K] [NumberField F] [NumberField K]

abbrev FreeUnits (E : Type*) [Field E] [NumberField E] :=
  Additive ((𝓞 E)ˣ ⧸ NumberField.Units.torsion E)

instance (E : Type*) [Field E] [NumberField E] : AddCommGroup (FreeUnits E) :=
  inferInstanceAs (AddCommGroup (Additive ((𝓞 E)ˣ ⧸ NumberField.Units.torsion E)))

instance (E : Type*) [Field E] [NumberField E] : Module ℤ (FreeUnits E) :=
  inferInstanceAs (Module ℤ (Additive ((𝓞 E)ˣ ⧸ NumberField.Units.torsion E)))

def mapUnits (f : F →+* K) : (𝓞 F)ˣ →* (𝓞 K)ˣ :=
  _root_.Units.map (RingOfIntegers.mapRingHom f).toMonoidHom

theorem mapUnits_injective (f : F →+* K) : Function.Injective (mapUnits f) := by
  intro x y h
  apply _root_.Units.ext
  apply Subtype.ext
  apply f.injective
  exact congrArg (fun z : (𝓞 K)ˣ => ((z : 𝓞 K) : K)) h

theorem mapUnits_mem_torsion_iff (f : F →+* K) (u : (𝓞 F)ˣ) :
    mapUnits f u ∈ NumberField.Units.torsion K ↔ u ∈ NumberField.Units.torsion F := by
  change IsOfFinOrder (mapUnits f u) ↔ IsOfFinOrder u
  constructor
  · rw [isOfFinOrder_iff_pow_eq_one, isOfFinOrder_iff_pow_eq_one]
    rintro ⟨n, hn, hu⟩
    exact ⟨n, hn, mapUnits_injective f (by simpa using hu)⟩
  · exact (mapUnits f).isOfFinOrder

def freeMapMul (f : F →+* K) :
    ((𝓞 F)ˣ ⧸ NumberField.Units.torsion F) →* ((𝓞 K)ˣ ⧸ NumberField.Units.torsion K) :=
  QuotientGroup.map _ _ (mapUnits f) (fun _ hu => (mapUnits_mem_torsion_iff f _).2 hu)

def freeMap (f : F →+* K) : FreeUnits F →ₗ[ℤ] FreeUnits K :=
  (freeMapMul f).toAdditive.toIntLinearMap

theorem freeMap_injective (f : F →+* K) : Function.Injective (freeMap f) := by
  suffices Function.Injective (freeMapMul f) from this
  apply (MonoidHom.ker_eq_bot_iff _).1
  apply le_antisymm _ bot_le
  intro q hq
  obtain ⟨u, rfl⟩ := QuotientGroup.mk'_surjective (NumberField.Units.torsion F) q
  apply (Subgroup.mem_bot).2
  apply (QuotientGroup.eq_one_iff u).2
  apply (mapUnits_mem_torsion_iff f u).1
  apply (QuotientGroup.eq_one_iff _).1
  exact hq

variable {ι κ ν : Type*} [Fintype ι] [Fintype κ] [DecidableEq κ]
variable (L : Type*) [Field L] [CharZero L]
variable (f : F →+* K) (bF : Basis ι ℤ (FreeUnits F)) (bK : Basis κ ℤ (FreeUnits K))

def coeff : Matrix κ ι L := fun i j => (bK.equivFun (freeMap f (bF j)) i : ℤ)

theorem coeff_independent :
    LinearIndependent L (fun j i => coeff L f bF bK i j) := by
  let v : ι → κ → ℤ := fun j => bK.equivFun (freeMap f (bF j))
  change LinearIndependent L (fun j => algebraMap ℤ L ∘ v j)
  apply linearIndependent_algebraMap_comp_iff.mpr
  apply bF.linearIndependent.map' (bK.equivFun.toLinearMap.comp (freeMap f))
  apply LinearMap.ker_eq_bot_of_injective
  exact bK.equivFun.injective.comp (freeMap_injective f)

theorem eval_mul_coeff (ev : ν → FreeUnits K →ₗ[ℤ] L) (q : ν) (j : ι) :
    (Matrix.of (fun i k => ev i (bK k)) * coeff L f bF bK) q j =
      ev q (freeMap f (bF j)) := by
  rw [Matrix.mul_apply]
  conv_rhs => rw [← bK.sum_repr (freeMap f (bF j)), map_sum]
  apply Finset.sum_congr rfl
  intro i _
  simp [coeff, zsmul_eq_mul, mul_comm, Matrix.of_apply]

end
end LoeUnits

namespace LoeUnits
noncomputable section
open NumberField
variable {F K L : Type*} [Field F] [Field K] [NumberField F] [NumberField K]
variable [Field L] [CharZero L]

/-- The image of an integral unit under an embedding, viewed in the field's unit group. -/
def embUnit (σ : K →+* L) : (𝓞 K)ˣ →* Lˣ :=
  _root_.Units.map (σ.comp (algebraMap (𝓞 K) K)).toMonoidHom

def charQuot (ℓ : Lˣ →* Multiplicative L) (σ : K →+* L) :
    ((𝓞 K)ˣ ⧸ NumberField.Units.torsion K) →* Multiplicative L :=
  QuotientGroup.lift _ (ℓ.comp (embUnit σ)) (by
    intro x hx
    change (ℓ.comp (embUnit σ)) x = 1
    apply (isOfFinOrder_iff_eq_one _).mp
    exact (ℓ.comp (embUnit σ)).isOfFinOrder hx)

def evalChar (ℓ : Lˣ →* Multiplicative L) (σ : K →+* L) : FreeUnits K →ₗ[ℤ] L :=
  (MonoidHom.toAdditiveLeft (charQuot ℓ σ)).toIntLinearMap

@[simp] theorem evalChar_mk (ℓ : Lˣ →* Multiplicative L) (σ : K →+* L) (u : (𝓞 K)ˣ) :
    evalChar ℓ σ (Additive.ofMul ((QuotientGroup.mk u : (𝓞 K)ˣ ⧸ NumberField.Units.torsion K))) =
      (ℓ (embUnit σ u)).toAdd := rfl

theorem evalChar_restrict (ℓ : Lˣ →* Multiplicative L) (σ : K →+* L) (f : F →+* K)
    (x : FreeUnits F) :
    evalChar ℓ σ (freeMap f x) = evalChar ℓ (σ.comp f) x := by
  obtain ⟨u, hu⟩ := QuotientGroup.mk'_surjective (NumberField.Units.torsion F) x.toMul
  have h : Additive.ofMul ((QuotientGroup.mk u : (𝓞 F)ˣ ⧸ NumberField.Units.torsion F)) = x := hu
  subst x
  rfl

end
end LoeUnits

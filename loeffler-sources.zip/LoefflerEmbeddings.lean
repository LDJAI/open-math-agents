import Mathlib.Algebra.Algebra.Rat
import Mathlib.FieldTheory.PrimitiveElement
import Mathlib.Data.Fin.VecNotation
import Mathlib.Tactic.FinCases

/-! Duplicate restrictions in a tower of finite separable extensions. -/

namespace LoefflerEmbeddings

variable (F K Ω : Type*) [Field F] [CharZero F] [Field K] [Algebra F K]
    [FiniteDimensional F K] [Field Ω] [CharZero Ω] [IsAlgClosed Ω]

private theorem two_extensions (f : F →ₐ[ℚ] Ω) (hd : 2 ≤ Module.finrank F K) :
    ∃ a b : K →+* Ω, a ≠ b ∧
      (∀ x, a (algebraMap F K x) = f x) ∧ (∀ x, b (algebraMap F K x) = f x) := by
  let : Algebra F Ω := f.toRingHom.toAlgebra
  have hn : 1 < Fintype.card (K →ₐ[F] Ω) := by
    rw [AlgHom.card F K Ω]
    exact hd
  obtain ⟨a, b, hab⟩ := Fintype.one_lt_card_iff.mp hn
  refine ⟨a.toRingHom, b.toRingHom, ?_, fun x => a.commutes x, fun x => b.commutes x⟩
  intro he
  exact hab (AlgHom.ext fun x => DFunLike.congr_fun he x)

theorem four_embeddings [FiniteDimensional ℚ F] (hF : 2 ≤ Module.finrank ℚ F)
    (hK : Module.finrank F K = 2) :
    ∃ σ : Fin 4 ↪ (K →+* Ω),
      (∀ x : F, σ 0 (algebraMap F K x) = σ 1 (algebraMap F K x)) ∧
      (∀ x : F, σ 2 (algebraMap F K x) = σ 3 (algebraMap F K x)) := by
  classical
  have hn : 1 < Fintype.card (F →ₐ[ℚ] Ω) := by
    rw [AlgHom.card ℚ F Ω]
    exact hF
  obtain ⟨f, g, hfg⟩ := Fintype.one_lt_card_iff.mp hn
  obtain ⟨a, b, hab, ha, hb⟩ := two_extensions F K Ω f hK.ge
  obtain ⟨c, d, hcd, hc, hd⟩ := two_extensions F K Ω g hK.ge
  have separate (u v : K →+* Ω)
      (hu : ∀ x, u (algebraMap F K x) = f x)
      (hv : ∀ x, v (algebraMap F K x) = g x) : u ≠ v := by
    rintro rfl
    exact hfg (AlgHom.ext fun x => (hu x).symm.trans (hv x))
  have hac := separate a c ha hc
  have had := separate a d ha hd
  have hbc := separate b c hb hc
  have hbd := separate b d hb hd
  let family : Fin 4 → (K →+* Ω) := ![a,b,c,d]
  have hinj : Function.Injective family := by
    intro i j hij
    fin_cases i <;> fin_cases j <;> first
      | rfl
      | exact False.elim (hab hij)
      | exact False.elim (hab.symm hij)
      | exact False.elim (hac hij)
      | exact False.elim (hac.symm hij)
      | exact False.elim (had hij)
      | exact False.elim (had.symm hij)
      | exact False.elim (hbc hij)
      | exact False.elim (hbc.symm hij)
      | exact False.elim (hbd hij)
      | exact False.elim (hbd.symm hij)
      | exact False.elim (hcd hij)
      | exact False.elim (hcd.symm hij)
  refine ⟨⟨family, hinj⟩, fun x => (ha x).trans (hb x).symm,
    fun x => (hc x).trans (hd x).symm⟩

end LoefflerEmbeddings
#print axioms LoefflerEmbeddings.four_embeddings

"""Recheck the proof and auxiliary theorems in a clean directory with the pinned Mathlib."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
from tempfile import TemporaryDirectory

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("formal_conjectures", type=Path, help="Pinned checkout with Mathlib cache installed")
fc = parser.parse_args().formal_conjectures.resolve()
rev = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=fc, text=True).strip()
if rev != "9097e2f90e66d2f6244209cb1c07f7120d17ec53":
    raise SystemExit("Checkout of formal-conjectures does not match the pin in README.md")
def lake(*args):
    return subprocess.check_output(["lake","env",*args], cwd=fc, text=True).strip()
lean = lake("which","lean")
paths = [str((fc / p).resolve()) for p in lake("printenv","LEAN_PATH").split(os.pathsep) if p]
with TemporaryDirectory(prefix="loeffler-check-") as tmp:
    work = Path(tmp)
    shutil.copytree(root, work, dirs_exist_ok=True)
    env = {**os.environ, "LEAN_PATH":os.pathsep.join([tmp]+paths)}
    modules = ["OMAStatements/S_mo_119202","LoefflerDisproof","LoefflerEmbeddings","LoeUnits",
               "LoefflerColumns","LoeCharacters","SplitPrime"]
    for module in modules:
        print("Checking",module,flush=True)
        subprocess.run([lean,"-o",module+".olean",module+".lean"],cwd=work,env=env,check=True)
    for audit in ("Audit.lean","AuditExtras.lean"):
        result = subprocess.check_output([lean,audit],cwd=work,env=env,text=True)
        print(result,end="")
        for line in result.splitlines():
            if "depends on axioms: [" in line:
                assumptions = set(line.partition("depends on axioms: [")[2].removesuffix("]").split(", "))
                if not assumptions <= {"Classical.choice", "propext", "Quot.sound"}:
                    raise RuntimeError(line)

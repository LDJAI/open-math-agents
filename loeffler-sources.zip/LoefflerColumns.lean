import Mathlib.LinearAlgebra.Matrix.NonsingularInverse
import Mathlib.LinearAlgebra.Matrix.ToLin
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.NormNum

namespace LoefflerMinor

/-- If the logarithms of three independent subfield units form two equal pairs among
four rows, the restriction to those four embeddings is singular, in any unit basis. -/
theorem paired_columnAnn {L : Type*} [Field L] (M : Matrix (Fin 4) (Fin 4) L)
    (C : Matrix (Fin 4) (Fin 3) L)
    (hC : LinearIndependent L (fun j i => C i j))
    (h01 : ∀ j, (M*C) 0 j = (M*C) 1 j)
    (h23 : ∀ j, (M*C) 2 j = (M*C) 3 j) : M.det = 0 := by
  by_contra hn
  let p : Fin 4 → Fin 2 := ![0, 0, 1, 1]
  let dup : (Fin 2 → L) →ₗ[L] (Fin 4 → L) :=
    { toFun := fun v i => v (p i)
      map_add' := fun _ _ => rfl
      map_smul' := fun _ _ => rfl }
  let two : Fin 3 → Fin 2 → L := fun j => ![(M*C) 0 j, (M*C) 2 j]
  have hi : Function.Injective M.mulVecLin :=
    Matrix.mulVec_injective_of_isUnit (M.isUnit_iff_isUnit_det.mpr (isUnit_iff_ne_zero.mpr hn))
  have hm := hC.map' M.mulVecLin (LinearMap.ker_eq_bot.mpr hi)
  have eqn : (dup ∘ two) = (M.mulVecLin ∘ fun j i => C i j) := by
    funext j i
    change (two j) (p i) = (M*C) i j
    fin_cases i
    · rfl
    · exact h01 j
    · rfl
    · exact h23 j
  have ht : LinearIndependent L two := by
    apply LinearIndependent.of_comp dup
    rwa [eqn]
  have hdim := ht.fintype_card_le_finrank
  simp at hdim

#print axioms paired_columnAnn
end LoefflerMinor

// Read the decompressed certificate on stdin. All arithmetic comparisons are exact.
#include <gmpxx.h>
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <utility>
#include <vector>
using Z = mpz_class;
struct Interval { unsigned lo, hi; };
using Rows = std::vector<std::vector<Interval>>;
static void require(bool ok, const char *msg) { if (!ok) throw std::runtime_error(msg); }
static Z choose(unsigned long n, unsigned long k) {
    Z out;
    mpz_bin_uiui(out.get_mpz_t(),n,k);
    return out;
}
static Z power(unsigned base, unsigned exponent) {
    Z out;
    mpz_ui_pow_ui(out.get_mpz_t(),base,exponent);
    return out;
}
static std::vector<unsigned> primes(unsigned max) {
    std::vector<bool> prime(max+1,true);
    std::vector<unsigned> ps;
    for (unsigned p=2;p<=max;++p) {
        if (!prime[p]) continue;
        ps.push_back(p);
        if (p<=max/p) for (unsigned i=p*p;i<=max;i+=p) prime[i]=false;
    }
    return ps;
}
static Z range_lcm(unsigned lo,unsigned hi,const std::vector<unsigned>& ps) {
    Z v=1;
    for (auto p : ps) {
        if (p>hi) break;
        unsigned pe=p;
        while (pe<=hi && hi/pe>(lo-1)/pe) {
            v*=p;
            if (pe>hi/p) break;
            pe*=p;
        }
    }
    return v;
}
int main() {
    const unsigned last=9999;
    auto ps=primes(26*last+1);
    Rows rows(last+1);
    char t;
    std::uint64_t leaves=0,individual=0,pairs=0;
    while (std::cin>>t) {
        ++leaves;
        if (t=='P') {
            unsigned k,d; long n;
            require(bool(std::cin>>k>>d>>n),"incomplete pair");
            require(2<=k && k<=last && k<=d && d<=25*k && n>=-1,"pair out of range");
            const auto delta = [k,d](unsigned long x)->Z {
                return choose(x+d+k,k)-25*choose(x+k,k);
            };
            if (n==-1) require(delta(0)<0,"failed start-zero test");
            else require(delta(n)>0 && delta(n+1)<0,"failed exact crossing");
            rows[k].push_back({d,d});
            ++individual;
            continue;
        }
        unsigned a,b,f,g;
        require(bool(std::cin>>a>>b>>f>>g),"incomplete rectangle");
        require(2<=a && a<=b && b<=last && 1<=f && f<=g && g<=25*last,"bad rectangle");
        auto n=std::max(0L,(4L*(a/8)*f-b-1)/2);
        const unsigned upper=g+b-1;
        if (t=='A') {
            auto c=(16*upper+2*a-2)/(2*a-1);
            require(power(1+n/b,a)>power(c,2*b-1),"failed coarse comparison");
        } else {
            require(t=='B'||t=='C',"unknown leaf");
            Z L=range_lcm(f<b ? 1 : f-b+1,upper,ps);
            Z lower=(t=='B') ? power(1+n/b,a) : a*choose(n+a,a);
            require(lower>L,"failed exact LCM comparison");
        }
        for (unsigned k=a;k<=b;++k) {
            unsigned l=std::max(f,k), h=std::min(g,25*k);
            if (l<=h) rows[k].push_back({l,h});
        }
    }
    for (unsigned k=2;k<=last;++k) {
        auto &row=rows[k];
        std::sort(row.begin(),row.end(),[](const Interval&a,const Interval&b){return a.lo<b.lo;});
        unsigned next=k;
        for (auto seg:row) {
            require(seg.lo==next,"gap or overlap");
            pairs+=seg.hi-seg.lo+1;
            next=seg.hi+1;
        }
        require(next==25*k+1,"incomplete row");
    }
    std::cout<<"Exact replay passed. Rectangles and individual leaves "<<leaves
        <<", bracketed pairs "<<individual<<", distinct (k,d) pairs covered "<<pairs<<"\n";
}

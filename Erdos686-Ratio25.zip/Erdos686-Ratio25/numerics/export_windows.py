"""Record the leaves of the finite proof, plus the two bracket starts at surviving pairs."""
from pathlib import Path
import gzip,sys
import window_boxes as s
from math import comb,expm1,log
base=Path(__file__).parent
with gzip.open(base/'window-certificate.txt.gz','wt',compresslevel=6) as out:
    original=s.maybe
    def maybe(a,b,f,g,exact=False):
        old=dict(s.stats); yes=original(a,b,f,g,exact)
        if not yes:
            code=next(k for k in s.stats if s.stats[k]!=old.get(k,0))
            out.write(f"{ {'coarse cells':'A','LCM cells':'B','binomial cells':'C'}[code]} {a} {b} {f} {g}\n")
        return yes
    def pair(k,d):
        u=max(0,int(d/expm1(log(25)/k)-(k+1)/2))
        def delta(x):return comb(x+d+k,k)-25*comb(x+k,k)
        while u>0 and delta(u)<0:u-=1
        if u==0 and delta(0)<0:u=-1
        else:
            while delta(u+1)>0:u+=1
            assert delta(u)>0>delta(u+1)
        out.write(f'P {k} {d} {u}\n')
    s.maybe=maybe
    s.pair=pair
    s.main()

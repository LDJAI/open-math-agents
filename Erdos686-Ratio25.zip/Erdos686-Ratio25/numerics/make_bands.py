"""Build interval certificates. Every signed polynomial test uses integers."""
from fractions import Fraction
from decimal import Decimal, localcontext
from math import prod
from functools import lru_cache
from pathlib import Path
import sys, json, time
def mul_lin(poly,a,b):
    return [a*poly[0]]+[a*y+b*x for x,y in zip(poly,poly[1:])]+[b*poly[-1]]
def factors(z,p,q,k):
    poly=[1]
    for i in range(1,k+1):
        poly=mul_lin(poly,z+i*q,p)
    return poly
def lower(poly,w,s):
    bound=0
    for v in reversed(poly):
        bound=s*v+min(0,w*bound)
    return bound
def band(k,a,b,alpha):
    limits=[max(1,a//(2**j)) for j in range(a.bit_length()+1)]
    choices={alpha.limit_denominator(limit) for limit in limits}
    frac=min(choices,key=lambda r:abs(alpha*r.denominator-r.numerator)*(b-a)
             +Fraction(k*r.denominator,3*a))
    p,q=frac.numerator,frac.denominator
    @lru_cache(4000)
    def base(x,d):
        return factors(q*x,d*q,q,k)
    @lru_cache(4000)
    def poly(x,j,d):
        return [u-25*v for u,v in zip(factors(p*x+j,d*p,q,k),base(x,d))]
    def ok(x,y,j,s):
        return lower(poly(x,j,1),y-x,s)>0 or lower(poly(y,j,-1),y-x,s)>0
    def val(n,j):
        return prod(p*n+j+i*q for i in range(1,k+1))-25*prod(q*(n+i) for i in range(1,k+1))
    def root(n):
        lo=-p*n; hi=q*25*(n+k)+1
        while hi-lo>1:
            mid=(hi+lo)//2
            if val(n,mid)<0:lo=mid
            else:hi=mid
        return lo
    ja,jb=root(a),root(b)
    lo,hi=min(ja,jb),max(ja,jb)+2
    while not ok(a,b,lo,-1):lo-=1
    while not ok(a,b,hi,+1):hi+=1
    assert p*a+lo>=0
    def make_splits(x,y,j):
        if ok(x,y,j,1) or ok(x,y,j,-1):return []
        if x==y:
            raise ArithmeticError((k,x,j,p,q,'exact rational upper root'))
        z=(x+y)//2
        if val(x,j)*val(y,j)<0:
            left=x;right=y; sign=val(x,j)>0
            while right-left>1:
                mid=(left+right)//2
                if (val(mid,j)>0)==sign: left=mid
                else:right=mid
            z=left
        return make_splits(x,z,j)+[z]+make_splits(z+1,y,j)
    cuts=[make_splits(a,b,j) for j in range(lo+1,hi)]
    return [k,a,b,p,q,lo,cuts]
def run(k,t,place,first=100):
    out=[]
    with localcontext() as ctx:
        ctx.prec=max(120,2*len(str(t))+20)
        alpha=Fraction(Decimal(25)**(Decimal(1)/k))
    a=first
    while a<t:
        b=min(2*a-1,t-1)
        out.append(band(k,a,b,alpha));a=b+1
    place.write_text(json.dumps(out))
    return out
if __name__=='__main__':
    dest=Path(__file__).parent
    heights={int(k):int(t) for k,t,_ in (row.split() for row in (dest/'heights.tsv').read_text().splitlines()[1:])}
    for arg in sys.argv[1:]:
        k=int(arg)
        entries=run(k,heights[k],dest/'bands'/f'band{k}.json')
        print(k,len(entries),'bands;',sum(len(j[-1]) for j in entries),'intercepts;',sum(len(c) for j in entries for c in j[-1]),'splits',flush=True)

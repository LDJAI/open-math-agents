"""Exhaust k<10000, k<=d<=25k, using integer upper bounds for a common LCM.
No floating point assumption is needed for coverage or comparison."""
from math import comb, prod, lcm, gcd, log, expm1
from collections import Counter
from pathlib import Path
from functools import lru_cache
import sys, time, json
stats=Counter()
@lru_cache(maxsize=32768)
def lc_chunk(j):
    return lcm(*range(64*j+1,64*j+65))
@lru_cache(maxsize=4096)
def mid_lcm(j,num):
    if num==1: return lc_chunk(j)
    return lcm(mid_lcm(j,num//2),mid_lcm(j+num//2,num//2))
def window_lcm(lo,hi):
    lo=max(1,lo)
    j=(lo+62)//64
    b=hi//64
    if b<=j:return lcm(*range(lo,hi+1))
    v=lcm(*range(lo,64*j+1),*range(64*b+1,hi+1))
    while j<b:
        h=1<<((b-j).bit_length()-1)
        v=lcm(v,mid_lcm(j,h));j+=h
    return v
def maybe(a,b,f,g,exact=False):
    # 2*n+k+1 > 4*floor(k/8)*d, as proved in Center.lean.
    n=max(0,(4*(a//8)*f-b-1)//2)
    low=(1+n//b)**a
    w=2*b-1
    high=g+b-1
    c=(16*high+2*a-2)//(2*a-1)
    if low>c**w:
        stats['coarse cells']+=1;return False
    upper=window_lcm(f-b+1,g+b-1)
    if low>upper:
        stats['LCM cells']+=1;return False
    if comb(n+a,a)*a>upper:
        stats['binomial cells']+=1;return False
    return True
def pair(k,d):
    stats['individual pairs']+=1
    # Only a hint: both final inequalities are checked with exact integers.
    u=max(0,int(d/expm1(log(25)/k)-(k+1)/2))
    def sign(n):
        return comb(n+d+k,k)-25*comb(n+k,k)
    v=sign(u)
    if v==0:raise Exception(('WITNESS',k,d,u,u+d))
    if v<0:
        while u>0:
            u-=1
            v=sign(u)
            if v==0:raise Exception(('WITNESS',k,d,u,u+d))
            if v>0:break
        else:
            stats['already below at zero']+=1;return
    while True:
        t=sign(u+1)
        if t==0:raise Exception(('WITNESS',k,d,u+1,u+1+d))
        if t<0:break
        u+=1
    stats['strict crossing']+=1
def investigate(a,b,f,g):
    if g<a or 25*b<f:return
    if not maybe(a,b,f,g):return
    if b>a and (b-a>=1 and ((b-a)*12>=g-f or g-f<20)):
        m=(a+b)//2
        investigate(a,m,f,g);investigate(m+1,b,f,g);return
    if g-f>=max(8,a//3):
        m=(f+g)//2
        investigate(a,b,f,m);investigate(a,b,m+1,g);return
    if b>a:
        m=(a+b)//2
        investigate(a,m,f,g);investigate(m+1,b,f,g);return
    for d in range(max(f,a),min(g,25*a)+1):
        pair(a,d)
def main():
    first=int(sys.argv[1]) if len(sys.argv)>1 else 2
    last=int(sys.argv[2]) if len(sys.argv)>2 else 9999
    a=first
    while a<=last:
        b=min(last,a+max(1,a//20)-1)
        investigate(a,b,a,25*b)
        a=b+1
    print(json.dumps(dict(stats),sort_keys=True))
    print('No witness for every k between',first,'and',last,'inclusive, k <= d <= 25*k, every n.')
if __name__=='__main__':main()

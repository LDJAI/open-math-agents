#include <gmpxx.h>
#include <iostream>
#include <vector>
#include <numeric>
#include <algorithm>
#include <cstdlib>
#include <chrono>
#include <set>
#include <cassert>
using namespace std;
using Z=mpz_class;
Z pw(const Z&x,unsigned k){Z r; mpz_pow_ui(r.get_mpz_t(),x.get_mpz_t(),k);return r;}
Z gcdz(const Z&a,const Z&b){Z x;mpz_gcd(x.get_mpz_t(),a.get_mpz_t(),b.get_mpz_t());return x;}
Z lcmz(const Z&a,const Z&b){Z x;mpz_lcm(x.get_mpz_t(),a.get_mpz_t(),b.get_mpz_t());return x;}
Z sqrtz(const Z&a){Z x;mpz_sqrt(x.get_mpz_t(),a.get_mpz_t());return x;}
Z rootz(const Z&a,unsigned k){Z x;mpz_root(x.get_mpz_t(),a.get_mpz_t(),k);return x;}
Z f(const Z&x,unsigned k){Z p=1;for(unsigned i=1;i<=k;i++)p*=x+(long)(2*i)-(long)k-1;return p;}
Z M(const Z&n,unsigned k){Z p=1;for(unsigned i=1;i<=k;i++)p=lcmz(p,n+i);return p;}

struct Frac{Z p,q,err;};
vector<Z> cf(const Z&N,const Z&D){Z n=N,d=D;vector<Z>a;while(d>0){a.push_back(n/d);Z r=n%d;n=d;d=r;}return a;}

unsigned long long tested=0, candidates=0, rat=0, product_hits=0, below_first_possible=0;
bool first_only=false;
bool check(const Z&a,const Z&b, const Z&err, const Z&u,const Z&V,
 const Z&A,const Z&B,unsigned k,unsigned long E1,unsigned long C,
 const Z&Xmax,unsigned long Xmin){
 if(b<=0||b>Xmax||a<=b)return false;
 // alpha in [u/V,(u+1)/V], error_lower=ub-Va
 if(err+b<=0)return false;
 Z gmin=(Xmin+b-1)/b;if(gmin<1)gmin=1;
 if(err>0&&err*b*gmin*gmin>=V*C)return false;
 ++candidates;
 Z D0=A*pw(b,k)-B*pw(a,k);if(D0<=0)return false;
 Z D1=A*pw(b,k-2)-B*pw(a,k-2);assert(D1>0);
 Z top=(E1*D1)/D0;
 // if a solution exists, g² in [E1D1/D0 - 2E1/b², E1D1/D0]
 Z low=top-(2*E1)/(b*b)-1; if(low<1)low=1;
 Z gmax=sqrtz(top); if(gmax<gmin)return false;
 Z xmaxg=Xmax/b;if(gmax>xmaxg)gmax=xmaxg;
 Z glo=sqrtz(low);if(glo*glo<low)++glo;if(glo<gmin)glo=gmin;
 for(Z g=glo;g<=gmax;++g){
  Z x=b*g,y=a*g;if(y-x<2*k)continue;
  if((x-k-1)%2!=0||(y-k-1)%2!=0)continue;
  ++tested;
  if(B*f(y,k)==A*f(x,k)){
     ++product_hits;Z n=(x-k-1)/2,m=(y-k-1)/2;
     cerr<<"PRODUCT HIT k="<<k<<" n="<<n<<" m="<<m<<" ratio="<<A<<"/"<<B<<"\n";
     return true;
  }
 }
 return false;
}

bool solve(const Z&A,const Z&B,unsigned k,unsigned D,unsigned long Xmin){
 ++rat;
 Z Xmax=2*pw(Z(10),D)+k+1;
 unsigned long E1=k*(k*k-1)/6;
 // upper bound for C = [alpha (1-alpha^-2) E1 / k] / [1-(k-1)^2/Xmin²].
 unsigned P=2*D+30; Z V,u;vector<Z> a;
 vector<Frac> conv;
 while(true){
  V=pw(Z(10),P);u=rootz(A*pw(V,k)/B,k);
  assert(B*pw(u,k)<A*pw(V,k));assert(B*pw(Z(u+1),k)>A*pw(V,k));
  auto l=cf(u,V),r=cf(u+1,V);a.clear();
  for(size_t i=0;i<min(l.size(),r.size())&&l[i]==r[i];i++)a.push_back(l[i]);
  Z p0=0,q0=1,p1=1,q1=0;conv.clear();
  conv.push_back({p1,q1,-V}); // index -1
  int beyond=0;
  for(const auto&t:a){Z p=t*p1+p0,q=t*q1+q0;conv.push_back({p,q,u*q-V*p});
     if(q>Xmax && ++beyond>=3)break;
     p0=p1;q0=q1;p1=p;q1=q;}
  if(beyond>=3)break; P*=2;
 }
 Z up=u+1, Cnum=(up*up-V*V)*E1*Xmin*Xmin,Cden=V*up*k*(Z(Xmin)*Xmin-(k-1)*(k-1));
 Z cz=Cnum/Cden+1;unsigned long C=cz.get_ui();assert(C>0);
 vector<pair<unsigned,unsigned>>pairs;
 for(unsigned r=1;r<2*C;r++)for(unsigned s=1;r*s<2*C;s++)if(std::gcd(r,s)==1)pairs.emplace_back(r,s);
 // Initial pair at indices -1,0 handles approximants below floor(alpha).
 if((u%V)*Xmin*Xmin < C*V) {
  ++below_first_possible;
  const Frac&v=conv[1];
  for(auto[r,s]:pairs)for(int sign:{-1,1}){
     Z p=r*v.p+((long)sign*(long)s),q=r*v.q;
     if(check(p,q,r*v.err-((long)sign*(long)s)*V,u,V,A,B,k,E1,C,Xmax,Xmin))return true;
  }
 }
 if(first_only)return false;
 // For largest even m with p_m/q_m <= a/b < alpha, q_m<=b. The proof of Worley theorem
 // gives either positive combination of adjacent m,m+1, or negative of adjacent m+1,m+2.
 for(size_t i=1;i+2<conv.size()&&conv[i].q<=Xmax;i+=2){
  const Frac&v=conv[i],&w=conv[i+1],&z=conv[i+2];
  if(check(v.p,v.q,v.err,u,V,A,B,k,E1,C,Xmax,Xmin))return true;
  for(auto[r,s]:pairs){
   Z p=r*w.p+s*v.p,q=r*w.q+s*v.q;
   // denominator and lower-side tests from bounding bracket
   if(q<=Xmax&&check(p,q,r*w.err+s*v.err,u,V,A,B,k,E1,C,Xmax,Xmin))return true;
   p=r*z.p-s*w.p;q=r*z.q-s*w.q;
   if(q>0&&q<=Xmax&&check(p,q,r*z.err-s*w.err,u,V,A,B,k,E1,C,Xmax,Xmin))return true;
  }
 }
 return false;
}


int main(int argc, char** argv) {
    const unsigned start = argc > 1 ? stoul(argv[1]) : 3;
    const unsigned stop = argc > 2 ? stoul(argv[2]) : 50;
    const unsigned digits = argc > 3 ? stoul(argv[3]) : 80;
    const unsigned long xmin = 10000;
    for (unsigned k = start; k <= stop; ++k) {
        assert(k >= 3 && 2UL*k*(k*k-1)/6 < xmin*xmin);
        // For each lower start there is at most one upper start.
        Z m=k;
        for (unsigned long n=0; 2*n+k+1<xmin; ++n) {
            if (m<n+k) m=n+k;
            Z target=25*f(2*Z(n)+k+1,k);
            while(f(2*m+k+1,k)<target) ++m;
            if (f(2*m+k+1,k)==target) {
                cout<<"WITNESS "<<k<<" "<<n<<" "<<m<<endl;
                return 1;
            }
        }
        if (solve(25,1,k,digits,xmin)) return 1;
        cout<<"length "<<k<<" complete through 10^"<<digits<<"; cumulative candidates "<<candidates
            <<"; cumulative large-center exact tests "<<tested<<endl;
    }
    cout<<"No witness. Initial convergent boundary cases: "<<below_first_possible<<endl;
}

# Bounded search for ratio 25

In these runs A=25, B=1, k ranges from 3 to 100 and D=160. The variables n and m are starts before the first entry. For x below 10000 the code enumerates lower starts and monotonically advances the upper start, beginning at n+k.

## 2. Centered rational approximation

Let x=2n+k+1, y=2m+k+1. Set c_i=2i-k-1, i=1,...,k and

F_k(X)=prod_i (X+c_i)=X^eps prod_{c>0} (X^2-c^2).

The positive c are drawn from the centered offsets and eps=k mod 2; their squared sum is E1=k(k^2-1)/6.

If F_k(y)/F_k(x)=A/B, put t=y/x and alpha=(A/B)^(1/k). For y>x>=Xmin=10000, the function G(X)=F_k(X)/X^k is strictly increasing, so 1<t<alpha, with

alpha-t = alpha(1-(G(x)/G(y))^(1/k))
        <= (alpha/k) log(G(y)/G(x))
        <= (alpha/k) sum_{c>0} c^2 (1-1/t^2)/(x^2-c^2)
        < C/x^2,

where we take integer C strictly larger than

(alpha-1/alpha) E1 / [k (1-(k-1)^2/Xmin^2)].

The code calculates C via certified rational upper endpoint alpha_U=(u+1)/V, where u=floor(V*(A/B)^(1/k)) is computed by an integer k-th root and exact rational power checks. Since z-1/z is increasing for z>0, alpha_U provides a valid upper bound. All arithmetic in the C++ GMP implementation is exact.

Reduce y/x=a/b, with y=ga, x=gb and gcd(a,b)=1. Then

0 < alpha-a/b < C/(g^2 b^2) <= C/b^2.

By Worley's theorem on rational approximations, a/b is either a convergent of alpha or a linear combination of two neighboring convergents with small coefficients r,s, rs<2C. See A. Dujella and B. Ibrahimpašić, On Worley's theorem in Diophantine approximations, Annales Mathematicae et Informaticae 35 (2008), 61-73, Theorem 1.1 and the proof details in Section 2:
https://emis.de/ft/38763

For a/b below alpha, choose the largest even index m with p_m/q_m <= a/b<alpha. Then q_m<=b by unimodularity and the positive combination of these neighboring bracketing convergents. The cited proof gives either a positive combination of m,m+1 or a negative combination of m+1,m+2, and rs<2C. Thus only even m with q_m<=Xmax and two extra convergents need be generated, where Xmax=2*10^D+k+1. An initial pair can handle a/b<floor(alpha), if necessary. In these experiments an independent exact check found that alpha-floor(alpha)>C/Xmin^2 in the recorded ratio-25 runs, so the possibility is excluded.

Convergents are certified by taking a common continued-fraction prefix of the rational endpoints u/V and (u+1)/V; root precision is doubled until this prefix contains at least three denominators beyond Xmax. Approximation tests use the lower root bound; they only reject when failure follows exactly.

## 3. Exact integer-scale test

A possible fraction need not be primitive in the original centered x,y, so testing only g=1 would be incomplete. Instead set u=g^2 and define

D_j = A b^(k-2j) - B a^(k-2j) > 0  for j=0,...,floor(k/2)

and E_j to be elementary symmetric functions in the positive centered-offset squares, with E_1=E1.

Expanding the equality BF_k(ga)=AF_k(gb) and cancelling the common leading g^(k-2) gives

D_0 u = E_1 D_1 - E_2 D_2/u + E_3 D_3/u^2 - ....

For j>=1, E_{j+1}/E_j <= E1/(j+1) by elementary symmetric counting, and

D_{j+1}/D_j
= b^-2 (1-(B/A)t^(k-2j-2))/(1-(B/A)t^(k-2j))
<= 2/b^2

because B t^k/A<1 and t>1. Hence the alternating terms decrease in magnitude when E1/(b^2 u)=E1/x^2<1, and in the searched regime E1/x^2<1/2.

The alternating bounds give

0 <= U-u <= E_2 D_2/(D_0 u) <= 2 E_2 D_2/(E1 D_1) <= 4 E_2/(E1 b^2) <= 2 E1/b^2,
where U=E1 D_1/D_0.

Thus every g is among the integer square roots in the narrow interval [U-2E1/b^2,U]. For b^2>2E1 that interval has width less than 1. The code takes a slightly relaxed integer lower bound to preserve completeness and tests each g exactly, requiring correct parity of x,y and disjointness (y-x>=2k). It verifies BF_k(y)=AF_k(x), and reports every exact product hit.


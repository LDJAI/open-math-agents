\\ Unconditional integral solutions for the length-three reduction.
T=thueinit(x^3-25,1);
{ my(count=0,primitive=0,hits=0);
  fordiv(15600,d,
    my(s=thue(T,-d));
    for(i=1,#s,
      count++;
      my(a=s[i][1],b=s[i][2],g=0);
      if(a>b && b>0 && gcd(a,b)==1,
         primitive++;
         print("d=",d," a=",a," b=",b," scaled numerator=",25*b-a);
         if((25*b-a)%d==0 && issquare((25*b-a)/d,&g) && g*b>=2 && g*(a-b)>=3,
            hits++; print("WITNESS n=",g*b-2," m=",g*a-2)));
    ));
  print("Thue equations=",numdiv(15600)," integer pairs=",count," positive primitive ordered pairs=",primitive," admissible witnesses=",hits);
}
quit

"""Recompute each polynomial cutoff, or check the supplied rational-slope certificates."""
import argparse,csv,json
from math import prod
from pathlib import Path
from square_bounds import bounds
from make_bands import factors,lower
from functools import lru_cache
here=Path(__file__).parent
def verify_band(row):
    k,a,b,p,q,lo,cuts=row
    assert 0<=a<=b and q>0 and p>=0 and p*a+lo>=0
    @lru_cache(2000)
    def baseline(x,d):
        return factors(q*x,q*d,q,k)
    def signed(x,y,j,s):
        for z,d in [(x,1),(y,-1)]:
            coeff=[l-25*r for l,r in zip(factors(p*z+j,p*d,q,k),baseline(z,d))]
            if lower(coeff,y-x,s)>0:return True
        return False
    assert signed(a,b,lo,-1) and signed(a,b,lo+1+len(cuts),1)
    for j,split in enumerate(cuts,lo+1):
        assert a-1<=(split[0] if split else b)<=b
        x=a
        for y in split+[b]:
            assert x<=y<=b
            assert signed(x,y,j,1) or signed(x,y,j,-1)
            x=y+1
def verify_small(k,cap):
    f=lambda n:prod(range(n+1,n+k+1))
    m=k
    for n in range(cap):
        m=max(m,n+k)
        while f(m)<25*f(n):m+=1
        assert f(m)>25*f(n)
if __name__=='__main__':
    a=argparse.ArgumentParser()
    a.add_argument('--heights',action='store_true')
    a.add_argument('--bands',action='store_true')
    a.add_argument('--length',type=int)
    opt=a.parse_args()
    heights={int(r['length']):int(r['lower_start_threshold'])
             for r in csv.DictReader((here/'heights.tsv').open(),delimiter='\t')}
    assert set(heights)==set(range(2,101,2)) and max(heights.values())<10**160
    if opt.bands and opt.length in (None,5):
        import json
        table=json.loads((here/"bands/band5.json").read_text())
        verify_small(5,100)
        edge=99
        for row in table:
            assert row[0]==5 and row[1]==edge+1
            verify_band(row)
            edge=row[2]
        assert edge==10**160
        print("length 5: checked all lower starts through a one followed by 160 zeros",flush=True)
    for k,t in heights.items():
        if opt.length and opt.length!=k: continue
        if opt.heights:
            assert bounds(k)[0]==t
            print('cutoff',k,t,flush=True)
        cert=here/'bands'/f'band{k}.json'
        if opt.bands and cert.exists():
            bands=json.loads(cert.read_text())
            verify_small(k,min(100,t))
            end=99
            for row in bands:
                assert row[0]==k and row[1]==end+1
                verify_band(row)
                end=row[2]
            assert end+1>=t
            print('finite certificate',k,'complete',flush=True)

f=9*x^6+400*x^5-1250*x^3+400*x+5625;
print("factorization = ",factor(f));
print("discriminant factorization = ",factor(poldisc(f)));
p=hyperellratpoints(f,1000000);
print("affine rational points through naive x height 1000000 = ",p);
quit

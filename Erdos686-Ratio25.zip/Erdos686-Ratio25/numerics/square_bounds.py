from sympy import symbols, Poly, QQ, prod, ilcm
from functools import reduce
x=symbols('x')
def bounds(k):
    r=k//2
    p=Poly(prod(x+i for i in range(1,k+1)),x,domain=QQ)
    h=Poly(x**r,x,domain=QQ)
    for j in range(1,r+1):
        h+=Poly((p-h*h).nth(k-j)/2*x**(r-j),x,domain=QQ)
    d=reduce(ilcm,[1]+[a.q for a in h.all_coeffs()])
    h*=d
    rem=h*h-d*d*p
    if rem.LC()<0: rem=-rem
    # Positive test H, (6H+-1)^2 sandwich, and decreasing residual / P.
    arr=[6*h-1, 36*d*d*p-(6*h-1)**2,(6*h+1)**2-36*d*d*p,rem,rem*Poly(x+k+1,x)-(rem.shift(1))*Poly(x+1,x)]
    def good(n):
        return all(all(v>=0 for v in a.shift(n).all_coeffs()) and a.eval(n)>0 for a in arr)
    hi=1
    while not good(hi): hi*=2
    lo=-1
    while lo+1<hi:
        m=(lo+hi)//2
        if good(m):hi=m
        else:lo=m
    return hi,d,h,rem,p,arr
if __name__=='__main__':
 for k in range(2,43,2):
    n,d,h,R,p,_=bounds(k);print(k,n,d, flush=True)

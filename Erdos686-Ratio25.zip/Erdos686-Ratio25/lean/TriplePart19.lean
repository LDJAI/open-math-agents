import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem cell78_0 {n k d : ℕ} (ak : 78≤k) (kb : k≤78) (sd : k≤d) (lo : 78≤d) (hi : d≤229) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=78) (b:=78) (f:=78) (s:=306) (U':=9014716836799586623329573573945377845159029877980505339167320652785333649613624539473353602148614605570705738411136004478202144000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell78_1 {n k d : ℕ} (ak : 78≤k) (kb : k≤78) (sd : k≤d) (lo : 230≤d) (hi : d≤234) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=78) (b:=78) (f:=230) (s:=311) (U':=860698119427114132035637696119582840522248695659944708267678273965985300864160030155297381872343276696074271786280032299565306102688000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row78 {n k d : ℕ} (ak : 78≤k) (kb : k≤78) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤229
  · exact cell78_0 ak kb sd (by omega) c0
  exact cell78_1 ak kb sd (by omega) (by omega)
private theorem cell79_0 {n k d : ℕ} (ak : 79≤k) (kb : k≤79) (sd : k≤d) (lo : 79≤d) (hi : d≤232) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=79) (b:=79) (f:=79) (s:=310) (U':=2767518068897473093362179087201230998463822172540015139124367440405097430431382733618319555859624683910206661692218753374808058208000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell79_1 {n k d : ℕ} (ak : 79≤k) (kb : k≤79) (sd : k≤d) (lo : 233≤d) (hi : d≤237) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=79) (b:=79) (f:=233) (s:=315) (U':=269398511380686723327154598885429429083463841741562693687783299751353399170482089438608080526043445605871247069105650109763940810141344000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row79 {n k d : ℕ} (ak : 79≤k) (kb : k≤79) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤232
  · exact cell79_0 ak kb sd (by omega) c0
  exact cell79_1 ak kb sd (by omega) (by omega)
private theorem cell80_0 {n k d : ℕ} (ak : 80≤k) (kb : k≤80) (sd : k≤d) (lo : 80≤d) (hi : d≤237) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=80) (b:=80) (f:=80) (s:=316) (U':=269398511380686723327154598885429429083463841741562693687783299751353399170482089438608080526043445605871247069105650109763940810141344000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell80_1 {n k d : ℕ} (ak : 80≤k) (kb : k≤80) (sd : k≤d) (lo : 238≤d) (hi : d≤240) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=80) (b:=80) (f:=238) (s:=319) (U':=85399328107677691294708007846681129019458037832075373899027306021179027537042822352038761526755772257061185320906491084795169236814806048000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row80 {n k d : ℕ} (ak : 80≤k) (kb : k≤80) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤237
  · exact cell80_0 ak kb sd (by omega) c0
  exact cell80_1 ak kb sd (by omega) (by omega)
private theorem cell81_0 {n k d : ℕ} (ak : 81≤k) (kb : k≤82) (sd : k≤d) (lo : 81≤d) (hi : d≤246) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=81) (b:=82) (f:=81) (s:=327) (U':=85399328107677691294708007846681129019458037832075373899027306021179027537042822352038761526755772257061185320906491084795169236814806048000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row81 {n k d : ℕ} (ak : 81≤k) (kb : k≤82) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  exact cell81_0 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

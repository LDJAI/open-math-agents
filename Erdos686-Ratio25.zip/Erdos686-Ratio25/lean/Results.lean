import Finite
import SmallCases
import Length10
import Length14
import Length18
import Length20
import Length22
import Length24

namespace Ratio25

/-- Every even length between two and 24 is excluded at all allowed starts. -/
theorem even_through_24 {k n m : ℕ} (hk : 2≤k) (hi : k≤24) (he : Even k) (hm : n+k≤m) :
    (25 : ℚ) ≠ (∏ i ∈ Finset.Icc 1 k, (m+i)) / (∏ i ∈ Finset.Icc 1 k, (n+i)) := by
  intro eqn
  have h := (ratio_iff n m k).mp eqn
  obtain ⟨v,hv⟩ := he
  have classify : ∀ x : Fin 25, 2 ≤ x.val → x.val % 2 = 0 → x.val=2 ∨ x.val=4 ∨ x.val=6 ∨ x.val=8 ∨ x.val=10 ∨ x.val=12 ∨ x.val=14 ∨ x.val=16 ∨ x.val=18 ∨ x.val=20 ∨ x.val=22 ∨ x.val=24 := by decide +kernel
  have opts := classify ⟨k,by omega⟩ hk (by change k%2=0; omega)
  rcases opts with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact exclude2 (by omega) h
  · exact exclude4 (by omega) h
  · exact exclude6 (by omega) h
  · exact exclude8 (by omega) h
  · exact Length10.exclusion (by omega) h
  · exact exclude12 (by omega) h
  · exact Length14.exclusion (by omega) h
  · exact exclude16 (by omega) h
  · exact Length18.exclusion (by omega) h
  · exact Length20.exclusion (by omega) h
  · exact Length22.exclusion (by omega) h
  · exact Length24.exclusion (by omega) h

#print axioms even_through_24
end Ratio25

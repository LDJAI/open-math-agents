import Bound

namespace Ratio25

/-- A single bracket excludes every choice of upper start at this lower start. -/
theorem beyond_bracket {n k a : ℕ} (hlt : block a k < 25*block n k)
    (hgt : 25*block n k < block (a+1) k) (m : ℕ) : block m k ≠ 25*block n k := by
  by_cases hh : m≤a
  · exact ((block_mono k hh).trans_lt hlt).ne
  · exact (hgt.trans_le (block_mono k (show a+1≤m by omega))).ne'

def checkBatch (k start : ℕ) : List ℕ → Bool
  | [] => true
  | a::as => decide (block a k < 25*block start k) &&
    decide (25*block start k < block (a+1) k) && checkBatch k (start+1) as

theorem batch_sound {k t : ℕ} {l : List ℕ} (h : checkBatch k t l = true)
    {n : ℕ} (hn : t≤n) (hn' : n<t+l.length) (m : ℕ) : block m k ≠ 25*block n k := by
  induction l generalizing t with
  | nil => simp at hn'; omega
  | cons a l ih =>
    simp only [checkBatch,Bool.and_eq_true,decide_eq_true_eq] at h
    by_cases he : t=n
    · subst n; exact beyond_bracket h.1.1 h.1.2 m
    · apply ih h.2 (by omega)
      simp only [List.length_cons] at hn'
      omega

/-- A strict inequality at the first allowed upper start also excludes
every larger start. This permits an exact equality at an overlapping start. -/
def checkSeparated (k start : ℕ) : List ℕ → Bool
  | [] => true
  | a::as => (decide (25*block start k < block (start+2) k) ||
      (decide (block a k < 25*block start k) &&
       decide (25*block start k < block (a+1) k))) && checkSeparated k (start+1) as

theorem separated_sound {k t : ℕ} {l : List ℕ} (h : checkSeparated k t l = true)
    {n m : ℕ} (hn : t≤n) (hn' : n<t+l.length) (hm : n+2≤m) : block m k ≠ 25*block n k := by
  induction l generalizing t with
  | nil => simp at hn'; omega
  | cons a l ih =>
    simp only [checkSeparated,Bool.and_eq_true,Bool.or_eq_true,decide_eq_true_eq] at h
    by_cases ht : t=n
    · subst n
      rcases h.1 with h0 | ⟨hl,hu⟩
      · exact (h0.trans_le (block_mono k hm)).ne'
      · exact beyond_bracket hl hu m
    · apply ih h.2 (by omega)
      simp only [List.length_cons] at hn'
      omega

theorem transpose (n d k : ℕ) :
    block (n+d) k * block n d = block (n+k) d * block n k := by
  have join (a b : ℕ) : block n a * block (n+a) b = block n (a+b) := by
    induction b with
    | zero => simp [block]
    | succ b ih =>
      change block n a * ((n+a+1+b)*block (n+a) b) = (n+1+(a+b))*block n (a+b)
      rw [show n+a+1+b=n+1+(a+b) by omega,← ih]
      ring
  calc _ = block n (d+k) := by simpa only [mul_comm] using join d k
       _ = block n (k+d) := by rw [Nat.add_comm d k]
       _ = _ := by simpa only [mul_comm] using (join k d).symm

theorem block_Icc (n k : ℕ) : (∏ i ∈ Finset.Icc 1 k, (n+i)) = block n k := by
  have hs : Finset.Icc 1 k = Finset.Ico 1 (k+1) := by ext i; simp
  rw [hs, Finset.prod_Ico_eq_prod_range, block, Nat.ascFactorial_eq_prod_range]
  simp [add_assoc]

theorem ratio_iff (n m k : ℕ) :
    (25 : ℚ) = (∏ i ∈ Finset.Icc 1 k, (m+i)) / (∏ i ∈ Finset.Icc 1 k, (n+i)) ↔
    block m k = 25*block n k := by
  rw [block_Icc, block_Icc, eq_div_iff (by exact_mod_cast (block_pos n k).ne')]
  constructor <;> intro h <;> exact_mod_cast h.symm

end Ratio25

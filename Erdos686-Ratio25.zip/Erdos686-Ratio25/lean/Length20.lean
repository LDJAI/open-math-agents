import Finite
import Strips
namespace Ratio25.Length20
open Strips
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private theorem high {n m : ℕ} (hn : 137541≤n) (hm : n<m) : block m 20 ≠ 25*block n 20 :=
  no_large (t:=137541) (d:=8) (h:=[19397389678922264274985723760815040182503904635442925, 1410191071199549319445978857898182693920183299365, 46134428416344650704001274311057169232841063, 894393318951381640939253815417357658220, 11378925784151040296824895819921720, 99269807703387473776164583140, 601409943311669276143604, 2498430223958579280, 6811349453480, 11004120, 8]) (sgn:=(1)) (by decide +kernel) hn hm
private theorem small {n m : ℕ} (hn : n<100) (hm : n+2≤m) : block m 20 ≠ 25*block n 20 :=
  separated_sound (l:=[1, 2, 3, 4, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 18, 19, 20, 21, 22, 23, 25, 26, 27, 28, 29, 31, 32, 33, 34, 35, 36, 38, 39, 40, 41, 42, 44, 45, 46, 47, 48, 49, 51, 52, 53, 54, 55, 56, 58, 59, 60, 61, 62, 64, 65, 66, 67, 68, 69, 71, 72, 73, 74, 75, 76, 78, 79, 80, 81, 82, 83, 85, 86, 87, 88, 89, 91, 92, 93, 94, 95, 96, 98, 99, 100, 101, 102, 103, 105, 106, 107, 108, 109, 111, 112, 113, 114, 115, 116, 118]) (t:=0) (by decide +kernel) (Nat.zero_le _) (by simpa using hn) hm
private theorem part0 {n m : ℕ} (ha : 100≤n) (hb : n≤199) : block m 20 ≠ 25*block n 20 :=
  band_sound (p:=27) (q:=23) (l:=(42)) (cs:=[[112], [157], []]) (by decide +kernel) ha hb
private theorem part1 {n m : ℕ} (ha : 200≤n) (hb : n≤399) : block m 20 ≠ 25*block n 20 :=
  band_sound (p:=74) (q:=63) (l:=(114)) (cs:=[[373], []]) (by decide +kernel) ha hb
private theorem part2 {n m : ℕ} (ha : 400≤n) (hb : n≤799) : block m 20 ≠ 25*block n 20 :=
  band_sound (p:=74) (q:=63) (l:=(115)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part3 {n m : ℕ} (ha : 800≤n) (hb : n≤1599) : block m 20 ≠ 25*block n 20 :=
  band_sound (p:=74) (q:=63) (l:=(115)) (cs:=[[876], []]) (by decide +kernel) ha hb
private theorem part4 {n m : ℕ} (ha : 1600≤n) (hb : n≤3199) : block m 20 ≠ 25*block n 20 :=
  band_sound (p:=74) (q:=63) (l:=(116)) (cs:=[[1698], [2634], []]) (by decide +kernel) ha hb
private theorem part5 {n m : ℕ} (ha : 3200≤n) (hb : n≤6399) : block m 20 ≠ 25*block n 20 :=
  band_sound (p:=1157) (q:=985) (l:=(1802)) (cs:=[[6342], []]) (by decide +kernel) ha hb
private theorem part6 {n m : ℕ} (ha : 6400≤n) (hb : n≤12799) : block m 20 ≠ 25*block n 20 :=
  band_sound (p:=1157) (q:=985) (l:=(1801)) (cs:=[[10197], []]) (by decide +kernel) ha hb
private theorem part7 {n m : ℕ} (ha : 12800≤n) (hb : n≤25599) : block m 20 ≠ 25*block n 20 :=
  band_sound (p:=3545) (q:=3018) (l:=(5531)) (cs:=[[15699], []]) (by decide +kernel) ha hb
private theorem part8 {n m : ℕ} (ha : 25600≤n) (hb : n≤51199) : block m 20 ≠ 25*block n 20 :=
  band_sound (p:=3545) (q:=3018) (l:=(5531)) (cs:=[[34681], []]) (by decide +kernel) ha hb
private theorem part9 {n m : ℕ} (ha : 51200≤n) (hb : n≤102399) : block m 20 ≠ 25*block n 20 :=
  band_sound (p:=3545) (q:=3018) (l:=(5530)) (cs:=[[76908], []]) (by decide +kernel) ha hb
private theorem part10 {n m : ℕ} (ha : 102400≤n) (hb : n≤137540) : block m 20 ≠ 25*block n 20 :=
  band_sound (p:=3545) (q:=3018) (l:=(5529)) (cs:=[[112762], []]) (by decide +kernel) ha hb
theorem exclusion {n m : ℕ} (hm : n+2≤m) : block m 20 ≠ 25*block n 20 := by
  by_cases hh : n<100
  · exact small hh hm
  by_cases h0 : n≤199
  · exact part0 (by omega) h0
  by_cases h1 : n≤399
  · exact part1 (by omega) h1
  by_cases h2 : n≤799
  · exact part2 (by omega) h2
  by_cases h3 : n≤1599
  · exact part3 (by omega) h3
  by_cases h4 : n≤3199
  · exact part4 (by omega) h4
  by_cases h5 : n≤6399
  · exact part5 (by omega) h5
  by_cases h6 : n≤12799
  · exact part6 (by omega) h6
  by_cases h7 : n≤25599
  · exact part7 (by omega) h7
  by_cases h8 : n≤51199
  · exact part8 (by omega) h8
  by_cases h9 : n≤102399
  · exact part9 (by omega) h9
  by_cases h10 : n≤137540
  · exact part10 (by omega) h10
  exact high (by omega) (by omega)
#print axioms exclusion
end Ratio25.Length20

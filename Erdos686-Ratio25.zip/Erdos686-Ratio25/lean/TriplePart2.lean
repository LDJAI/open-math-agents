import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem small10 : allGaps 10 = true := by decide +kernel
theorem row10 {n k d : ℕ} (ak : 10≤k) (kb : k≤10) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=10 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small10
private theorem small11 : allGaps 11 = true := by decide +kernel
theorem row11 {n k d : ℕ} (ak : 11≤k) (kb : k≤11) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=11 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small11
private theorem small12 : allGaps 12 = true := by decide +kernel
theorem row12 {n k d : ℕ} (ak : 12≤k) (kb : k≤12) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=12 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small12
private theorem small13 : allGaps 13 = true := by decide +kernel
theorem row13 {n k d : ℕ} (ak : 13≤k) (kb : k≤13) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=13 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small13
end Ratio25.TripleBlocks

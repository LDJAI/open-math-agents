import Finite
import Strips
namespace Ratio25.Length14
open Strips
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private theorem high {n m : ℕ} (hn : 123641932≤n) (hm : n<m) : block m 14 ≠ 25*block n 14 :=
  no_large (t:=123641932) (d:=2048) (h:=[904670888036669354437759193388107364032351501467139439269213, 51218027166717909763473714314567202964117211081233230, 1242734319127644106542980943593521884507100024, 16751790481357999445972964453133468208, 135486312727713304346163968640, 657477454376457847552, 1772530844672, 2048]) (sgn:=(1)) (by decide +kernel) hn hm
private theorem small {n : ℕ} (hn : n<100) (m : ℕ) : block m 14 ≠ 25*block n 14 :=
  batch_sound (l:=[1, 2, 3, 5, 6, 7, 9, 10, 11, 13, 14, 15, 16, 18, 19, 20, 21, 23, 24, 25, 26, 28, 29, 30, 32, 33, 34, 35, 37, 38, 39, 40, 42, 43, 44, 45, 47, 48, 49, 50, 52, 53, 54, 55, 57, 58, 59, 61, 62, 63, 64, 66, 67, 68, 69, 71, 72, 73, 74, 76, 77, 78, 79, 81, 82, 83, 84, 86, 87, 88, 89, 91, 92, 93, 95, 96, 97, 98, 100, 101, 102, 103, 105, 106, 107, 108, 110, 111, 112, 113, 115, 116, 117, 118, 120, 121, 122, 123, 125, 126]) (t:=0) (by decide +kernel) (Nat.zero_le _) (by simpa using hn) m
private theorem part0 {n m : ℕ} (ha : 100≤n) (hb : n≤199) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=39) (q:=31) (l:=(60)) (cs:=[[129], [185], []]) (by decide +kernel) ha hb
private theorem part1 {n m : ℕ} (ha : 200≤n) (hb : n≤399) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=112) (q:=89) (l:=(172)) (cs:=[[263], [366], []]) (by decide +kernel) ha hb
private theorem part2 {n m : ℕ} (ha : 400≤n) (hb : n≤799) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=185) (q:=147) (l:=(283)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part3 {n m : ℕ} (ha : 800≤n) (hb : n≤1599) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=185) (q:=147) (l:=(283)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part4 {n m : ℕ} (ha : 1600≤n) (hb : n≤3199) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=185) (q:=147) (l:=(282)) (cs:=[[2741], []]) (by decide +kernel) ha hb
private theorem part5 {n m : ℕ} (ha : 3200≤n) (hb : n≤6399) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=185) (q:=147) (l:=(280)) (cs:=[[5964], [4385], []]) (by decide +kernel) ha hb
private theorem part6 {n m : ℕ} (ha : 6400≤n) (hb : n≤12799) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=1962) (q:=1559) (l:=(3020)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part7 {n m : ℕ} (ha : 12800≤n) (hb : n≤25599) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=1962) (q:=1559) (l:=(3018)) (cs:=[[23931], [15614], []]) (by decide +kernel) ha hb
private theorem part8 {n m : ℕ} (ha : 25600≤n) (hb : n≤51199) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=9625) (q:=7648) (l:=(14825)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part9 {n m : ℕ} (ha : 51200≤n) (hb : n≤102399) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=9625) (q:=7648) (l:=(14824)) (cs:=[[84717], []]) (by decide +kernel) ha hb
private theorem part10 {n m : ℕ} (ha : 102400≤n) (hb : n≤204799) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=46163) (q:=36681) (l:=(71114)) (cs:=[[127583], [199383], []]) (by decide +kernel) ha hb
private theorem part11 {n m : ℕ} (ha : 204800≤n) (hb : n≤409599) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=46163) (q:=36681) (l:=(71116)) (cs:=[[291357], [394496], []]) (by decide +kernel) ha hb
private theorem part12 {n m : ℕ} (ha : 409600≤n) (hb : n≤819199) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=148114) (q:=117691) (l:=(228171)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part13 {n m : ℕ} (ha : 819200≤n) (hb : n≤1638399) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=148114) (q:=117691) (l:=(228171)) (cs:=[[908263], []]) (by decide +kernel) ha hb
private theorem part14 {n m : ℕ} (ha : 1638400≤n) (hb : n≤3276799) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=148114) (q:=117691) (l:=(228172)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part15 {n m : ℕ} (ha : 3276800≤n) (hb : n≤6553599) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=148114) (q:=117691) (l:=(228172)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part16 {n m : ℕ} (ha : 6553600≤n) (hb : n≤13107199) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=148114) (q:=117691) (l:=(228172)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part17 {n m : ℕ} (ha : 13107200≤n) (hb : n≤26214399) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=148114) (q:=117691) (l:=(228172)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part18 {n m : ℕ} (ha : 26214400≤n) (hb : n≤52428799) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=148114) (q:=117691) (l:=(228171)) (cs:=[[38246811], []]) (by decide +kernel) ha hb
private theorem part19 {n m : ℕ} (ha : 52428800≤n) (hb : n≤104857599) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=148114) (q:=117691) (l:=(228171)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part20 {n m : ℕ} (ha : 104857600≤n) (hb : n≤123641931) : block m 14 ≠ 25*block n 14 :=
  band_sound (p:=148114) (q:=117691) (l:=(228170)) (cs:=[[117168779], []]) (by decide +kernel) ha hb
theorem exclusion {n m : ℕ} (hm : n<m) : block m 14 ≠ 25*block n 14 := by
  by_cases hh : n<100
  · exact small hh m
  by_cases h0 : n≤199
  · exact part0 (by omega) h0
  by_cases h1 : n≤399
  · exact part1 (by omega) h1
  by_cases h2 : n≤799
  · exact part2 (by omega) h2
  by_cases h3 : n≤1599
  · exact part3 (by omega) h3
  by_cases h4 : n≤3199
  · exact part4 (by omega) h4
  by_cases h5 : n≤6399
  · exact part5 (by omega) h5
  by_cases h6 : n≤12799
  · exact part6 (by omega) h6
  by_cases h7 : n≤25599
  · exact part7 (by omega) h7
  by_cases h8 : n≤51199
  · exact part8 (by omega) h8
  by_cases h9 : n≤102399
  · exact part9 (by omega) h9
  by_cases h10 : n≤204799
  · exact part10 (by omega) h10
  by_cases h11 : n≤409599
  · exact part11 (by omega) h11
  by_cases h12 : n≤819199
  · exact part12 (by omega) h12
  by_cases h13 : n≤1638399
  · exact part13 (by omega) h13
  by_cases h14 : n≤3276799
  · exact part14 (by omega) h14
  by_cases h15 : n≤6553599
  · exact part15 (by omega) h15
  by_cases h16 : n≤13107199
  · exact part16 (by omega) h16
  by_cases h17 : n≤26214399
  · exact part17 (by omega) h17
  by_cases h18 : n≤52428799
  · exact part18 (by omega) h18
  by_cases h19 : n≤104857599
  · exact part19 (by omega) h19
  by_cases h20 : n≤123641931
  · exact part20 (by omega) h20
  exact high (by omega) hm
#print axioms exclusion
end Ratio25.Length14

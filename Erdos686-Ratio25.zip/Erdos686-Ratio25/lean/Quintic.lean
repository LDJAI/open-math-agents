import Bound

namespace Ratio25

/-- The length-five problem maps to a rational point on a fixed sextic.
This form clears all denominators in the discriminant identity. -/
theorem length_five_square {m n : ℕ} (h : block m 5 = 25*block n 5) :
    let X : ℤ := n+3
    let Y : ℤ := m+3
    ∃ Z : ℤ, Z^2 = 9*Y^6+400*Y^5*X-1250*Y^3*X^3+400*Y*X^5+5625*X^6 := by
  dsimp only
  let X : ℤ := n+3
  let Y : ℤ := m+3
  have form (w : ℕ) : (block w 5 : ℤ) = ((w:ℤ)+3)^5-5*((w:ℤ)+3)^3+4*((w:ℤ)+3) := by
    simp [block,Nat.ascFactorial]; ring
  have eq : (Y^5-25*X^5) - 5*(Y^3-25*X^3)+4*(Y-25*X)=0 := by
    have zz : (block m 5:ℤ)=25*(block n 5:ℤ) := by exact_mod_cast h
    rw [form,form] at zz
    dsimp [X,Y]; linarith only [zz]
  refine ⟨2*(Y^5-25*X^5)-5*(Y^3-25*X^3), ?_⟩
  change _ = 9*Y^6+400*Y^5*X-1250*Y^3*X^3+400*Y*X^5+5625*X^6
  calc _ = 9*Y^6+400*Y^5*X-1250*Y^3*X^3+400*Y*X^5+5625*X^6 +
          4*(Y^5-25*X^5)*((Y^5-25*X^5)-5*(Y^3-25*X^3)+4*(Y-25*X)) := by ring
       _ = _ := by rw [eq]; ring

#print axioms length_five_square
end Ratio25

import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem cell34_0 {n k d : ℕ} (ak : 34≤k) (kb : k≤34) (sd : k≤d) (lo : 34≤d) (hi : d≤73) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=34) (b:=34) (f:=34) (s:=106) (U':=725301063514698899942645214354053893901390400) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell34_1 {n k d : ℕ} (ak : 34≤k) (kb : k≤34) (sd : k≤d) (lo : 74≤d) (hi : d≤102) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=34) (b:=34) (f:=74) (s:=135) (U':=1749342047920660916901891145781670987072592322134428432000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row34 {n k d : ℕ} (ak : 34≤k) (kb : k≤34) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤73
  · exact cell34_0 ak kb sd (by omega) c0
  exact cell34_1 ak kb sd (by omega) (by omega)
private theorem cell35_0 {n k d : ℕ} (ak : 35≤k) (kb : k≤35) (sd : k≤d) (lo : 35≤d) (hi : d≤74) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=35) (b:=35) (f:=35) (s:=108) (U':=77607213796072782293863037935883766647448772800) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell35_1 {n k d : ℕ} (ak : 35≤k) (kb : k≤35) (sd : k≤d) (lo : 75≤d) (hi : d≤102) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=35) (b:=35) (f:=75) (s:=136) (U':=1749342047920660916901891145781670987072592322134428432000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell35_2 {n k d : ℕ} (ak : 35≤k) (kb : k≤35) (sd : k≤d) (lo : 103≤d) (hi : d≤105) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=35) (b:=35) (f:=103) (s:=139) (U':=33312720618553145840562713089120360606823375590405920630576000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row35 {n k d : ℕ} (ak : 35≤k) (kb : k≤35) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤74
  · exact cell35_0 ak kb sd (by omega) c0
  by_cases c1 : d≤102
  · exact cell35_1 ak kb sd (by omega) c1
  exact cell35_2 ak kb sd (by omega) (by omega)
private theorem cell36_0 {n k d : ℕ} (ak : 36≤k) (kb : k≤36) (sd : k≤d) (lo : 36≤d) (hi : d≤73) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=36) (b:=36) (f:=36) (s:=108) (U':=77607213796072782293863037935883766647448772800) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell36_1 {n k d : ℕ} (ak : 36≤k) (kb : k≤36) (sd : k≤d) (lo : 74≤d) (hi : d≤103) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=36) (b:=36) (f:=74) (s:=138) (U':=239659860565130545615559086972088925228945148132416695184000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell36_2 {n k d : ℕ} (ak : 36≤k) (kb : k≤36) (sd : k≤d) (lo : 104≤d) (hi : d≤108) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=36) (b:=36) (f:=104) (s:=143) (U':=33312720618553145840562713089120360606823375590405920630576000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row36 {n k d : ℕ} (ak : 36≤k) (kb : k≤36) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤73
  · exact cell36_0 ak kb sd (by omega) c0
  by_cases c1 : d≤103
  · exact cell36_1 ak kb sd (by omega) c1
  exact cell36_2 ak kb sd (by omega) (by omega)
private theorem cell37_0 {n k d : ℕ} (ak : 37≤k) (kb : k≤37) (sd : k≤d) (lo : 37≤d) (hi : d≤76) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=37) (b:=37) (f:=37) (s:=112) (U':=8459186303771933270031071135011330564571916235200) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell37_1 {n k d : ℕ} (ak : 37≤k) (kb : k≤37) (sd : k≤d) (lo : 77≤d) (hi : d≤111) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=37) (b:=37) (f:=77) (s:=147) (U':=33312720618553145840562713089120360606823375590405920630576000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row37 {n k d : ℕ} (ak : 37≤k) (kb : k≤37) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤76
  · exact cell37_0 ak kb sd (by omega) c0
  exact cell37_1 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

import Transfer
import Mathlib.Tactic.IntervalCases
namespace Ratio25
open Erdos677TransportSecond Erdos677PrimePower Erdos677Valuation

/-- Bound a fixed-length block ratio by a power of a bound for individual factors. -/
theorem scale_upper (k n d z : ℕ) (hn : z*d ≤ n+1) :
    z^k * block (n+d) k ≤ (z+1)^k * block n k := by
  induction k with
  | zero => simp [block]
  | succ k ih =>
    have hf : z*(n+d+1+k) ≤ (z+1)*(n+1+k) := by nlinarith only [hn,Nat.zero_le k]
    simp only [pow_succ,block,Nat.ascFactorial_succ] at ih ⊢
    simpa only [Nat.mul_comm,Nat.mul_left_comm,Nat.mul_assoc] using Nat.mul_le_mul ih hf

theorem length5_lower_start {n d : ℕ} (he : block (n+d) 5 = 25*block n 5) : n<2*d := by
  by_contra! hn
  have hh := scale_upper 5 n d 2 (by omega)
  rw [he] at hh
  norm_num at hh
  have := block_pos n 5
  omega

/-- No individual prime power can take an arbitrarily large share of a length-five gap.
The base of the prime power may also be 2, 3 or 5. -/
theorem length5_cofactor {n d p e t : ℕ} (hp : p.Prime) (hd : d=p^e*t)
    (hs : 5≤d) (he : block (n+d) 5=25*block n 5) :
    p^e < 796262400*t ∧ d < 796262400*t^2 := by
  have he' : 1*P (n+d) 5=25*P n 5 := by simpa [block,P] using he
  have weight (i : ℕ) (hi : i<5) : (edgeWeight 5 i).natAbs ≤ 24 := by
    interval_cases i <;> decide +kernel
  have rough := (power_cofactor_bounds hp hd (by decide : 2≤5) hs (by decide : 0<1) he' weight).1
  have bound : p^e < 796262400*t := by exact rough
  have ht : 0<t := by
    by_contra! h; have h0 : t=0 := by omega
    simp [h0] at hd; omega
  refine ⟨bound,?_⟩
  calc d = p^e*t := hd
       _ < (796262400*t)*t := Nat.mul_lt_mul_of_pos_right bound ht
       _ = _ := by ring

/-- A height exclusion through N rules out prime-power times small-cofactor gaps with
no further bound on the starts, the exponent, or the prime. -/
theorem length5_cofactor_of_search {N T : ℕ}
    (hN : 2*796262400*T^2 ≤ N) (hc : ∀ n m : ℕ, n≤N → n+5≤m → block m 5≠25*block n 5)
    {n d p e t : ℕ} (hp : p.Prime) (hd : d=p^e*t) (hs : 5≤d) (ht : t≤T) :
    block (n+d) 5≠25*block n 5 := by
  intro he
  have size := (length5_cofactor hp hd hs he).2
  have h := Nat.mul_le_mul_left 796262400 (Nat.pow_le_pow_left ht 2)
  have hn := length5_lower_start he
  exact hc n (n+d) (by nlinarith only [size,h,hn,hN]) (by omega) he

#print axioms length5_cofactor_of_search
end Ratio25

import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem cell113_0 {n k d : ℕ} (ak : 113≤k) (kb : k≤122) (sd : k≤d) (lo : 113≤d) (hi : d≤366) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=113) (b:=122) (f:=113) (s:=487) (U':=298926252990514008031802401214005603180949835521508430491733732371448834209370730847959706867467427667017589585069972432495598175224678836672581173196330760715163179968717060664113939572582825877621626985697952000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row113 {n k d : ℕ} (ak : 113≤k) (kb : k≤122) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  exact cell113_0 ak kb sd (by omega) (by omega)
private theorem cell123_0 {n k d : ℕ} (ak : 123≤k) (kb : k≤136) (sd : k≤d) (lo : 123≤d) (hi : d≤408) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=123) (b:=136) (f:=123) (s:=543) (U':=127152930085872751704893960075511153308633889006187285337779978998483830730812162416098967460913067401430134028616289807745170753790452125450459850496886744172842712855619842276136099796525677521568672403007872416433713436393631168000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row123 {n k d : ℕ} (ak : 123≤k) (kb : k≤136) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  exact cell123_0 ak kb sd (by omega) (by omega)
private theorem cell137_0 {n k d : ℕ} (ak : 137≤k) (kb : k≤154) (sd : k≤d) (lo : 137≤d) (hi : d≤462) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=137) (b:=154) (f:=137) (s:=615) (U':=190653477501387432428243898790418979457473686746559437568361500674082704574890200285023043966756655210913726834248445415906637071896145129654263890751759171523425347019724278027315375926618840851600259989712084943610772856576419629926877165808863671517671098909632000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row137 {n k d : ℕ} (ak : 137≤k) (kb : k≤154) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  exact cell137_0 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem cell92_0 {n k d : ℕ} (ak : 92≤k) (kb : k≤94) (sd : k≤d) (lo : 92≤d) (hi : d≤282) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=92) (b:=94) (f:=92) (s:=375) (U':=2661723513916553208630771904990103550783227485383563233347362920784697180777267682265633186017679737401670515904147624706076581413847364103402516734243188200608000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row92 {n k d : ℕ} (ak : 92≤k) (kb : k≤94) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  exact cell92_0 ak kb sd (by omega) (by omega)
private theorem cell95_0 {n k d : ℕ} (ak : 95≤k) (kb : k≤97) (sd : k≤d) (lo : 95≤d) (hi : d≤291) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=95) (b:=97) (f:=95) (s:=387) (U':=386367800109585114105216957412648461121040952095821888263003159492344288670085844954632516382768337642014287077098356759459958328289841831157599121592538469635655456000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row95 {n k d : ℕ} (ak : 95≤k) (kb : k≤97) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  exact cell95_0 ak kb sd (by omega) (by omega)
private theorem cell98_0 {n k d : ℕ} (ak : 98≤k) (kb : k≤104) (sd : k≤d) (lo : 98≤d) (hi : d≤312) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=98) (b:=104) (f:=98) (s:=415) (U':=9786078921235332411985538641727093494452304397678501240454771259802886638128517922501762106887193141243531175704680604601888381217797378602122087297309985035365212550588800032000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row98 {n k d : ℕ} (ak : 98≤k) (kb : k≤104) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  exact cell98_0 ak kb sd (by omega) (by omega)
private theorem cell105_0 {n k d : ℕ} (ak : 105≤k) (kb : k≤112) (sd : k≤d) (lo : 105≤d) (hi : d≤336) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=105) (b:=112) (f:=105) (s:=447) (U':=62652476986945811929574508085753525213325243476748757638370409819051066331429819908604545880040736669362770937694609989560289409637253984209373160098134477290043961183590474128343974265063328000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row105 {n k d : ℕ} (ak : 105≤k) (kb : k≤112) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  exact cell105_0 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

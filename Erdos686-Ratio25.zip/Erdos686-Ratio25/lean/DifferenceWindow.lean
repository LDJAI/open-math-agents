module
public import Valuation
public import Upper677
public import Mathlib.Tactic.Ring
@[expose] public section

namespace Erdos677DifferenceWindow
open Erdos677Valuation Finset

/-- The two floor endpoints of a difference window dominate the two
interval counts, losing at most one. This uses no equal-LCM assumption. -/
theorem difference_count {m n k q : ℕ} (hk : 0<k) (hm : n+k≤m) (hq : 0<q) :
    C m k q + C n k q ≤ C (m-n-k) (2*k-1) q + 1 := by
  let lo := m-n-k
  let hi := m-n-k+(2*k-1)
  have hl : lo+(n+k)=m := by dsimp [lo];omega
  have hh : hi+n+1=m+k := by dsimp [hi];omega
  have hlo : lo/q+(n+k)/q ≤ m/q := by
    rw [←hl]; exact Nat.div_add_div_le_add_div
  have hhi : (m+k)/q ≤ hi/q+n/q+1 := by
    apply Nat.le_of_lt_succ
    apply (Nat.div_lt_iff_lt_mul hq).mpr
    have hx := Nat.mod_add_div hi q
    have hy := Nat.mod_add_div n q
    have hrx := Nat.mod_lt hi hq
    have hry := Nat.mod_lt n hq
    rw [show (hi/q+n/q+1+1)*q=q*(hi/q)+q*(n/q)+2*q by ring]
    omega
  have h₁ := Nat.div_le_div_right (by omega : m≤m+k) (c:=q)
  have h₂ := Nat.div_le_div_right (by omega : n≤n+k) (c:=q)
  change (m+k)/q-m/q + ((n+k)/q-n/q) ≤ hi/q-lo/q+1
  omega

theorem layer {m n k p a : ℕ} (hk : 0<k) (hm : n+k≤m) (hp : p.Prime) (ha : 0<a)
    (h : M m k=M n k) :
    C m k (p^a)+C n k (p^a)+(2*k-1)/(p^a) ≤
      2*C (m-n-k) (2*k-1) (p^a) + (if p^a≤2*k-1 then 1 else 0) := by
  let q := p^a
  have hq : 0<q := Nat.pow_pos hp.pos
  have hc := difference_count (q:=q) hk hm hq
  have hl : (2*k-1)/q ≤ C (m-n-k) (2*k-1) q := by
    rw [count_formula _ _ _ hq]; omega
  by_cases hsmall : p^a≤2*k-1
  · rw [if_pos hsmall]; change _ ≤ 2*C (m-n-k) (2*k-1) q+1
    dsimp [q] at hc hl ⊢; omega
  · have hbig : 2*k-1<q := by dsimp [q];omega
    rw [if_neg hsmall, Nat.div_eq_of_lt hbig]
    have hm1 := count_big_le_one m k q (by omega)
    have hn1 := count_big_le_one n k q (by omega)
    have he : 0<C m k q ↔ 0<C n k q := by
      dsimp [q]; rw [count_pos_iff_dvd_M hp ha,count_pos_iff_dvd_M hp ha,h]
    dsimp [q] at *
    omega

theorem difference_product_dvd {m n k : ℕ} (hk : 0<k) (hm : n+k≤m) (h : M m k=M n k) :
    P m k * P n k * (2*k-1).factorial ∣
      P (m-n-k) (2*k-1)^2 * Erdos677UpperBound.U (2*k-1) := by
  let z := m-n-k
  let w := 2*k-1
  have hw : 0<w := by dsimp [w];omega
  have hnz (x j : ℕ) : P x j ≠ 0 := (Nat.ascFactorial_pos _ _).ne'
  apply (Nat.factorization_prime_le_iff_dvd
    (Nat.mul_ne_zero (Nat.mul_ne_zero (hnz _ _) (hnz _ _)) (Nat.factorial_ne_zero _))
    (Nat.mul_ne_zero (pow_ne_zero _ (hnz _ _)) (Erdos677UpperBound.U_ne_zero _))).mp
  intro p hp
  let b := p.log (m+k)+1
  have hlog (v : ℕ) (hv : v≤m+k) : p.log v<b := (Nat.log_mono_right hv).trans_lt (Nat.lt_succ_self _)
  have hb' : p.log w<b := hlog _ (by dsimp [w];omega)
  have hind : ∑ a ∈ Ico 1 b, (if p^a≤w then 1 else 0) = p.log w := by
    rw [Finset.sum_boole]
    have hh : (Ico 1 b).filter (fun a => p^a≤w) = Icc 1 (p.log w) := by
      ext a; simp only [mem_filter,mem_Ico,mem_Icc]
      constructor
      · rintro ⟨⟨ha,_⟩,hq⟩; exact ⟨ha,Nat.le_log_of_pow_le hp.one_lt hq⟩
      · rintro ⟨ha,hle⟩
        exact ⟨⟨ha,by omega⟩,(Nat.pow_le_pow_right hp.pos hle).trans (Nat.pow_log_le_self p hw.ne')⟩
    simp [hh,Nat.card_Icc]
  have hl := Finset.sum_le_sum (s:=Ico 1 b) (fun a ha => layer (p:=p) hk hm hp (by have := mem_Ico.mp ha; omega : 0<a) h)
  change ∑ a ∈ Ico 1 b, (C m k (p^a)+C n k (p^a)+w/(p^a)) ≤
      ∑ a ∈ Ico 1 b, (2*C z w (p^a)+(if p^a≤w then 1 else 0)) at hl
  simp only [sum_add_distrib,← Finset.mul_sum,hind] at hl
  change (P m k*P n k*w.factorial).factorization p ≤ (P z w^2*Erdos677UpperBound.U w).factorization p
  rw [Nat.factorization_mul (Nat.mul_ne_zero (hnz _ _) (hnz _ _)) (Nat.factorial_ne_zero _), Finsupp.add_apply,
    Nat.factorization_mul (hnz _ _) (hnz _ _), Finsupp.add_apply,
    Nat.factorization_mul (pow_ne_zero _ (hnz _ _)) (Erdos677UpperBound.U_ne_zero _), Finsupp.add_apply,
    Nat.factorization_pow,Finsupp.smul_apply,smul_eq_mul,Erdos677UpperBound.U_factorization _ hp,
    factorization_product_eq_sum_counts hp (hlog _ le_rfl),
    factorization_product_eq_sum_counts hp (hlog _ (by omega : n+k≤m+k)),
    factorization_product_eq_sum_counts hp (hlog (z+w) (by dsimp [z,w];omega)),
    Nat.factorization_factorial hp hb']
  exact hl

/-- An elementary factorial lower bound suitable for uniform estimates. -/
theorem factorial_power (w : ℕ) : w^w ≤ w.factorial * 4^w := by
  calc w^w ≤ (w+1)^w := Nat.pow_le_pow_left (by omega) _
       _ ≤ (w+1).ascFactorial w := Nat.pow_succ_le_ascFactorial _ _
       _ = _ := Nat.ascFactorial_eq_factorial_mul_choose w w
       _ ≤ w.factorial*2^(w+w) := Nat.mul_le_mul_left _ (Nat.choose_le_two_pow _ _)
       _ = _ := by rw [show w+w=2*w by omega, pow_mul]; rfl

/-- The squared window product gives a lower bound on the separation
which applies at every length, independently of prime-interval results. -/
theorem square_gap_height {m n k : ℕ} (hk : 0<k) (hm : n+k≤m) (h : M m k=M n k) :
    (n+1)*(2*k-1) ≤ 16*(m-n+k-1)^2 := by
  let w := 2*k-1
  let T := m-n+k-1
  let z := m-n-k
  have hw : 0<w := by dsimp [w];omega
  have hzw : z+w=T := by dsimp [z,w,T];omega
  have hp : ∀ x, 0<P x k := fun x => Nat.ascFactorial_pos _ _
  have hPz : 0<P z w := Nat.ascFactorial_pos _ _
  have hP : (n+1)^w ≤ P m k*P n k := calc
    _ ≤ (n+1)^(k+k) := Nat.pow_le_pow_right (by omega) (by dsimp [w];omega)
    _ = (n+1)^k*(n+1)^k := pow_add _ _ _
    _ ≤ _ := Nat.mul_le_mul ((Nat.pow_le_pow_left (by omega : n+1≤m+1) _).trans
      (Nat.pow_succ_le_ascFactorial _ _)) (Nat.pow_succ_le_ascFactorial _ _)
  have hZ : P z w ≤ T^w := by simpa only [P,hzw] using Nat.ascFactorial_le_pow_add z w
  have hd := difference_product_dvd hk hm h
  change P m k*P n k*w.factorial ∣ P z w^2*Erdos677UpperBound.U w at hd
  have hs := Nat.le_of_dvd (Nat.mul_pos (Nat.pow_pos hPz) (Erdos677UpperBound.U_pos _)) hd
  have hb : ((n+1)*w)^w ≤ (16*T^2)^w := calc
    _ = (n+1)^w*w^w := mul_pow _ _ _
    _ ≤ (P m k*P n k)*(w.factorial*4^w) := Nat.mul_le_mul hP (factorial_power w)
    _ = (P m k*P n k*w.factorial)*4^w := by rw [Nat.mul_assoc (P m k*P n k)]
    _ ≤ (P z w^2*Erdos677UpperBound.U w)*4^w := Nat.mul_le_mul_right _ hs
    _ ≤ ((T^w)^2*4^w)*4^w := Nat.mul_le_mul_right _ (Nat.mul_le_mul
      (Nat.pow_le_pow_left hZ _) (Erdos677UpperBound.U_le_four_pow w))
    _ = _ := by
      rw [←pow_mul, Nat.mul_comm w 2, pow_mul, Nat.mul_assoc, ←mul_pow, ←mul_pow]
      congr 1
      ring
  exact (Nat.pow_le_pow_iff_left hw.ne').mp hb

#print axioms square_gap_height
#print axioms difference_count
#print axioms difference_product_dvd
end Erdos677DifferenceWindow

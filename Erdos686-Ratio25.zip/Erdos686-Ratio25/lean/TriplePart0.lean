import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem small2 : allGaps 2 = true := by decide +kernel
theorem row2 {n k d : ℕ} (ak : 2≤k) (kb : k≤2) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=2 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small2
private theorem small3 : allGaps 3 = true := by decide +kernel
theorem row3 {n k d : ℕ} (ak : 3≤k) (kb : k≤3) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=3 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small3
private theorem small4 : allGaps 4 = true := by decide +kernel
theorem row4 {n k d : ℕ} (ak : 4≤k) (kb : k≤4) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=4 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small4
private theorem small5 : allGaps 5 = true := by decide +kernel
theorem row5 {n k d : ℕ} (ak : 5≤k) (kb : k≤5) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=5 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small5
end Ratio25.TripleBlocks

import Finite
import Strips
namespace Ratio25.Length22
open Strips
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private theorem high {n m : ℕ} (hn : 2714522912082776≤n) (hm : n<m) : block m 22 ≠ 25*block n 22 :=
  no_large (t:=2714522912082776) (d:=524288) (h:=[30917085447456612210676178848300323137541118851953251848760823007261591374337152243539552785608763921841331351817170117264680509909602311824071758273190585131420385730357200775, 125284608359073130123173261531523600802627989027787568022022624387424556943142470763725253870266985507066486303793238303461231748439505359011637918648850503149594, 230767270007946429611894704324088178553266860388342689618226846004023859279840155422017887495444931884398226667806998552222277675692432886044139000, 255036274308936639130616047260412267562336746184371642193002877281254424018478144367233776207140647065095778666324495214972547026480, 187905044509831379676663576151017244641976700381380755470694269821872334592119784675580531764310219423674025908640000, 96910975089880145464425372317376927077836175456144521424271144952548629147479730123331791471845690880, 35700923598218114893567673128886956975197166496761236280161605788818600717573114009600, 9394158951285808957471647667216722840574130116790240904540618968281088, 1730351751586045549318757817764859548669057589045657600, 212480769503911177425449887915506335744, 15655109673830665420800, 524288]) (sgn:=(1)) (by decide +kernel) hn hm
private theorem small {n m : ℕ} (hn : n<100) (hm : n+2≤m) : block m 22 ≠ 25*block n 22 :=
  separated_sound (l:=[1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 20, 21, 22, 23, 24, 25, 27, 28, 29, 30, 31, 32, 34, 35, 36, 37, 38, 39, 41, 42, 43, 44, 45, 46, 47, 49, 50, 51, 52, 53, 54, 56, 57, 58, 59, 60, 61, 63, 64, 65, 66, 67, 68, 70, 71, 72, 73, 74, 75, 76, 78, 79, 80, 81, 82, 83, 85, 86, 87, 88, 89, 90, 92, 93, 94, 95, 96, 97, 98, 100, 101, 102, 103, 104, 105, 107, 108, 109, 110, 111, 112, 114, 115, 116]) (t:=0) (by decide +kernel) (Nat.zero_le _) (by simpa using hn) hm
private theorem part0 {n m : ℕ} (ha : 100≤n) (hb : n≤199) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=22) (q:=19) (l:=(32)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part1 {n m : ℕ} (ha : 200≤n) (hb : n≤399) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=22) (q:=19) (l:=(31)) (cs:=[[327], []]) (by decide +kernel) ha hb
private theorem part2 {n m : ℕ} (ha : 400≤n) (hb : n≤799) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=22) (q:=19) (l:=(29)) (cs:=[[665], [501], []]) (by decide +kernel) ha hb
private theorem part3 {n m : ℕ} (ha : 800≤n) (hb : n≤1599) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=360) (q:=311) (l:=(561)) (cs:=[[919], [1458], []]) (by decide +kernel) ha hb
private theorem part4 {n m : ℕ} (ha : 1600≤n) (hb : n≤3199) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=360) (q:=311) (l:=(563)) (cs:=[[2437], []]) (by decide +kernel) ha hb
private theorem part5 {n m : ℕ} (ha : 3200≤n) (hb : n≤6399) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=360) (q:=311) (l:=(564)) (cs:=[[3857], [5534], []]) (by decide +kernel) ha hb
private theorem part6 {n m : ℕ} (ha : 6400≤n) (hb : n≤12799) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=2351) (q:=2031) (l:=(3678)) (cs:=[[6677], [10040], []]) (by decide +kernel) ha hb
private theorem part7 {n m : ℕ} (ha : 12800≤n) (hb : n≤25599) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=2351) (q:=2031) (l:=(3680)) (cs:=[[15094], [21515], []]) (by decide +kernel) ha hb
private theorem part8 {n m : ℕ} (ha : 25600≤n) (hb : n≤51199) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=9044) (q:=7813) (l:=(14153)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part9 {n m : ℕ} (ha : 51200≤n) (hb : n≤102399) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=9044) (q:=7813) (l:=(14152)) (cs:=[[83364], []]) (by decide +kernel) ha hb
private theorem part10 {n m : ℕ} (ha : 102400≤n) (hb : n≤204799) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=29483) (q:=25470) (l:=(46149)) (cs:=[[129717], [181858], []]) (by decide +kernel) ha hb
private theorem part11 {n m : ℕ} (ha : 204800≤n) (hb : n≤409599) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=29483) (q:=25470) (l:=(46151)) (cs:=[[243602], [311243], [382350], []]) (by decide +kernel) ha hb
private theorem part12 {n m : ℕ} (ha : 409600≤n) (hb : n≤819199) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=97493) (q:=84223) (l:=(152605)) (cs:=[[598573], []]) (by decide +kernel) ha hb
private theorem part13 {n m : ℕ} (ha : 819200≤n) (hb : n≤1638399) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=360489) (q:=311422) (l:=(564267)) (cs:=[[929442], []]) (by decide +kernel) ha hb
private theorem part14 {n m : ℕ} (ha : 1638400≤n) (hb : n≤3276799) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=360489) (q:=311422) (l:=(564268)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part15 {n m : ℕ} (ha : 3276800≤n) (hb : n≤6553599) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=360489) (q:=311422) (l:=(564266)) (cs:=[[5679255], [3541103], []]) (by decide +kernel) ha hb
private theorem part16 {n m : ℕ} (ha : 6553600≤n) (hb : n≤13107199) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=360489) (q:=311422) (l:=(564263)) (cs:=[[11333052], [9488362], [7614788], []]) (by decide +kernel) ha hb
private theorem part17 {n m : ℕ} (ha : 13107200≤n) (hb : n≤26214399) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=4160365) (q:=3594088) (l:=(6512183)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part18 {n m : ℕ} (ha : 26214400≤n) (hb : n≤52428799) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=4160365) (q:=3594088) (l:=(6512183)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part19 {n m : ℕ} (ha : 52428800≤n) (hb : n≤104857599) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=4160365) (q:=3594088) (l:=(6512181)) (cs:=[[104095431], [69272837], []]) (by decide +kernel) ha hb
private theorem part20 {n m : ℕ} (ha : 104857600≤n) (hb : n≤209715199) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=35182858) (q:=30394037) (l:=(55071440)) (cs:=[[109249827], [156989151], []]) (by decide +kernel) ha hb
private theorem part21 {n m : ℕ} (ha : 209715200≤n) (hb : n≤419430399) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=35182858) (q:=30394037) (l:=(55071442)) (cs:=[[220870112], [296534806], [379382973], []]) (by decide +kernel) ha hb
private theorem part22 {n m : ℕ} (ha : 419430400≤n) (hb : n≤838860799) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=109708939) (q:=94776199) (l:=(171726508)) (cs:=[[543826155, 668221911], []]) (by decide +kernel) ha hb
private theorem part23 {n m : ℕ} (ha : 838860800≤n) (hb : n≤1677721599) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=109708939) (q:=94776199) (l:=(171726509)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part24 {n m : ℕ} (ha : 1677721600≤n) (hb : n≤3355443199) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=109708939) (q:=94776199) (l:=(171726509)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part25 {n m : ℕ} (ha : 3355443200≤n) (hb : n≤6710886399) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=109708939) (q:=94776199) (l:=(171726508)) (cs:=[[3463021701], []]) (by decide +kernel) ha hb
private theorem part26 {n m : ℕ} (ha : 6710886400≤n) (hb : n≤13421772799) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=109708939) (q:=94776199) (l:=(171726506)) (cs:=[[12204117262], [7972220968], []]) (by decide +kernel) ha hb
private theorem part27 {n m : ℕ} (ha : 13421772800≤n) (hb : n≤26843545599) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=4752667235) (q:=4105770594) (l:=(7439311370)) (cs:=[[15848648610], [23534098339], []]) (by decide +kernel) ha hb
private theorem part28 {n m : ℕ} (ha : 26843545600≤n) (hb : n≤53687091199) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=4752667235) (q:=4105770594) (l:=(7439311372)) (cs:=[[34020005652], [46455999667], []]) (by decide +kernel) ha hb
private theorem part29 {n m : ℕ} (ha : 53687091200≤n) (hb : n≤107374182399) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=19120377879) (q:=16517858575) (l:=(29928971995)) (cs:=[[73290520040], [105795639721], []]) (by decide +kernel) ha hb
private theorem part30 {n m : ℕ} (ha : 107374182400≤n) (hb : n≤214748364799) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=19120377879) (q:=16517858575) (l:=(29928971997)) (cs:=[[146669583212], [192913723430], []]) (by decide +kernel) ha hb
private theorem part31 {n m : ℕ} (ha : 214748364800≤n) (hb : n≤429496729599) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=71728844281) (q:=61965663706) (l:=(112276576612)) (cs:=[[254122356846], [338153513643], []]) (by decide +kernel) ha hb
private theorem part32 {n m : ℕ} (ha : 429496729600≤n) (hb : n≤858993459199) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=124337310683) (q:=107413468837) (l:=(194624181225)) (cs:=[[739051595117], []]) (by decide +kernel) ha hb
private theorem part33 {n m : ℕ} (ha : 858993459200≤n) (hb : n≤1717986918399) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=124337310683) (q:=107413468837) (l:=(194624181223)) (cs:=[[1587929194315], [1197795962536], []]) (by decide +kernel) ha hb
private theorem part34 {n m : ℕ} (ha : 1717986918400≤n) (hb : n≤3435973836799) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=444740776330) (q:=384206070217) (l:=(696149120295)) (cs:=[[2442280665639], []]) (by decide +kernel) ha hb
private theorem part35 {n m : ℕ} (ha : 3435973836800≤n) (hb : n≤6871947673599) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=1209885018307) (q:=1045204741814) (l:=(1893823179666)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part36 {n m : ℕ} (ha : 6871947673600≤n) (hb : n≤13743895347199) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=1209885018307) (q:=1045204741814) (l:=(1893823179665)) (cs:=[[11361391024182], []]) (by decide +kernel) ha hb
private theorem part37 {n m : ℕ} (ha : 13743895347200≤n) (hb : n≤27487790694399) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=4394799296898) (q:=3796612897039) (l:=(6879143598377)) (cs:=[[27440292231782], []]) (by decide +kernel) ha hb
private theorem part38 {n m : ℕ} (ha : 27487790694400≤n) (hb : n≤54975581388799) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=4394799296898) (q:=3796612897039) (l:=(6879143598378)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part39 {n m : ℕ} (ha : 54975581388800≤n) (hb : n≤109951162777599) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=4394799296898) (q:=3796612897039) (l:=(6879143598378)) (cs:=[[70623734334708], []]) (by decide +kernel) ha hb
private theorem part40 {n m : ℕ} (ha : 109951162777600≤n) (hb : n≤219902325555199) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=4394799296898) (q:=3796612897039) (l:=(6879143598379)) (cs:=[[143093473084578], []]) (by decide +kernel) ha hb
private theorem part41 {n m : ℕ} (ha : 219902325555200≤n) (hb : n≤439804651110399) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=4394799296898) (q:=3796612897039) (l:=(6879143598380)) (cs:=[[224547611418904], [308564581925298], [393574910450379], []]) (by decide +kernel) ha hb
private theorem part42 {n m : ℕ} (ha : 439804651110400≤n) (hb : n≤879609302220799) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=200185738397024) (q:=172937989850383) (l:=(313349108286369)) (cs:=[[553968893709646], []]) (by decide +kernel) ha hb
private theorem part43 {n m : ℕ} (ha : 879609302220800≤n) (hb : n≤1759218604441599) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=200185738397024) (q:=172937989850383) (l:=(313349108286370)) (cs:=[[941056212136733], [1743865233003853], []]) (by decide +kernel) ha hb
private theorem part44 {n m : ℕ} (ha : 1759218604441600≤n) (hb : n≤2714522912082775) : block m 22 ≠ 25*block n 22 :=
  band_sound (p:=200185738397024) (q:=172937989850383) (l:=(313349108286372)) (cs:=[[]]) (by decide +kernel) ha hb
theorem exclusion {n m : ℕ} (hm : n+2≤m) : block m 22 ≠ 25*block n 22 := by
  by_cases hh : n<100
  · exact small hh hm
  by_cases h0 : n≤199
  · exact part0 (by omega) h0
  by_cases h1 : n≤399
  · exact part1 (by omega) h1
  by_cases h2 : n≤799
  · exact part2 (by omega) h2
  by_cases h3 : n≤1599
  · exact part3 (by omega) h3
  by_cases h4 : n≤3199
  · exact part4 (by omega) h4
  by_cases h5 : n≤6399
  · exact part5 (by omega) h5
  by_cases h6 : n≤12799
  · exact part6 (by omega) h6
  by_cases h7 : n≤25599
  · exact part7 (by omega) h7
  by_cases h8 : n≤51199
  · exact part8 (by omega) h8
  by_cases h9 : n≤102399
  · exact part9 (by omega) h9
  by_cases h10 : n≤204799
  · exact part10 (by omega) h10
  by_cases h11 : n≤409599
  · exact part11 (by omega) h11
  by_cases h12 : n≤819199
  · exact part12 (by omega) h12
  by_cases h13 : n≤1638399
  · exact part13 (by omega) h13
  by_cases h14 : n≤3276799
  · exact part14 (by omega) h14
  by_cases h15 : n≤6553599
  · exact part15 (by omega) h15
  by_cases h16 : n≤13107199
  · exact part16 (by omega) h16
  by_cases h17 : n≤26214399
  · exact part17 (by omega) h17
  by_cases h18 : n≤52428799
  · exact part18 (by omega) h18
  by_cases h19 : n≤104857599
  · exact part19 (by omega) h19
  by_cases h20 : n≤209715199
  · exact part20 (by omega) h20
  by_cases h21 : n≤419430399
  · exact part21 (by omega) h21
  by_cases h22 : n≤838860799
  · exact part22 (by omega) h22
  by_cases h23 : n≤1677721599
  · exact part23 (by omega) h23
  by_cases h24 : n≤3355443199
  · exact part24 (by omega) h24
  by_cases h25 : n≤6710886399
  · exact part25 (by omega) h25
  by_cases h26 : n≤13421772799
  · exact part26 (by omega) h26
  by_cases h27 : n≤26843545599
  · exact part27 (by omega) h27
  by_cases h28 : n≤53687091199
  · exact part28 (by omega) h28
  by_cases h29 : n≤107374182399
  · exact part29 (by omega) h29
  by_cases h30 : n≤214748364799
  · exact part30 (by omega) h30
  by_cases h31 : n≤429496729599
  · exact part31 (by omega) h31
  by_cases h32 : n≤858993459199
  · exact part32 (by omega) h32
  by_cases h33 : n≤1717986918399
  · exact part33 (by omega) h33
  by_cases h34 : n≤3435973836799
  · exact part34 (by omega) h34
  by_cases h35 : n≤6871947673599
  · exact part35 (by omega) h35
  by_cases h36 : n≤13743895347199
  · exact part36 (by omega) h36
  by_cases h37 : n≤27487790694399
  · exact part37 (by omega) h37
  by_cases h38 : n≤54975581388799
  · exact part38 (by omega) h38
  by_cases h39 : n≤109951162777599
  · exact part39 (by omega) h39
  by_cases h40 : n≤219902325555199
  · exact part40 (by omega) h40
  by_cases h41 : n≤439804651110399
  · exact part41 (by omega) h41
  by_cases h42 : n≤879609302220799
  · exact part42 (by omega) h42
  by_cases h43 : n≤1759218604441599
  · exact part43 (by omega) h43
  by_cases h44 : n≤2714522912082775
  · exact part44 (by omega) h44
  exact high (by omega) (by omega)
#print axioms exclusion
end Ratio25.Length22

import SmallGap
import Bound
namespace Ratio25.GivenBracket
open Erdos677SmallGap Erdos677Valuation

/-- A strict crossing between neighboring lower starts excludes every integer start. -/
def pair (k d t : ℕ) : Bool :=
  decide (P d k < 25*P 0 k) ||
   (decide (25*P t k < P (t+d) k) && decide (P (t+1+d) k < 25*P (t+1) k))

theorem sound {n k d t : ℕ} (hk : 0<k) (hd : 0<d) (c : pair k d t = true) :
    block (n+d) k≠25*block n k := by
  simp only [pair,Bool.or_eq_true,Bool.and_eq_true,decide_eq_true_eq] at c
  rcases c with h|⟨l,r⟩
  · simpa [P,block] using (reject_right (A:=1) (B:=25) (n:=n) (t:=0) (d:=d) (Nat.zero_le _) hd hk (by simpa using h))
  · by_cases hn : n≤t
    · simpa [P,block] using (reject_left (A:=1) (B:=25) hn hd hk (by decide) (by simpa using l))
    · simpa [P,block] using (reject_right (A:=1) (B:=25) (n:=n) (t:=t+1) (by omega) hd hk (by simpa using r))

def row (k d : ℕ) : List ℕ → Bool
  | [] => true
  | t::ts => pair k d t && row k (d+1) ts

theorem row_sound {k n : ℕ} (ts : List ℕ) (s d : ℕ) (hk : 0<k)
    (hd : 0<d) (lo : s≤d) (hi : d<s+ts.length) (c : row k s ts = true) :
    block (n+d) k≠25*block n k := by
  induction ts generalizing s with
  | nil => simp at hi;omega
  | cons t ts ih =>
    simp only [row,Bool.and_eq_true] at c
    simp only [List.length_cons] at hi
    by_cases hd' : s=d
    · subst s
      exact sound hk hd c.1
    · exact ih (s+1) (by omega) (by omega) c.2

end Ratio25.GivenBracket

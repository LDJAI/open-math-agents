import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem cell42_0 {n k d : ℕ} (ak : 42≤k) (kb : k≤42) (sd : k≤d) (lo : 42≤d) (hi : d≤97) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=42) (b:=42) (f:=42) (s:=138) (U':=239659860565130545615559086972088925228945148132416695184000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell42_1 {n k d : ℕ} (ak : 42≤k) (kb : k≤42) (sd : k≤d) (lo : 98≤d) (hi : d≤126) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=42) (b:=42) (f:=98) (s:=167) (U':=3203148300336176934962225892573533565278968596048507174063660957360528000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row42 {n k d : ℕ} (ak : 42≤k) (kb : k≤42) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤97
  · exact cell42_0 ak kb sd (by omega) c0
  exact cell42_1 ak kb sd (by omega) (by omega)
private theorem cell43_0 {n k d : ℕ} (ak : 43≤k) (kb : k≤43) (sd : k≤d) (lo : 43≤d) (hi : d≤106) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=43) (b:=43) (f:=43) (s:=148) (U':=33312720618553145840562713089120360606823375590405920630576000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell43_1 {n k d : ℕ} (ak : 43≤k) (kb : k≤43) (sd : k≤d) (lo : 107≤d) (hi : d≤129) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=43) (b:=43) (f:=107) (s:=171) (U':=41640927904370300154508936603455936348626591748630593262827592445686864000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row43 {n k d : ℕ} (ak : 43≤k) (kb : k≤43) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤106
  · exact cell43_0 ak kb sd (by omega) c0
  exact cell43_1 ak kb sd (by omega) (by omega)
private theorem cell44_0 {n k d : ℕ} (ak : 44≤k) (kb : k≤44) (sd : k≤d) (lo : 44≤d) (hi : d≤105) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=44) (b:=44) (f:=44) (s:=148) (U':=33312720618553145840562713089120360606823375590405920630576000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell44_1 {n k d : ℕ} (ak : 44≤k) (kb : k≤44) (sd : k≤d) (lo : 106≤d) (hi : d≤132) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=44) (b:=44) (f:=106) (s:=175) (U':=7203880527456061926730046032397876988312400372513092634469173493103827472000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row44 {n k d : ℕ} (ak : 44≤k) (kb : k≤44) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤105
  · exact cell44_0 ak kb sd (by omega) c0
  exact cell44_1 ak kb sd (by omega) (by omega)
private theorem cell45_0 {n k d : ℕ} (ak : 45≤k) (kb : k≤45) (sd : k≤d) (lo : 45≤d) (hi : d≤106) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=45) (b:=45) (f:=45) (s:=150) (U':=4963595372164418730243844250278933730416682962970482173955824000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell45_1 {n k d : ℕ} (ak : 45≤k) (kb : k≤45) (sd : k≤d) (lo : 107≤d) (hi : d≤135) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=45) (b:=45) (f:=107) (s:=179) (U':=1289494614414635084884678239799219980907919666679843581569982055265585117488000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row45 {n k d : ℕ} (ak : 45≤k) (kb : k≤45) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤106
  · exact cell45_0 ak kb sd (by omega) c0
  exact cell45_1 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

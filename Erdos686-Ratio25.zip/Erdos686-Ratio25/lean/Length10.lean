import Finite
import Strips
namespace Ratio25.Length10
open Strips
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private theorem high {n m : ℕ} (hn : 121683≤n) (hm : n<m) : block m 10 ≠ 25*block n 10 :=
  no_large (t:=121683) (d:=256) (h:=[6831052979777378436266801875, 280677836590275512356214, 4613054425152016720, 37908713037280, 155761280, 256]) (sgn:=(1)) (by decide +kernel) hn hm
private theorem small {n : ℕ} (hn : n<100) (m : ℕ) : block m 10 ≠ 25*block n 10 :=
  batch_sound (l:=[1, 2, 4, 5, 7, 8, 10, 11, 12, 14, 15, 17, 18, 19, 21, 22, 24, 25, 26, 28, 29, 30, 32, 33, 35, 36, 37, 39, 40, 42, 43, 44, 46, 47, 48, 50, 51, 53, 54, 55, 57, 58, 59, 61, 62, 64, 65, 66, 68, 69, 71, 72, 73, 75, 76, 77, 79, 80, 82, 83, 84, 86, 87, 88, 90, 91, 93, 94, 95, 97, 98, 100, 101, 102, 104, 105, 106, 108, 109, 111, 112, 113, 115, 116, 117, 119, 120, 122, 123, 124, 126, 127, 128, 130, 131, 133, 134, 135, 137, 138]) (t:=0) (by decide +kernel) (Nat.zero_le _) (by simpa using hn) m
private theorem part0 {n m : ℕ} (ha : 100≤n) (hb : n≤199) : block m 10 ≠ 25*block n 10 :=
  band_sound (p:=109) (q:=79) (l:=(162)) (cs:=[[110], []]) (by decide +kernel) ha hb
private theorem part1 {n m : ℕ} (ha : 200≤n) (hb : n≤399) : block m 10 ≠ 25*block n 10 :=
  band_sound (p:=109) (q:=79) (l:=(163)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part2 {n m : ℕ} (ha : 400≤n) (hb : n≤799) : block m 10 ≠ 25*block n 10 :=
  band_sound (p:=109) (q:=79) (l:=(163)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part3 {n m : ℕ} (ha : 800≤n) (hb : n≤1599) : block m 10 ≠ 25*block n 10 :=
  band_sound (p:=1021) (q:=740) (l:=(1542)) (cs:=[[807], [1393], []]) (by decide +kernel) ha hb
private theorem part4 {n m : ℕ} (ha : 1600≤n) (hb : n≤3199) : block m 10 ≠ 25*block n 10 :=
  band_sound (p:=1021) (q:=740) (l:=(1544)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part5 {n m : ℕ} (ha : 3200≤n) (hb : n≤6399) : block m 10 ≠ 25*block n 10 :=
  band_sound (p:=1021) (q:=740) (l:=(1544)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part6 {n m : ℕ} (ha : 6400≤n) (hb : n≤12799) : block m 10 ≠ 25*block n 10 :=
  band_sound (p:=1021) (q:=740) (l:=(1544)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part7 {n m : ℕ} (ha : 12800≤n) (hb : n≤25599) : block m 10 ≠ 25*block n 10 :=
  band_sound (p:=17248) (q:=12501) (l:=(26112)) (cs:=[[13907], [15433], [17030], [18685], [20390], [22136], [23917], []]) (by decide +kernel) ha hb
private theorem part8 {n m : ℕ} (ha : 25600≤n) (hb : n≤51199) : block m 10 ≠ 25*block n 10 :=
  band_sound (p:=27458) (q:=19901) (l:=(41561)) (cs:=[[35874, 46149], []]) (by decide +kernel) ha hb
private theorem part9 {n m : ℕ} (ha : 51200≤n) (hb : n≤102399) : block m 10 ≠ 25*block n 10 :=
  band_sound (p:=27458) (q:=19901) (l:=(41562)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part10 {n m : ℕ} (ha : 102400≤n) (hb : n≤121682) : block m 10 ≠ 25*block n 10 :=
  band_sound (p:=136269) (q:=98765) (l:=(206270)) (cs:=[[106265], []]) (by decide +kernel) ha hb
theorem exclusion {n m : ℕ} (hm : n<m) : block m 10 ≠ 25*block n 10 := by
  by_cases hh : n<100
  · exact small hh m
  by_cases h0 : n≤199
  · exact part0 (by omega) h0
  by_cases h1 : n≤399
  · exact part1 (by omega) h1
  by_cases h2 : n≤799
  · exact part2 (by omega) h2
  by_cases h3 : n≤1599
  · exact part3 (by omega) h3
  by_cases h4 : n≤3199
  · exact part4 (by omega) h4
  by_cases h5 : n≤6399
  · exact part5 (by omega) h5
  by_cases h6 : n≤12799
  · exact part6 (by omega) h6
  by_cases h7 : n≤25599
  · exact part7 (by omega) h7
  by_cases h8 : n≤51199
  · exact part8 (by omega) h8
  by_cases h9 : n≤102399
  · exact part9 (by omega) h9
  by_cases h10 : n≤121682
  · exact part10 (by omega) h10
  exact high (by omega) hm
#print axioms exclusion
end Ratio25.Length10

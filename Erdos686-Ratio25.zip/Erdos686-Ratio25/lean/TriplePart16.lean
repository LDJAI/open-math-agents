import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem cell66_0 {n k d : ℕ} (ak : 66≤k) (kb : k≤66) (sd : k≤d) (lo : 66≤d) (hi : d≤185) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=66) (b:=66) (f:=66) (s:=250) (U':=33216117145210841975416352095172082371056423324521218824612457552866313497868591504764276025256988217808000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell66_1 {n k d : ℕ} (ak : 66≤k) (kb : k≤66) (sd : k≤d) (lo : 186≤d) (hi : d≤198) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=66) (b:=66) (f:=186) (s:=263) (U':=1127045508128896902020104060541317662210121503881712278190339070464805071808486856136058134773218835496189985056000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row66 {n k d : ℕ} (ak : 66≤k) (kb : k≤66) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤185
  · exact cell66_0 ak kb sd (by omega) c0
  exact cell66_1 ak kb sd (by omega) (by omega)
private theorem cell67_0 {n k d : ℕ} (ak : 67≤k) (kb : k≤67) (sd : k≤d) (lo : 67≤d) (hi : d≤190) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=67) (b:=67) (f:=67) (s:=256) (U':=16674490806895842671659008751776385350270324508909651849955453691538889375930032935391666564679008085339616000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell67_1 {n k d : ℕ} (ak : 67≤k) (kb : k≤67) (sd : k≤d) (lo : 191≤d) (hi : d≤201) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=67) (b:=67) (f:=191) (s:=267) (U':=1127045508128896902020104060541317662210121503881712278190339070464805071808486856136058134773218835496189985056000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row67 {n k d : ℕ} (ak : 67≤k) (kb : k≤67) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤190
  · exact cell67_0 ak kb sd (by omega) c0
  exact cell67_1 ak kb sd (by omega) (by omega)
private theorem cell68_0 {n k d : ℕ} (ak : 68≤k) (kb : k≤68) (sd : k≤d) (lo : 68≤d) (hi : d≤195) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=68) (b:=68) (f:=68) (s:=262) (U':=4285344137372231566616365249206531035019473398789780525438551598725494569614018464395658307122505077932281312000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell68_1 {n k d : ℕ} (ak : 68≤k) (kb : k≤68) (sd : k≤d) (lo : 196≤d) (hi : d≤204) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=68) (b:=68) (f:=196) (s:=271) (U':=82160490497088455260363565909401516257455647511472943367797527897813824929766883325462501966832879888836753720597344000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row68 {n k d : ℕ} (ak : 68≤k) (kb : k≤68) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤195
  · exact cell68_0 ak kb sd (by omega) c0
  exact cell68_1 ak kb sd (by omega) (by omega)
private theorem cell69_0 {n k d : ℕ} (ak : 69≤k) (kb : k≤69) (sd : k≤d) (lo : 69≤d) (hi : d≤194) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=69) (b:=69) (f:=69) (s:=262) (U':=4285344137372231566616365249206531035019473398789780525438551598725494569614018464395658307122505077932281312000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell69_1 {n k d : ℕ} (ak : 69≤k) (kb : k≤69) (sd : k≤d) (lo : 195≤d) (hi : d≤207) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=69) (b:=69) (f:=195) (s:=275) (U':=82160490497088455260363565909401516257455647511472943367797527897813824929766883325462501966832879888836753720597344000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row69 {n k d : ℕ} (ak : 69≤k) (kb : k≤69) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤194
  · exact cell69_0 ak kb sd (by omega) c0
  exact cell69_1 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

import Bound
import Upper677
import Valuation

namespace Ratio25.Window
open Erdos677Valuation Erdos677UpperBound Finset

theorem choose_transfer {n k d s : ℕ} (he : block (n+d) k = s*block n k) :
    (n+d+k).choose k = s*(n+k).choose k := by
  simp only [block,Nat.ascFactorial_eq_factorial_mul_choose] at he
  apply Nat.eq_of_mul_eq_mul_left (Nat.factorial_pos k)
  simpa only [Nat.mul_assoc,Nat.mul_left_comm,Nat.mul_comm] using he

/-- The common binomial factor divides a single LCM built solely from differences. -/
theorem choose_window {n k d s : ℕ} (hk : 0<k) (hd : k≤d)
    (he : block (n+d) k = s*block n k) :
    k*(n+k).choose k ∣ M (d-k) (2*k-1) := by
  let c := k*(n+k).choose k
  have lower : c ∣ M n k := choose_dvd_L n k hk
  have upper : c ∣ M (n+d) k := by
    apply Dvd.dvd.trans _ (choose_dvd_L (n+d) k hk)
    rw [choose_transfer he]
    exact ⟨s,by dsimp [c];ring⟩
  rw [Nat.dvd_iff_prime_pow_dvd_dvd]
  intro p e hp hq
  by_cases ee : e=0
  · simp [ee]
  have own (y : ℕ) (hy : p^e∣M y k) : ∃ t ∈ Ioc y (y+k), p^e∣t := by
    exact primePow_dvd_finsetLcm hp (by omega) (fun v hv => by have := mem_Ioc.mp hv; simpa using (show v≠0 by omega)) hy
  obtain ⟨i,hi,he1⟩ := own n (hq.trans lower)
  obtain ⟨j,hj,he2⟩ := own (n+d) (hq.trans upper)
  have h1 := mem_Ioc.mp hi
  have h2 := mem_Ioc.mp hj
  have wx : j-i∈Ioc (d-k) ((d-k)+(2*k-1)) := by apply mem_Ioc.mpr;omega
  exact (Nat.dvd_sub he2 he1).trans (Finset.dvd_lcm (f:=id) wx)

#print axioms choose_window
end Ratio25.Window

import Strips
import Finite
open Ratio25 Ratio25.Strips
namespace Ratio25.Five
set_option maxHeartbeats 0
set_option maxRecDepth 100000
private theorem strip0 {n m : ℕ} (ha : 28147497671065600≤n) (hb : n≤56294995342131199) : block m 5≠25*block n 5 :=
  band_sound (p:=20280071663616216) (q:=10653234419957791) (l:=28880511730975274) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip1 {n m : ℕ} (ha : 56294995342131200≤n) (hb : n≤112589990684262399) : block m 5≠25*block n 5 :=
  band_sound (p:=20280071663616216) (q:=10653234419957791) (l:=28880511730975274) (cs:=[[69568132720903728], []]) (by decide +kernel) ha hb
private theorem strip2 {n m : ℕ} (ha : 112589990684262400≤n) (hb : n≤225179981368524799) : block m 5≠25*block n 5 :=
  band_sound (p:=20280071663616216) (q:=10653234419957791) (l:=28880511730975275) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip3 {n m : ℕ} (ha : 225179981368524800≤n) (hb : n≤450359962737049599) : block m 5≠25*block n 5 :=
  band_sound (p:=20280071663616216) (q:=10653234419957791) (l:=28880511730975275) (cs:=[[343676888318514506], []]) (by decide +kernel) ha hb
private theorem strip4 {n m : ℕ} (ha : 450359962737049600≤n) (hb : n≤900719925474099199) : block m 5≠25*block n 5 :=
  band_sound (p:=20280071663616216) (q:=10653234419957791) (l:=28880511730975276) (cs:=[[666451319262161178], []]) (by decide +kernel) ha hb
private theorem strip5 {n m : ℕ} (ha : 900719925474099200≤n) (hb : n≤1801439850948198399) : block m 5≠25*block n 5 :=
  band_sound (p:=621534351991854295) (q:=326495451379736659) (l:=885116701836352906) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip6 {n m : ℕ} (ha : 1801439850948198400≤n) (hb : n≤3602879701896396799) : block m 5≠25*block n 5 :=
  band_sound (p:=621534351991854295) (q:=326495451379736659) (l:=885116701836352904) (cs:=[[3241528042967887630], [2012540088726319753], []]) (by decide +kernel) ha hb
private theorem strip7 {n m : ℕ} (ha : 3602879701896396800≤n) (hb : n≤7205759403792793599) : block m 5≠25*block n 5 :=
  band_sound (p:=4391300607270212497) (q:=2306774628498072195) (l:=6253577936316420904) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip8 {n m : ℕ} (ha : 7205759403792793600≤n) (hb : n≤14411518807585587199) : block m 5≠25*block n 5 :=
  band_sound (p:=4391300607270212497) (q:=2306774628498072195) (l:=6253577936316420904) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip9 {n m : ℕ} (ha : 14411518807585587200≤n) (hb : n≤28823037615171174399) : block m 5≠25*block n 5 :=
  band_sound (p:=4391300607270212497) (q:=2306774628498072195) (l:=6253577936316420902) (cs:=[[26028475009217444324], [16327614750535525251], []]) (by decide +kernel) ha hb
private theorem strip10 {n m : ℕ} (ha : 28823037615171174400≤n) (hb : n≤57646075230342348799) : block m 5≠25*block n 5 :=
  band_sound (p:=34508870506169845681) (q:=18127701576604840901) (l:=49143506788695014339) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip11 {n m : ℕ} (ha : 57646075230342348800≤n) (hb : n≤115292150460684697599) : block m 5≠25*block n 5 :=
  band_sound (p:=34508870506169845681) (q:=18127701576604840901) (l:=49143506788695014339) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip12 {n m : ℕ} (ha : 115292150460684697600≤n) (hb : n≤230584300921369395199) : block m 5≠25*block n 5 :=
  band_sound (p:=34508870506169845681) (q:=18127701576604840901) (l:=49143506788695014339) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip13 {n m : ℕ} (ha : 230584300921369395200≤n) (hb : n≤461168601842738790399) : block m 5≠25*block n 5 :=
  band_sound (p:=34508870506169845681) (q:=18127701576604840901) (l:=49143506788695014339) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip14 {n m : ℕ} (ha : 461168601842738790400≤n) (hb : n≤922337203685477580799) : block m 5≠25*block n 5 :=
  band_sound (p:=34508870506169845681) (q:=18127701576604840901) (l:=49143506788695014338) (cs:=[[511045428178405580089], []]) (by decide +kernel) ha hb
private theorem strip15 {n m : ℕ} (ha : 922337203685477580800≤n) (hb : n≤1844674407370955161599) : block m 5≠25*block n 5 :=
  band_sound (p:=1015816029628375341341) (q:=533613809195593770482) (l:=1446606661298344712576) (cs:=[[1391043443482326555343], []]) (by decide +kernel) ha hb
private theorem strip16 {n m : ℕ} (ha : 1844674407370955161600≤n) (hb : n≤3689348814741910323199) : block m 5≠25*block n 5 :=
  band_sound (p:=1015816029628375341341) (q:=533613809195593770482) (l:=1446606661298344712577) (cs:=[[3229930140569565058961], []]) (by decide +kernel) ha hb
private theorem strip17 {n m : ℕ} (ha : 3689348814741910323200≤n) (hb : n≤7378697629483820646399) : block m 5≠25*block n 5 :=
  band_sound (p:=5113589018648046552386) (q:=2686196747554573693311) (l:=7282176813280418577224) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip18 {n m : ℕ} (ha : 7378697629483820646400≤n) (hb : n≤14757395258967641292799) : block m 5≠25*block n 5 :=
  band_sound (p:=5113589018648046552386) (q:=2686196747554573693311) (l:=7282176813280418577224) (cs:=[[9690484744994156606975], []]) (by decide +kernel) ha hb
private theorem strip19 {n m : ℕ} (ha : 14757395258967641292800≤n) (hb : n≤29514790517935282585599) : block m 5≠25*block n 5 :=
  band_sound (p:=5113589018648046552386) (q:=2686196747554573693311) (l:=7282176813280418577225) (cs:=[[28641298626763414453990], []]) (by decide +kernel) ha hb
private theorem strip20 {n m : ℕ} (ha : 29514790517935282585600≤n) (hb : n≤59029581035870565171199) : block m 5≠25*block n 5 :=
  band_sound (p:=5113589018648046552386) (q:=2686196747554573693311) (l:=7282176813280418577226) (cs:=[[52513465740744880368145], []]) (by decide +kernel) ha hb
private theorem strip21 {n m : ℕ} (ha : 59029581035870565171200≤n) (hb : n≤118059162071741130342399) : block m 5≠25*block n 5 :=
  band_sound (p:=50120074156852090182519) (q:=26328353666350143162628) (l:=71375161471505841059673) (cs:=[[96952515658128637883547], []]) (by decide +kernel) ha hb
private theorem strip22 {n m : ℕ} (ha : 118059162071741130342400≤n) (hb : n≤236118324143482260684799) : block m 5≠25*block n 5 :=
  band_sound (p:=145246633451908223995171) (q:=76298864251495855794573) (l:=206843307601237104601793) (cs:=[[184277270061862808442367], []]) (by decide +kernel) ha hb
private theorem strip23 {n m : ℕ} (ha : 236118324143482260684800≤n) (hb : n≤472236648286964521369599) : block m 5≠25*block n 5 :=
  band_sound (p:=145246633451908223995171) (q:=76298864251495855794573) (l:=206843307601237104601794) (cs:=[[406447424228724749465664], []]) (by decide +kernel) ha hb
theorem batch2 {n m : ℕ} (ha : 28147497671065600≤n) (hb : n≤472236648286964521369599) : block m 5≠25*block n 5 := by
  by_cases h0 : n≤56294995342131199
  · exact strip0 (by omega) h0
  by_cases h1 : n≤112589990684262399
  · exact strip1 (by omega) h1
  by_cases h2 : n≤225179981368524799
  · exact strip2 (by omega) h2
  by_cases h3 : n≤450359962737049599
  · exact strip3 (by omega) h3
  by_cases h4 : n≤900719925474099199
  · exact strip4 (by omega) h4
  by_cases h5 : n≤1801439850948198399
  · exact strip5 (by omega) h5
  by_cases h6 : n≤3602879701896396799
  · exact strip6 (by omega) h6
  by_cases h7 : n≤7205759403792793599
  · exact strip7 (by omega) h7
  by_cases h8 : n≤14411518807585587199
  · exact strip8 (by omega) h8
  by_cases h9 : n≤28823037615171174399
  · exact strip9 (by omega) h9
  by_cases h10 : n≤57646075230342348799
  · exact strip10 (by omega) h10
  by_cases h11 : n≤115292150460684697599
  · exact strip11 (by omega) h11
  by_cases h12 : n≤230584300921369395199
  · exact strip12 (by omega) h12
  by_cases h13 : n≤461168601842738790399
  · exact strip13 (by omega) h13
  by_cases h14 : n≤922337203685477580799
  · exact strip14 (by omega) h14
  by_cases h15 : n≤1844674407370955161599
  · exact strip15 (by omega) h15
  by_cases h16 : n≤3689348814741910323199
  · exact strip16 (by omega) h16
  by_cases h17 : n≤7378697629483820646399
  · exact strip17 (by omega) h17
  by_cases h18 : n≤14757395258967641292799
  · exact strip18 (by omega) h18
  by_cases h19 : n≤29514790517935282585599
  · exact strip19 (by omega) h19
  by_cases h20 : n≤59029581035870565171199
  · exact strip20 (by omega) h20
  by_cases h21 : n≤118059162071741130342399
  · exact strip21 (by omega) h21
  by_cases h22 : n≤236118324143482260684799
  · exact strip22 (by omega) h22
  exact strip23 (by omega) hb
end Ratio25.Five

import Bound

namespace Ratio25
namespace Strips

/-- Product at an integer start with integer spacing. -/
def ap (z s : ℤ) : ℕ → ℤ
  | 0 => 1
  | k+1 => (z+(k+1:ℕ)*s)*ap z s k

theorem evalScale (n q k : ℕ) :
    ap ((q:ℤ)*n) q k = (q:ℤ)^k*(block n k:ℤ) := by
  induction k with
  | zero => simp [ap,block]
  | succ k ih =>
    simp only [ap,ih,block,Nat.ascFactorial_succ,pow_succ,Nat.cast_mul,Nat.cast_add,Nat.cast_one]
    ring

theorem ap_mono {z y s : ℤ} (hz : 0≤z) (hzy : z≤y) (hs : 0≤s) (k : ℕ) :
    ap z s k ≤ ap y s k := by
  have pos (t : ℕ) : 0 ≤ ap z s t := by
    induction t with
    | zero => simp [ap]
    | succ t ih => simp only [ap]; exact mul_nonneg (by positivity) ih
  induction k with
  | zero => rfl
  | succ k ih =>
    simp only [ap]
    exact mul_le_mul (by omega) ih (pos k) (add_nonneg (hz.trans hzy) (mul_nonneg (Int.natCast_nonneg _) hs))

def affinePoly (z p q : ℤ) : ℕ → Coeff
  | 0 => [1]
  | k+1 => lin (z+(k+1:ℕ)*q) p 0 (affinePoly z p q k)

theorem affineEval (z p q x : ℤ) (k : ℕ) : ev (affinePoly z p q k) x = ap (z+p*x) q k := by
  induction k with
  | zero => simp [affinePoly,ev,ap]
  | succ k ih => simp only [affinePoly,ev_lin,ev,ih,ap]; ring

def lower (w : ℕ) : Coeff → ℤ
  | [] => 0
  | c::cs => c + min 0 ((w:ℤ)*lower w cs)

theorem lower_le {x : ℤ} {w : ℕ} (a : Coeff) (hx : 0≤x) (hxw : x≤w) : lower w a ≤ ev a x := by
  induction a with
  | nil => rfl
  | cons c cs ih =>
    simp only [lower,ev,add_le_add_iff_left]
    by_cases h : 0≤lower w cs
    · exact (min_le_left _ _).trans (mul_nonneg hx (h.trans ih))
    · exact (min_le_right _ _).trans ((mul_le_mul_of_nonpos_right hxw (by omega)).trans
        (mul_le_mul_of_nonneg_left ih hx))

def diff (k : ℕ) (p q j b dir : ℤ) : Coeff :=
  sub (affinePoly (p*b+j) (p*dir) q k)
    (scale 25 (affinePoly (q*b) (q*dir) q k))

def val (k : ℕ) (p q j n : ℤ) : ℤ := ap (p*n+j) q k - 25*ap (q*n) q k

theorem evalDiff (k : ℕ) (p q j b dir x : ℤ) :
    ev (diff k p q j b dir) x = val k p q j (b+dir*x) := by
  simp only [diff,val,ev_sub,ev_scale,affineEval]
  congr 2 <;> ring_nf

/-- A sign certificate can be read from either endpoint of an inclusive interval. -/
def signOK (k a b : ℕ) (p q j sign : ℤ) : Bool :=
  decide (0 < lower (b-a) (scale sign (diff k p q j a 1))) ||
  decide (0 < lower (b-a) (scale sign (diff k p q j b (-1))))

theorem sign_sound {k a b n : ℕ} {p q j sg : ℤ} (h : signOK k a b p q j sg = true)
    (ha : a≤n) (hb : n≤b) : 0 < sg*val k p q j n := by
  simp only [signOK,Bool.or_eq_true,decide_eq_true_eq] at h
  rcases h with h|h
  · have v := h.trans_le (lower_le _ (by omega : (0:ℤ)≤(n:ℤ)-a) (by omega))
    simpa only [ev_scale,evalDiff,one_mul,add_sub_cancel] using v
  · have v := h.trans_le (lower_le _ (by omega : (0:ℤ)≤(b:ℤ)-n) (by omega))
    rwa [ev_scale,evalDiff,show (b:ℤ)+(-1)*((b:ℤ)-n)=n by ring] at v

def clear (k a b : ℕ) (p q j : ℤ) : List ℕ → Bool
  | [] => signOK k a b p q j 1 || signOK k a b p q j (-1)
  | c::cs => (signOK k a c p q j 1 || signOK k a c p q j (-1)) &&
      clear k (c+1) b p q j cs

theorem clear_sound {k a b n : ℕ} {p q j : ℤ} {cs : List ℕ}
    (h : clear k a b p q j cs = true) (ha : a≤n) (hb : n≤b) : val k p q j n ≠ 0 := by
  have side {d e : ℕ} (hd : d≤n) (he : n≤e)
      (hh : signOK k d e p q j 1 = true ∨ signOK k d e p q j (-1) = true) :
      val k p q j n ≠ 0 := by
    rcases hh with hh|hh <;> have hh' := sign_sound hh hd he <;> omega
  induction cs generalizing a with
  | nil =>
    apply side ha hb
    simpa only [clear,Bool.or_eq_true] using h
  | cons c cs ih =>
    simp only [clear,Bool.or_eq_true,Bool.and_eq_true] at h
    by_cases hc : n≤c
    · exact side ha hc h.1
    · exact ih h.2 (by omega)

def inside (k a b : ℕ) (p q fromJ : ℤ) : List (List ℕ) → Bool
  | [] => true
  | cut::cuts => clear k a b p q fromJ cut && inside k a b p q (fromJ+1) cuts

theorem inside_sound {k a b n : ℕ} {p q j l : ℤ} {cs : List (List ℕ)}
    (h : inside k a b p q l cs = true) (ha : a≤n) (hb : n≤b) (hl : l≤j)
    (hu : j<l+(cs.length:ℤ)) : val k p q j n ≠ 0 := by
  induction cs generalizing l with
  | nil => simp at hu; omega
  | cons c cs ih =>
    simp only [inside,Bool.and_eq_true] at h
    by_cases eq : j=l
    · subst j; exact clear_sound h.1 ha hb
    · apply ih h.2 (by omega)
      simp only [List.length_cons,Nat.cast_add,Nat.cast_one] at hu
      omega

def band (k a b p q : ℕ) (l : ℤ) (cs : List (List ℕ)) : Bool :=
  decide (0≤(p:ℤ)*a+l) && signOK k a b p q l (-1) &&
    signOK k a b p q (l+1+cs.length) 1 && inside k a b p q (l+1) cs

theorem band_sound {k a b p q n m : ℕ} {l : ℤ} {cs : List (List ℕ)}
    (h : band k a b p q l cs = true) (ha : a≤n) (hb : n≤b) :
    block m k ≠ 25*block n k := by
  intro eqn
  simp only [band,Bool.and_eq_true,decide_eq_true_eq] at h
  obtain ⟨⟨⟨hz,hlo⟩,hhi⟩,hi⟩ := h
  let j : ℤ := (q:ℤ)*m-(p:ℤ)*n
  have hj : (p:ℤ)*n+j=(q:ℤ)*m := by dsimp [j]; ring
  have hv : val k p q j n = 0 := by
    rw [val,hj,evalScale,evalScale,eqn]; push_cast; ring
  have hbase : 0≤(p:ℤ)*n+l := by
    have := mul_le_mul_of_nonneg_left (show (a:ℤ)≤n by exact_mod_cast ha) (Int.natCast_nonneg p)
    omega
  have lb := sign_sound hlo ha hb
  have ub := sign_sound hhi ha hb
  have jl : l<j := by
    by_contra! no
    have z := ap_mono (z:=(q:ℤ)*m) (y:=(p:ℤ)*n+l) (by positivity) (by linarith only [hj,no]) (Int.natCast_nonneg q) k
    simp only [val,hj] at lb hv
    omega
  have ju : j<l+1+cs.length := by
    by_contra! no
    have z := ap_mono (z:=(p:ℤ)*n+(l+1+cs.length)) (y:=(q:ℤ)*m) (by omega) (by linarith only [hj,no]) (Int.natCast_nonneg q) k
    simp only [val,hj] at ub hv
    omega
  exact inside_sound hi ha hb (by omega) ju hv

end Strips
end Ratio25

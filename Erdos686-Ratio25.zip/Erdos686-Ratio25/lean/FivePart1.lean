import Strips
import Finite
open Ratio25 Ratio25.Strips
namespace Ratio25.Five
set_option maxHeartbeats 0
set_option maxRecDepth 100000
private theorem strip0 {n m : ℕ} (ha : 1677721600≤n) (hb : n≤3355443199) : block m 5≠25*block n 5 :=
  band_sound (p:=1190477407) (q:=625364402) (l:=1695339013) (cs:=[[2513119807], []]) (by decide +kernel) ha hb
private theorem strip1 {n m : ℕ} (ha : 3355443200≤n) (hb : n≤6710886399) : block m 5≠25*block n 5 :=
  band_sound (p:=1190477407) (q:=625364402) (l:=1695339013) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip2 {n m : ℕ} (ha : 6710886400≤n) (hb : n≤13421772799) : block m 5≠25*block n 5 :=
  band_sound (p:=6997757680) (q:=3675961023) (l:=9965389970) (cs:=[[9015563444], []]) (by decide +kernel) ha hb
private theorem strip3 {n m : ℕ} (ha : 13421772800≤n) (hb : n≤26843545599) : block m 5≠25*block n 5 :=
  band_sound (p:=6997757680) (q:=3675961023) (l:=9965389971) (cs:=[[20088097855], []]) (by decide +kernel) ha hb
private theorem strip4 {n m : ℕ} (ha : 26843545600≤n) (hb : n≤53687091199) : block m 5≠25*block n 5 :=
  band_sound (p:=29181508127) (q:=15329208494) (l:=41556898897) (cs:=[[40265318399]]) (by decide +kernel) ha hb
private theorem strip5 {n m : ℕ} (ha : 53687091200≤n) (hb : n≤107374182399) : block m 5≠25*block n 5 :=
  band_sound (p:=29181508127) (q:=15329208494) (l:=41556898897) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip6 {n m : ℕ} (ha : 107374182400≤n) (hb : n≤214748364799) : block m 5≠25*block n 5 :=
  band_sound (p:=152905298315) (q:=80322003493) (l:=217749884465) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip7 {n m : ℕ} (ha : 214748364800≤n) (hb : n≤429496729599) : block m 5≠25*block n 5 :=
  band_sound (p:=152905298315) (q:=80322003493) (l:=217749884465) (cs:=[[240903771537], []]) (by decide +kernel) ha hb
private theorem strip8 {n m : ℕ} (ha : 429496729600≤n) (hb : n≤858993459199) : block m 5≠25*block n 5 :=
  band_sound (p:=152905298315) (q:=80322003493) (l:=217749884466) (cs:=[[618089519185], []]) (by decide +kernel) ha hb
private theorem strip9 {n m : ℕ} (ha : 858993459200≤n) (hb : n≤1717986918399) : block m 5≠25*block n 5 :=
  band_sound (p:=946613298017) (q:=497261229452) (l:=1348056205693) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip10 {n m : ℕ} (ha : 1717986918400≤n) (hb : n≤3435973836799) : block m 5≠25*block n 5 :=
  band_sound (p:=2992745192366) (q:=1572105691849) (l:=4261918501549) (cs:=[[2223528532053], []]) (by decide +kernel) ha hb
private theorem strip11 {n m : ℕ} (ha : 3435973836800≤n) (hb : n≤6871947673599) : block m 5≠25*block n 5 :=
  band_sound (p:=2992745192366) (q:=1572105691849) (l:=4261918501550) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip12 {n m : ℕ} (ha : 6871947673600≤n) (hb : n≤13743895347199) : block m 5≠25*block n 5 :=
  band_sound (p:=2992745192366) (q:=1572105691849) (l:=4261918501550) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip13 {n m : ℕ} (ha : 13743895347200≤n) (hb : n≤27487790694399) : block m 5≠25*block n 5 :=
  band_sound (p:=2992745192366) (q:=1572105691849) (l:=4261918501550) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip14 {n m : ℕ} (ha : 27487790694400≤n) (hb : n≤54975581388799) : block m 5≠25*block n 5 :=
  band_sound (p:=2992745192366) (q:=1572105691849) (l:=4261918501550) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip15 {n m : ℕ} (ha : 54975581388800≤n) (hb : n≤109951162777599) : block m 5≠25*block n 5 :=
  band_sound (p:=2992745192366) (q:=1572105691849) (l:=4261918501549) (cs:=[[85098068488150], []]) (by decide +kernel) ha hb
private theorem strip16 {n m : ℕ} (ha : 109951162777600≤n) (hb : n≤219902325555199) : block m 5≠25*block n 5 :=
  band_sound (p:=2992745192366) (q:=1572105691849) (l:=4261918501548) (cs:=[[173552933104334], []]) (by decide +kernel) ha hb
private theorem strip17 {n m : ℕ} (ha : 219902325555200≤n) (hb : n≤439804651110399) : block m 5≠25*block n 5 :=
  band_sound (p:=166647117474479) (q:=87540657514092) (l:=237319379881160) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip18 {n m : ℕ} (ha : 439804651110400≤n) (hb : n≤879609302220799) : block m 5≠25*block n 5 :=
  band_sound (p:=166647117474479) (q:=87540657514092) (l:=237319379881159) (cs:=[[463548463317636], []]) (by decide +kernel) ha hb
private theorem strip19 {n m : ℕ} (ha : 879609302220800≤n) (hb : n≤1759218604441599) : block m 5≠25*block n 5 :=
  band_sound (p:=1163537077128987) (q:=611212496906795) (l:=1656973740666575) (cs:=[[1729105688960368], []]) (by decide +kernel) ha hb
private theorem strip20 {n m : ℕ} (ha : 1759218604441600≤n) (hb : n≤3518437208883199) : block m 5≠25*block n 5 :=
  band_sound (p:=1163537077128987) (q:=611212496906795) (l:=1656973740666576) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip21 {n m : ℕ} (ha : 3518437208883200≤n) (hb : n≤7036874417766399) : block m 5≠25*block n 5 :=
  band_sound (p:=1163537077128987) (q:=611212496906795) (l:=1656973740666576) (cs:=[[4252032089229329], []]) (by decide +kernel) ha hb
private theorem strip22 {n m : ℕ} (ha : 7036874417766400≤n) (hb : n≤14073748835532799) : block m 5≠25*block n 5 :=
  band_sound (p:=5984332503119414) (q:=3143603142048067) (l:=8522188083214038) (cs:=[[7687669150829499], []]) (by decide +kernel) ha hb
private theorem strip23 {n m : ℕ} (ha : 14073748835532800≤n) (hb : n≤28147497671065599) : block m 5≠25*block n 5 :=
  band_sound (p:=20280071663616216) (q:=10653234419957791) (l:=28880511730975273) (cs:=[[14082195384019805], []]) (by decide +kernel) ha hb
theorem batch1 {n m : ℕ} (ha : 1677721600≤n) (hb : n≤28147497671065599) : block m 5≠25*block n 5 := by
  by_cases h0 : n≤3355443199
  · exact strip0 (by omega) h0
  by_cases h1 : n≤6710886399
  · exact strip1 (by omega) h1
  by_cases h2 : n≤13421772799
  · exact strip2 (by omega) h2
  by_cases h3 : n≤26843545599
  · exact strip3 (by omega) h3
  by_cases h4 : n≤53687091199
  · exact strip4 (by omega) h4
  by_cases h5 : n≤107374182399
  · exact strip5 (by omega) h5
  by_cases h6 : n≤214748364799
  · exact strip6 (by omega) h6
  by_cases h7 : n≤429496729599
  · exact strip7 (by omega) h7
  by_cases h8 : n≤858993459199
  · exact strip8 (by omega) h8
  by_cases h9 : n≤1717986918399
  · exact strip9 (by omega) h9
  by_cases h10 : n≤3435973836799
  · exact strip10 (by omega) h10
  by_cases h11 : n≤6871947673599
  · exact strip11 (by omega) h11
  by_cases h12 : n≤13743895347199
  · exact strip12 (by omega) h12
  by_cases h13 : n≤27487790694399
  · exact strip13 (by omega) h13
  by_cases h14 : n≤54975581388799
  · exact strip14 (by omega) h14
  by_cases h15 : n≤109951162777599
  · exact strip15 (by omega) h15
  by_cases h16 : n≤219902325555199
  · exact strip16 (by omega) h16
  by_cases h17 : n≤439804651110399
  · exact strip17 (by omega) h17
  by_cases h18 : n≤879609302220799
  · exact strip18 (by omega) h18
  by_cases h19 : n≤1759218604441599
  · exact strip19 (by omega) h19
  by_cases h20 : n≤3518437208883199
  · exact strip20 (by omega) h20
  by_cases h21 : n≤7036874417766399
  · exact strip21 (by omega) h21
  by_cases h22 : n≤14073748835532799
  · exact strip22 (by omega) h22
  exact strip23 (by omega) hb
end Ratio25.Five

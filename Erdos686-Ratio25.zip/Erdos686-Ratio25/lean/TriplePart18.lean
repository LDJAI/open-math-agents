import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem cell74_0 {n k d : ℕ} (ak : 74≤k) (kb : k≤74) (sd : k≤d) (lo : 74≤d) (hi : d≤209) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=74) (b:=74) (f:=74) (s:=282) (U':=6395126098821874092100918879690085820931575235350519492919256178982134691058264897404024765592370871907386399350135464928000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell74_1 {n k d : ℕ} (ak : 74≤k) (kb : k≤74) (sd : k≤d) (lo : 210≤d) (hi : d≤222) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=74) (b:=74) (f:=210) (s:=295) (U':=9014716836799586623329573573945377845159029877980505339167320652785333649613624539473353602148614605570705738411136004478202144000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row74 {n k d : ℕ} (ak : 74≤k) (kb : k≤74) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤209
  · exact cell74_0 ak kb sd (by omega) c0
  exact cell74_1 ak kb sd (by omega) (by omega)
private theorem cell75_0 {n k d : ℕ} (ak : 75≤k) (kb : k≤75) (sd : k≤d) (lo : 75≤d) (hi : d≤214) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=75) (b:=75) (f:=75) (s:=288) (U':=1809820685966590368064560042952294287323635791604197016496149498651944117569488965965339008662640956749790351016088336574624000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell75_1 {n k d : ℕ} (ak : 75≤k) (kb : k≤75) (sd : k≤d) (lo : 215≤d) (hi : d≤225) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=75) (b:=75) (f:=215) (s:=299) (U':=9014716836799586623329573573945377845159029877980505339167320652785333649613624539473353602148614605570705738411136004478202144000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row75 {n k d : ℕ} (ak : 75≤k) (kb : k≤75) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤214
  · exact cell75_0 ak kb sd (by omega) c0
  exact cell75_1 ak kb sd (by omega) (by omega)
private theorem cell76_0 {n k d : ℕ} (ak : 76≤k) (kb : k≤76) (sd : k≤d) (lo : 76≤d) (hi : d≤217) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=76) (b:=76) (f:=76) (s:=292) (U':=30766951661432036257097520730189002884501808457271349280434541477083049998681312421410763147264896264746435967273501721768608000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell76_1 {n k d : ℕ} (ak : 76≤k) (kb : k≤76) (sd : k≤d) (lo : 218≤d) (hi : d≤228) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=76) (b:=76) (f:=218) (s:=303) (U':=9014716836799586623329573573945377845159029877980505339167320652785333649613624539473353602148614605570705738411136004478202144000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row76 {n k d : ℕ} (ak : 76≤k) (kb : k≤76) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤217
  · exact cell76_0 ak kb sd (by omega) c0
  exact cell76_1 ak kb sd (by omega) (by omega)
private theorem cell77_0 {n k d : ℕ} (ak : 77≤k) (kb : k≤77) (sd : k≤d) (lo : 77≤d) (hi : d≤230) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=77) (b:=77) (f:=77) (s:=306) (U':=9014716836799586623329573573945377845159029877980505339167320652785333649613624539473353602148614605570705738411136004478202144000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell77_1 {n k d : ℕ} (ak : 77≤k) (kb : k≤77) (sd : k≤d) (lo : 231≤d) (hi : d≤231) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=77) (b:=77) (f:=231) (s:=307) (U':=2767518068897473093362179087201230998463822172540015139124367440405097430431382733618319555859624683910206661692218753374808058208000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row77 {n k d : ℕ} (ak : 77≤k) (kb : k≤77) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤230
  · exact cell77_0 ak kb sd (by omega) c0
  exact cell77_1 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem cell46_0 {n k d : ℕ} (ak : 46≤k) (kb : k≤46) (sd : k≤d) (lo : 46≤d) (hi : d≤111) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=46) (b:=46) (f:=46) (s:=156) (U':=749502901196827228266820481792118993292919127408542808267329424000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell46_1 {n k d : ℕ} (ak : 46≤k) (kb : k≤46) (sd : k≤d) (lo : 112≤d) (hi : d≤138) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=46) (b:=46) (f:=112) (s:=183) (U':=233398525209048950364126761403658816544333459669051688264166752003070906265328000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row46 {n k d : ℕ} (ak : 46≤k) (kb : k≤46) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤111
  · exact cell46_0 ak kb sd (by omega) c0
  exact cell46_1 ak kb sd (by omega) (by omega)
private theorem cell47_0 {n k d : ℕ} (ak : 47≤k) (kb : k≤47) (sd : k≤d) (lo : 47≤d) (hi : d≤110) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=47) (b:=47) (f:=47) (s:=156) (U':=749502901196827228266820481792118993292919127408542808267329424000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell47_1 {n k d : ℕ} (ak : 47≤k) (kb : k≤47) (sd : k≤d) (lo : 111≤d) (hi : d≤141) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=47) (b:=47) (f:=111) (s:=187) (U':=233398525209048950364126761403658816544333459669051688264166752003070906265328000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row47 {n k d : ℕ} (ak : 47≤k) (kb : k≤47) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤110
  · exact cell47_0 ak kb sd (by omega) c0
  exact cell47_1 ak kb sd (by omega) (by omega)
private theorem cell48_0 {n k d : ℕ} (ak : 48≤k) (kb : k≤48) (sd : k≤d) (lo : 48≤d) (hi : d≤121) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=48) (b:=48) (f:=48) (s:=168) (U':=3203148300336176934962225892573533565278968596048507174063660957360528000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell48_1 {n k d : ℕ} (ak : 48≤k) (kb : k≤48) (sd : k≤d) (lo : 122≤d) (hi : d≤144) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=48) (b:=48) (f:=122) (s:=191) (U':=44579118314928349519548211428098833959967690796788872458455849632586543096677648000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row48 {n k d : ℕ} (ak : 48≤k) (kb : k≤48) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤121
  · exact cell48_0 ak kb sd (by omega) c0
  exact cell48_1 ak kb sd (by omega) (by omega)
private theorem cell49_0 {n k d : ℕ} (ak : 49≤k) (kb : k≤49) (sd : k≤d) (lo : 49≤d) (hi : d≤124) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=49) (b:=49) (f:=49) (s:=172) (U':=41640927904370300154508936603455936348626591748630593262827592445686864000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell49_1 {n k d : ℕ} (ak : 49≤k) (kb : k≤49) (sd : k≤d) (lo : 125≤d) (hi : d≤147) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=49) (b:=49) (f:=125) (s:=195) (U':=8603769834781171457272804805623074954273764323780252384481978979089202817658786064000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row49 {n k d : ℕ} (ak : 49≤k) (kb : k≤49) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤124
  · exact cell49_0 ak kb sd (by omega) c0
  exact cell49_1 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

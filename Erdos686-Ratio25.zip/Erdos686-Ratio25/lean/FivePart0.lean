import Strips
import Finite
open Ratio25 Ratio25.Strips
namespace Ratio25.Five
set_option maxHeartbeats 0
set_option maxRecDepth 100000
private theorem strip0 {n m : ℕ} (ha : 100≤n) (hb : n≤199) : block m 5≠25*block n 5 :=
  band_sound (p:=158) (q:=83) (l:=224) (cs:=[[183], []]) (by decide +kernel) ha hb
private theorem strip1 {n m : ℕ} (ha : 200≤n) (hb : n≤399) : block m 5≠25*block n 5 :=
  band_sound (p:=158) (q:=83) (l:=225) (cs:=[[390], []]) (by decide +kernel) ha hb
private theorem strip2 {n m : ℕ} (ha : 400≤n) (hb : n≤799) : block m 5≠25*block n 5 :=
  band_sound (p:=573) (q:=301) (l:=814) (cs:=[[444], []]) (by decide +kernel) ha hb
private theorem strip3 {n m : ℕ} (ha : 800≤n) (hb : n≤1599) : block m 5≠25*block n 5 :=
  band_sound (p:=573) (q:=301) (l:=815) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip4 {n m : ℕ} (ha : 1600≤n) (hb : n≤3199) : block m 5≠25*block n 5 :=
  band_sound (p:=573) (q:=301) (l:=815) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip5 {n m : ℕ} (ha : 3200≤n) (hb : n≤6399) : block m 5≠25*block n 5 :=
  band_sound (p:=573) (q:=301) (l:=814) (cs:=[[5630], []]) (by decide +kernel) ha hb
private theorem strip6 {n m : ℕ} (ha : 6400≤n) (hb : n≤12799) : block m 5≠25*block n 5 :=
  band_sound (p:=573) (q:=301) (l:=813) (cs:=[[11947], []]) (by decide +kernel) ha hb
private theorem strip7 {n m : ℕ} (ha : 12800≤n) (hb : n≤25599) : block m 5≠25*block n 5 :=
  band_sound (p:=11618) (q:=6103) (l:=16544) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip8 {n m : ℕ} (ha : 25600≤n) (hb : n≤51199) : block m 5≠25*block n 5 :=
  band_sound (p:=11618) (q:=6103) (l:=16544) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip9 {n m : ℕ} (ha : 51200≤n) (hb : n≤102399) : block m 5≠25*block n 5 :=
  band_sound (p:=11618) (q:=6103) (l:=16543) (cs:=[[73716], []]) (by decide +kernel) ha hb
private theorem strip10 {n m : ℕ} (ha : 102400≤n) (hb : n≤204799) : block m 5≠25*block n 5 :=
  band_sound (p:=11618) (q:=6103) (l:=16542) (cs:=[[162109], []]) (by decide +kernel) ha hb
private theorem strip11 {n m : ℕ} (ha : 204800≤n) (hb : n≤409599) : block m 5≠25*block n 5 :=
  band_sound (p:=162079) (q:=85141) (l:=230812) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip12 {n m : ℕ} (ha : 409600≤n) (hb : n≤819199) : block m 5≠25*block n 5 :=
  band_sound (p:=474619) (q:=249320) (l:=675896) (cs:=[[731155], []]) (by decide +kernel) ha hb
private theorem strip13 {n m : ℕ} (ha : 819200≤n) (hb : n≤1638399) : block m 5≠25*block n 5 :=
  band_sound (p:=474619) (q:=249320) (l:=675897) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip14 {n m : ℕ} (ha : 1638400≤n) (hb : n≤3276799) : block m 5≠25*block n 5 :=
  band_sound (p:=474619) (q:=249320) (l:=675897) (cs:=[[1845330], [3274521], []]) (by decide +kernel) ha hb
private theorem strip15 {n m : ℕ} (ha : 3276800≤n) (hb : n≤6553599) : block m 5≠25*block n 5 :=
  band_sound (p:=3009793) (q:=1581061) (l:=4286195) (cs:=[[5765413], []]) (by decide +kernel) ha hb
private theorem strip16 {n m : ℕ} (ha : 6553600≤n) (hb : n≤13107199) : block m 5≠25*block n 5 :=
  band_sound (p:=3009793) (q:=1581061) (l:=4286196) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip17 {n m : ℕ} (ha : 13107200≤n) (hb : n≤26214399) : block m 5≠25*block n 5 :=
  band_sound (p:=3009793) (q:=1581061) (l:=4286196) (cs:=[[17186965], []]) (by decide +kernel) ha hb
private theorem strip18 {n m : ℕ} (ha : 26214400≤n) (hb : n≤52428799) : block m 5≠25*block n 5 :=
  band_sound (p:=29623311) (q:=15561290) (l:=42186062) (cs:=[[40957581], []]) (by decide +kernel) ha hb
private theorem strip19 {n m : ℕ} (ha : 52428800≤n) (hb : n≤104857599) : block m 5≠25*block n 5 :=
  band_sound (p:=29623311) (q:=15561290) (l:=42186063) (cs:=[[95733219], []]) (by decide +kernel) ha hb
private theorem strip20 {n m : ℕ} (ha : 104857600≤n) (hb : n≤209715199) : block m 5≠25*block n 5 :=
  band_sound (p:=145106762) (q:=76225389) (l:=206644117) (cs:=[[134623220], []]) (by decide +kernel) ha hb
private theorem strip21 {n m : ℕ} (ha : 209715200≤n) (hb : n≤419430399) : block m 5≠25*block n 5 :=
  band_sound (p:=145106762) (q:=76225389) (l:=206644118) (cs:=[[]]) (by decide +kernel) ha hb
private theorem strip22 {n m : ℕ} (ha : 419430400≤n) (hb : n≤838860799) : block m 5≠25*block n 5 :=
  band_sound (p:=145106762) (q:=76225389) (l:=206644117) (cs:=[[478522519], []]) (by decide +kernel) ha hb
private theorem strip23 {n m : ℕ} (ha : 838860800≤n) (hb : n≤1677721599) : block m 5≠25*block n 5 :=
  band_sound (p:=1190477407) (q:=625364402) (l:=1695339013) (cs:=[[1311954795], []]) (by decide +kernel) ha hb
theorem batch0 {n m : ℕ} (ha : 100≤n) (hb : n≤1677721599) : block m 5≠25*block n 5 := by
  by_cases h0 : n≤199
  · exact strip0 (by omega) h0
  by_cases h1 : n≤399
  · exact strip1 (by omega) h1
  by_cases h2 : n≤799
  · exact strip2 (by omega) h2
  by_cases h3 : n≤1599
  · exact strip3 (by omega) h3
  by_cases h4 : n≤3199
  · exact strip4 (by omega) h4
  by_cases h5 : n≤6399
  · exact strip5 (by omega) h5
  by_cases h6 : n≤12799
  · exact strip6 (by omega) h6
  by_cases h7 : n≤25599
  · exact strip7 (by omega) h7
  by_cases h8 : n≤51199
  · exact strip8 (by omega) h8
  by_cases h9 : n≤102399
  · exact strip9 (by omega) h9
  by_cases h10 : n≤204799
  · exact strip10 (by omega) h10
  by_cases h11 : n≤409599
  · exact strip11 (by omega) h11
  by_cases h12 : n≤819199
  · exact strip12 (by omega) h12
  by_cases h13 : n≤1638399
  · exact strip13 (by omega) h13
  by_cases h14 : n≤3276799
  · exact strip14 (by omega) h14
  by_cases h15 : n≤6553599
  · exact strip15 (by omega) h15
  by_cases h16 : n≤13107199
  · exact strip16 (by omega) h16
  by_cases h17 : n≤26214399
  · exact strip17 (by omega) h17
  by_cases h18 : n≤52428799
  · exact strip18 (by omega) h18
  by_cases h19 : n≤104857599
  · exact strip19 (by omega) h19
  by_cases h20 : n≤209715199
  · exact strip20 (by omega) h20
  by_cases h21 : n≤419430399
  · exact strip21 (by omega) h21
  by_cases h22 : n≤838860799
  · exact strip22 (by omega) h22
  exact strip23 (by omega) hb
end Ratio25.Five

import Finite
import Strips
namespace Ratio25.Length24
open Strips
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private theorem high {n m : ℕ} (hn : 1136743≤n) (hm : n<m) : block m 24 ≠ 25*block n 24 :=
  no_large (t:=1136743) (d:=1) (h:=[4655912068281193875448256228060886037114553474418356355983124132758063136, 49149482735246129828827334941166779846766269538197497569595564990384, 237801492979771195805733486549627152109120992860131473072738424, 697310585512850307906642724825839670659767194112452420200, 1380199011525543272154012430086586593421781867382400, 1942650304742734078767626288182631413422028014, 1993766782372313647751264287190149844171, 1503351385894266872522691254190246, 826558231912303322268945555, 323164668380281453290, 85286062407209, 13641066, 1]) (sgn:=(1)) (by decide +kernel) hn hm
private theorem small {n m : ℕ} (hn : n<100) (hm : n+2≤m) : block m 24 ≠ 25*block n 24 :=
  separated_sound (l:=[0, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 14, 15, 16, 17, 18, 19, 21, 22, 23, 24, 25, 26, 27, 29, 30, 31, 32, 33, 34, 35, 37, 38, 39, 40, 41, 42, 43, 45, 46, 47, 48, 49, 50, 51, 53, 54, 55, 56, 57, 58, 60, 61, 62, 63, 64, 65, 66, 68, 69, 70, 71, 72, 73, 74, 76, 77, 78, 79, 80, 81, 82, 84, 85, 86, 87, 88, 89, 90, 92, 93, 94, 95, 96, 97, 98, 100, 101, 102, 103, 104, 105, 106, 108, 109, 110, 111, 112, 113, 114]) (t:=0) (by decide +kernel) (Nat.zero_le _) (by simpa using hn) hm
private theorem part0 {n m : ℕ} (ha : 100≤n) (hb : n≤199) : block m 24 ≠ 25*block n 24 :=
  band_sound (p:=8) (q:=7) (l:=(12)) (cs:=[[152], []]) (by decide +kernel) ha hb
private theorem part1 {n m : ℕ} (ha : 200≤n) (hb : n≤399) : block m 24 ≠ 25*block n 24 :=
  band_sound (p:=8) (q:=7) (l:=(13)) (cs:=[[333], []]) (by decide +kernel) ha hb
private theorem part2 {n m : ℕ} (ha : 400≤n) (hb : n≤799) : block m 24 ≠ 25*block n 24 :=
  band_sound (p:=8) (q:=7) (l:=(14)) (cs:=[[535], [743], []]) (by decide +kernel) ha hb
private theorem part3 {n m : ℕ} (ha : 800≤n) (hb : n≤1599) : block m 24 ≠ 25*block n 24 :=
  band_sound (p:=8) (q:=7) (l:=(16)) (cs:=[[953], [1163], [1374], [1586], []]) (by decide +kernel) ha hb
private theorem part4 {n m : ℕ} (ha : 1600≤n) (hb : n≤3199) : block m 24 ≠ 25*block n 24 :=
  band_sound (p:=486) (q:=425) (l:=(761)) (cs:=[[2737], []]) (by decide +kernel) ha hb
private theorem part5 {n m : ℕ} (ha : 3200≤n) (hb : n≤6399) : block m 24 ≠ 25*block n 24 :=
  band_sound (p:=486) (q:=425) (l:=(762)) (cs:=[[5510], []]) (by decide +kernel) ha hb
private theorem part6 {n m : ℕ} (ha : 6400≤n) (hb : n≤12799) : block m 24 ≠ 25*block n 24 :=
  band_sound (p:=486) (q:=425) (l:=(763)) (cs:=[[9846], []]) (by decide +kernel) ha hb
private theorem part7 {n m : ℕ} (ha : 12800≤n) (hb : n≤25599) : block m 24 ≠ 25*block n 24 :=
  band_sound (p:=486) (q:=425) (l:=(764)) (cs:=[[14871], [20149], [25535], []]) (by decide +kernel) ha hb
private theorem part8 {n m : ℕ} (ha : 25600≤n) (hb : n≤51199) : block m 24 ≠ 25*block n 24 :=
  band_sound (p:=6557) (q:=5734) (l:=(10288)) (cs:=[[32783], [42144], []]) (by decide +kernel) ha hb
private theorem part9 {n m : ℕ} (ha : 51200≤n) (hb : n≤102399) : block m 24 ≠ 25*block n 24 :=
  band_sound (p:=12628) (q:=11043) (l:=(19809)) (cs:=[[79912], []]) (by decide +kernel) ha hb
private theorem part10 {n m : ℕ} (ha : 102400≤n) (hb : n≤204799) : block m 24 ≠ 25*block n 24 :=
  band_sound (p:=12628) (q:=11043) (l:=(19808)) (cs:=[[150282], []]) (by decide +kernel) ha hb
private theorem part11 {n m : ℕ} (ha : 204800≤n) (hb : n≤409599) : block m 24 ≠ 25*block n 24 :=
  band_sound (p:=57069) (q:=49906) (l:=(89535)) (cs:=[[230195], []]) (by decide +kernel) ha hb
private theorem part12 {n m : ℕ} (ha : 409600≤n) (hb : n≤819199) : block m 24 ≠ 25*block n 24 :=
  band_sound (p:=57069) (q:=49906) (l:=(89536)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part13 {n m : ℕ} (ha : 819200≤n) (hb : n≤1136742) : block m 24 ≠ 25*block n 24 :=
  band_sound (p:=57069) (q:=49906) (l:=(89536)) (cs:=[[]]) (by decide +kernel) ha hb
theorem exclusion {n m : ℕ} (hm : n+2≤m) : block m 24 ≠ 25*block n 24 := by
  by_cases hh : n<100
  · exact small hh hm
  by_cases h0 : n≤199
  · exact part0 (by omega) h0
  by_cases h1 : n≤399
  · exact part1 (by omega) h1
  by_cases h2 : n≤799
  · exact part2 (by omega) h2
  by_cases h3 : n≤1599
  · exact part3 (by omega) h3
  by_cases h4 : n≤3199
  · exact part4 (by omega) h4
  by_cases h5 : n≤6399
  · exact part5 (by omega) h5
  by_cases h6 : n≤12799
  · exact part6 (by omega) h6
  by_cases h7 : n≤25599
  · exact part7 (by omega) h7
  by_cases h8 : n≤51199
  · exact part8 (by omega) h8
  by_cases h9 : n≤102399
  · exact part9 (by omega) h9
  by_cases h10 : n≤204799
  · exact part10 (by omega) h10
  by_cases h11 : n≤409599
  · exact part11 (by omega) h11
  by_cases h12 : n≤819199
  · exact part12 (by omega) h12
  by_cases h13 : n≤1136742
  · exact part13 (by omega) h13
  exact high (by omega) (by omega)
#print axioms exclusion
end Ratio25.Length24

import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem cell83_0 {n k d : ℕ} (ak : 83≤k) (kb : k≤84) (sd : k≤d) (lo : 83≤d) (hi : d≤252) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=83) (b:=84) (f:=83) (s:=335) (U':=28267177603641315818548350597251453705440610522416948760578038293010258114761174198524830065356160617087252341220048549067201017385700801888000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row83 {n k d : ℕ} (ak : 83≤k) (kb : k≤84) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  exact cell83_0 ak kb sd (by omega) (by omega)
private theorem cell85_0 {n k d : ℕ} (ak : 85≤k) (kb : k≤86) (sd : k≤d) (lo : 85≤d) (hi : d≤258) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=85) (b:=86) (f:=85) (s:=343) (U':=66682271966989864015955559058916179291134400222381582126203592333211198892721609934320074124175182895708828272938094527249527200012868191653792000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row85 {n k d : ℕ} (ak : 85≤k) (kb : k≤86) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  exact cell85_0 ak kb sd (by omega) (by omega)
private theorem cell87_0 {n k d : ℕ} (ak : 87≤k) (kb : k≤88) (sd : k≤d) (lo : 87≤d) (hi : d≤264) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=87) (b:=88) (f:=87) (s:=351) (U':=8075423182018373501924266068711926060694249270131076740229633642328875819505265127875963936659987174219026230337622061533499492503158376613849172576000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row87 {n k d : ℕ} (ak : 87≤k) (kb : k≤88) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  exact cell87_0 ak kb sd (by omega) (by omega)
private theorem cell89_0 {n k d : ℕ} (ak : 89≤k) (kb : k≤91) (sd : k≤d) (lo : 89≤d) (hi : d≤273) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=89) (b:=91) (f:=89) (s:=363) (U':=19444108918165205956788772855703468823978402417862118279122534869236817473590430943346408354221093697917836204747920788847160013542507280269722017767736288000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row89 {n k d : ℕ} (ak : 89≤k) (kb : k≤91) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  exact cell89_0 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

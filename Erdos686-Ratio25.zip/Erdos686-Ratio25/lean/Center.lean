import Finite
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Tactic.FieldSimp

namespace Ratio25

def center (n k : ℕ) := 2*n+k+1

theorem peel (n k : ℕ) : block n (k+2) = ((n+1)*(n+k+2))*block (n+1) k := by
  calc _ = (n+1+(k+1))*block n (k+1) := rfl
       _ = (n+1+(k+1))*((n+1)*block (n+1) k) := by
         congr 1
         change (n+1+k)*(n+1).ascFactorial k = (n+1)*(n+1+1).ascFactorial k
         rw [Nat.succ_ascFactorial]
       _ = _ := by ring

theorem centered_le (k n d : ℕ) : center (n+d) k ^ k * block n k ≤
    center n k ^ k * block (n+d) k := by
  induction k using Nat.twoStepInduction generalizing n with
  | zero => simp [block]
  | one => simp [center,block,Nat.ascFactorial]; nlinarith
  | more k ih _ =>
    have mid := ih (n+1)
    have nc : center (n+1) k = center n (k+2) := by simp [center]; omega
    have mc : center (n+1+d) k = center (n+d) (k+2) := by simp [center]; omega
    rw [nc,mc,show n+1+d=n+d+1 by omega] at mid
    have edges : center (n+d) (k+2)^2*((n+1)*(n+k+2)) ≤
        center n (k+2)^2*((n+d+1)*(n+d+k+2)) := by
      have eq : center n (k+2)^2*((n+d+1)*(n+d+k+2)) =
          center (n+d) (k+2)^2*((n+1)*(n+k+2))+d*(2*n+d+k+3)*(k+1)^2 := by unfold center; ring
      omega
    rw [peel,peel,pow_add,pow_add]
    simpa only [Nat.mul_comm,Nat.mul_assoc,Nat.mul_left_comm] using Nat.mul_le_mul mid edges

theorem center_power {k n d : ℕ} (h : block (n+d) k = 25*block n k) :
    (center n k + 2*d)^k ≤ 25*(center n k)^k := by
  have r := centered_le k n d
  rw [h,show center (n+d) k=center n k+2*d by unfold center; ring] at r
  exact Nat.le_of_mul_le_mul_right (by simpa only [Nat.mul_comm,Nat.mul_left_comm,Nat.mul_assoc] using r) (block_pos n k)

theorem uniform_bound {k n d l c : ℕ} (hc : 0<c) (hl : 25*c^l < (c+1)^l)
    (h : block (n+d) k = 25*block n k) : 2*c*(k/l)*d < center n k := by
  let x : ℚ := (center n k : ℕ)
  have hx : 0<x := by dsimp [x,center]; positivity
  let z : ℚ := 2*d/x
  have hz : 0≤z := by dsimp [z]; positivity
  have hp := center_power h
  have hp' : (1+z)^k ≤ 25 := by
    have eq : 1+z=(x+2*d)/x := by dsimp [z]; field_simp
    rw [eq,div_pow,div_le_iff₀ (pow_pos hx k)]
    dsimp [x]; exact_mod_cast hp
  by_contra! no
  have hno : x ≤ 2*(c:ℚ)*(k/l:ℕ)*d := by dsimp [x]; exact_mod_cast no
  have main : (c:ℚ)+1 ≤ c*(1+z)^(k/l) := by
    have e := one_add_mul_le_pow (show (-2:ℚ)≤z by linarith) (k/l)
    have low : 1 ≤ (c:ℚ)*(k/l:ℕ)*z := by
      dsimp [z]; rw [← mul_div_assoc,le_div_iff₀ hx]; linarith only [hno]
    linarith only [low, mul_le_mul_of_nonneg_left e (show (0:ℚ)≤c by positivity)]
  have big := pow_le_pow_left₀ (show 0≤(c:ℚ)+1 by positivity) main l
  rw [mul_pow,← pow_mul] at big
  have lengthBound : (k/l)*l≤k := Nat.div_mul_le_self _ _
  have limit := (pow_le_pow_right₀ (show (1:ℚ)≤1+z by linarith) lengthBound).trans hp'
  have bad := big.trans (mul_le_mul_of_nonneg_left limit (show 0≤(c:ℚ)^l by positivity))
  have lit : 25*(c:ℚ)^l < ((c:ℚ)+1)^l := by exact_mod_cast hl
  linarith only [bad,lit]

theorem lower_start {k n d : ℕ} (h : block (n+d) k = 25*block n k) :
    158*(k/256)*d < 2*n+k+1 := by
  exact uniform_bound (l:=256) (c:=79) (by decide) (by decide +kernel) h

#print axioms lower_start
end Ratio25

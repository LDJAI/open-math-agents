module

public import SmallGap
public import Upper677
public import Mathlib.Tactic.Ring

@[expose] public section

namespace Erdos677PrimePower
open Finset Erdos677Valuation Erdos677TransportSecond

theorem gap_dvd_difference_product {n k d A B : ℕ} (hk : 2≤k) (hsep : k≤d)
    (hA : 0<A) (hProd : A*P (n+d) k=B*P n k) :
    A<B ∧ d ∣ (B-A)*P n k := by
  have hz : 0<k := by omega
  have hab : A<B := by
    have hh := cross_scaled_entry_lt (i:=0) (j:=0) (by omega : n+k ≤ n+d) hk hz hz hA hProd
    by_contra! h
    exact (not_lt_of_ge (Nat.mul_le_mul h (by omega))) hh
  refine ⟨hab,?_⟩
  have hd : (d : ℤ) ∣ (∏ t ∈ range k, ((n : ℤ)+(d : ℤ)+1+(t : ℤ))) -
        (∏ t ∈ range k, ((n : ℤ)+1+(t : ℤ))) := by
    apply dvd_prod_diff
    intro t ht
    exact ⟨1,by ring⟩
  have he := congrArg (fun x : ℕ => (x : ℤ)) hProd
  simp only [P,Nat.cast_mul,ascFactorial_cast_eq_prod,Nat.cast_add] at he
  have hm := dvd_mul_of_dvd_right hd (A : ℤ)
  rw [mul_sub,he,← sub_mul,← Nat.cast_sub hab.le,← ascFactorial_cast_eq_prod,← Nat.cast_mul] at hm
  exact Int.natCast_dvd_natCast.mp hm

theorem owner {n k p f : ℕ} (hk : 0<k) (hp : p.Prime) (hd : p^f ∣ M n k) :
    ∃ i<k, p^f ∣ n+1+i := by
  by_cases hf : f=0
  · exact ⟨0,hk,by simp [hf]⟩
  have hn : ∀ y ∈ Ioc n (n+k), id y ≠ 0 := by
    intro y hy
    have := mem_Ioc.mp hy
    change y ≠ 0
    omega
  obtain ⟨y,hy,hdy⟩ := primePow_dvd_finsetLcm hp (by omega : 0<f) hn hd
  change p^f ∣ y at hdy
  have := mem_Ioc.mp hy
  exact ⟨y-(n+1),by omega,by simpa only [show n+1+(y-(n+1))=y by omega] using hdy⟩

theorem weighted_square_bound {n k d i A B q : ℕ} (hsep : k≤d) (hk : 2≤k)
    (hi : i<k) (ha : 0<A) (he : A*P (n+d) k=B*P n k)
    (hqd : q ∣ d) (hqi : q ∣ n+1+i) :
    q^2 < (edgeWeight k i).natAbs * (B*(k-1)*d) := by
  have hs : n+k≤n+d := by omega
  have hqj : q ∣ n+d+1+i := by
    simpa [Nat.add_assoc,Nat.add_left_comm,Nat.add_comm] using Nat.dvd_add hqd hqi
  have hz := ascFactorial_square_transport (q:=(q:ℤ)) hi hi (by exact_mod_cast hqi)
    (by exact_mod_cast hqj : (q:ℤ) ∣ ((n+d:ℕ):ℤ)+1+(i:ℤ)) he
  have hlt := cross_scaled_entry_lt hs hk hi hi ha he
  have hb := diagonal_scaled_entry_bound hs hk hi ha he
  let E := B*(n+1+i)-A*(n+d+1+i)
  have hE : 0<E := by dsimp [E]; omega
  have hEB : E < B*(k-1)*d := by dsimp [E]; simpa using (show _ < _ from (by omega : B*(n+1+i)-A*(n+d+1+i)< B*(k-1)*(n+d-n)))
  have hsub : (B:ℤ)*edgeWeight k i*((n:ℤ)+1+i) - (A:ℤ)*edgeWeight k i*((↑(n+d):ℤ)+1+i) = edgeWeight k i*(E:ℤ) := by
    dsimp [E]
    rw [Nat.cast_sub hlt.le]
    push_cast
    ring
  rw [hsub] at hz
  obtain ⟨z,hz⟩ := hz
  have hdiv : q^2 ∣ (edgeWeight k i).natAbs*E := by
    exact ⟨z.natAbs,by simpa only [Int.natAbs_mul,Int.natAbs_natCast,Int.natAbs_pow] using congrArg Int.natAbs hz⟩
  have hw : 0<(edgeWeight k i).natAbs := by have := edgeWeight_ne_zero k i; omega
  exact (Nat.le_of_dvd (Nat.mul_pos hw hE) hdiv).trans_lt (Nat.mul_lt_mul_of_pos_left hEB hw)

/-- Factor a prime power across a product and keep an actual owner in
the interval LCM. -/
theorem split_power {p e c L : ℕ} (hp : p.Prime) (hc : 0<c) (hL : 0<L)
    (hd : p^e ∣ c*L) : ∃ f≤e, p^f ∣ L ∧ p^e ≤ c*p^f := by
  let f := min e (L.factorization p)
  have hf : f≤e := min_le_left _ _
  have he' := (hp.pow_dvd_iff_le_factorization (Nat.mul_pos hc hL).ne').mp hd
  rw [Nat.factorization_mul hc.ne' hL.ne', Finsupp.add_apply] at he'
  have hcf : p^(e-f) ∣ c := (hp.pow_dvd_iff_le_factorization hc.ne').mpr (by dsimp [f]; omega)
  refine ⟨f,hf,(hp.pow_dvd_iff_le_factorization hL.ne').mpr (min_le_right _ _),?_⟩
  calc p^e = p^(e-f)*p^f := by rw [←pow_add, Nat.sub_add_cancel hf]
       _ ≤ _ := Nat.mul_le_mul_right _ (Nat.le_of_dvd hc hcf)

theorem prime_le_of_dvd_factorial {p r : ℕ} (hp : p.Prime) (h : p∣r.factorial) : p≤r := by
  induction r with
  | zero => simp only [Nat.factorial_zero, Nat.dvd_one] at h; have := hp.two_le; omega
  | succ r ih =>
    rw [Nat.factorial_succ] at h
    rcases hp.dvd_mul.mp h with h|h
    · exact Nat.le_of_dvd (by omega) h
    · exact (ih h).trans (by omega)

theorem power_cofactor_bounds {n k d p e t A B W : ℕ} (hp : p.Prime)
    (hdt : d=p^e*t) (hk : 2≤k) (hsep : k≤d) (hA : 0<A)
    (he : A*P (n+d) k=B*P n k) (hw : ∀ i<k, (edgeWeight k i).natAbs ≤ W) :
    p^e < (((B-A)*(k-1).factorial)^2*W*(B*(k-1)))*t ∧
      (k<p → B≤p → p^e < B*(k-1)*t) := by
  have hqd : p^e ∣ d := ⟨t,hdt⟩
  have hqpos : 0<p^e := Nat.pow_pos hp.pos
  obtain ⟨hab,hd⟩ := gap_dvd_difference_product hk hsep hA he
  let c := (B-A)*(k-1).factorial
  have hc : 0<c := Nat.mul_pos (by omega) (Nat.factorial_pos _)
  have hdiv : p^e ∣ c*M n k := by
    have hl := Erdos677UpperBound.product_dvd_factorial_mul_L n k (by omega)
    have hl' : P n k ∣ (k-1).factorial*M n k := hl
    have hl'' : (B-A)*P n k ∣ c*M n k := by
      rw [show c*M n k=(B-A)*((k-1).factorial*M n k) by dsimp [c]; ac_rfl]
      exact Nat.mul_dvd_mul_left _ hl'
    exact (hqd.trans hd).trans hl'' 
  constructor
  · obtain ⟨f,hf,hfL,hsize⟩ := split_power hp hc (Nat.pos_of_ne_zero (M_ne_zero n k)) hdiv
    obtain ⟨i,hi,hown⟩ := owner (by omega : 0<k) hp hfL
    have hfd : p^f ∣ d := (pow_dvd_pow p hf).trans hqd
    have hqs := weighted_square_bound hsep hk hi hA he hfd hown
    have ht : (p^e)^2 < c^2*(W*(B*(k-1)*d)) := calc
      _ ≤ (c*p^f)^2 := Nat.pow_le_pow_left hsize _
      _ = c^2*(p^f)^2 := mul_pow _ _ _
      _ < _ := Nat.mul_lt_mul_of_pos_left (hqs.trans_le (Nat.mul_le_mul_right _ (hw i hi))) (Nat.pow_pos hc)
    apply Nat.lt_of_mul_lt_mul_right (a:=p^e)
    calc (p^e)*(p^e) = (p^e)^2 := (pow_two _).symm
         _ < _ := ht
         _ = _ := by rw [hdt]; ring
  · intro hpk hbp
    have hnfa : ¬p ∣ (k-1).factorial := fun hh => (not_le_of_gt (by omega : k-1<p)) (prime_le_of_dvd_factorial hp hh)
    have hnc : ¬p ∣ c := by
      intro h
      rcases hp.dvd_mul.mp h with h|h
      · have := Nat.le_of_dvd (by omega : 0<B-A) h
        omega
      · exact hnfa h
    have hL : p^e ∣ M n k := (hp.coprime_iff_not_dvd.mpr hnc).pow_left e |>.dvd_of_dvd_mul_left hdiv
    obtain ⟨i,hi,hown⟩ := owner (by omega : 0<k) hp hL
    have hcop := (hp.coprime_iff_not_dvd.mpr (prime_not_dvd_edgeWeight hp hpk hi)).pow_left e
    have hbound := diagonal_divisor_square_bound (by omega : n+k≤n+d) hk hi hA he (by simpa using hqd) hown hcop
    rw [Nat.add_sub_cancel_left, hdt, pow_two] at hbound
    exact Nat.lt_of_mul_lt_mul_right (by simpa only [Nat.mul_assoc,Nat.mul_comm,Nat.mul_left_comm] using hbound : p^e*p^e < (B*(k-1)*t)*p^e)

#print axioms power_cofactor_bounds
end Erdos677PrimePower

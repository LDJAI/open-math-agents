module

public import Mathlib.Algebra.BigOperators.Group.Finset.Basic
public import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
public import Mathlib.Data.Nat.Factorial.BigOperators
public import Mathlib.Tactic.Ring.Basic
public import Mathlib.Data.Int.Basic
public import Mathlib.Data.Nat.Prime.Basic
public import Mathlib.Algebra.BigOperators.Associated

@[expose] public section

open Finset
open scoped BigOperators

namespace Erdos677TransportSecond

/-- A pointwise divisibility relation passes to the difference of finite products. -/
theorem dvd_prod_diff {α : Type*} [DecidableEq α] (q : ℤ) (s : Finset α)
    (f g : α → ℤ) (h : ∀ x ∈ s, q ∣ f x - g x) :
    q ∣ (∏ x ∈ s, f x) - ∏ x ∈ s, g x := by
  induction s using Finset.induction_on with
  | empty => simp
  | @insert x s hx ih =>
    rw [Finset.prod_insert hx, Finset.prod_insert hx]
    obtain ⟨u, hu⟩ := h x (mem_insert_self x s)
    obtain ⟨v, hv⟩ := ih (fun y hy => h y (mem_insert_of_mem hy))
    refine ⟨f x * v + u * (∏ y ∈ s, g y), ?_⟩
    calc
      f x * (∏ y ∈ s, f y) - g x * (∏ y ∈ s, g y)
          = f x * ((∏ y ∈ s, f y) - ∏ y ∈ s, g y) +
            (f x - g x) * (∏ y ∈ s, g y) := by ring
      _ = q * (f x * v + u * (∏ y ∈ s, g y)) := by rw [hu, hv]; ring

/-- First-order Taylor coefficient at index i, with zero-based indices. -/
theorem square_lift_at_root {x q : ℤ} {k i : ℕ} (hi : i < k)
    (h : q ∣ x + (i : ℤ)) :
    q ^ 2 ∣
      (∏ t ∈ range k, (x + (t : ℤ))) -
        (x + (i : ℤ)) * (∏ t ∈ (range k).erase i, ((t : ℤ) - (i : ℤ))) := by
  have h' := dvd_prod_diff q ((range k).erase i)
      (fun t => x + (t : ℤ)) (fun t => (t : ℤ) - (i : ℤ))
      (fun t _ => by
        convert h using 1; ring)
  obtain ⟨a, ha⟩ := h
  obtain ⟨b, hb⟩ := h'
  rw [← Finset.mul_prod_erase (range k) (fun t => x + (t : ℤ)) (mem_range.mpr hi)]
  refine ⟨a * b, ?_⟩
  calc
    (x + (i : ℤ)) * (∏ t ∈ (range k).erase i, (x + (t : ℤ))) -
      (x + (i : ℤ)) * (∏ t ∈ (range k).erase i, ((t : ℤ) - (i : ℤ)))
        = (x + (i : ℤ)) * ((∏ t ∈ (range k).erase i, (x + (t : ℤ))) -
          ∏ t ∈ (range k).erase i, ((t : ℤ) - (i : ℤ))) := by ring
    _ = q ^ 2 * (a * b) := by rw [ha, hb]; ring

/-- Signed factorial factor in the first-order Taylor coefficient. -/
def edgeWeight (k i : ℕ) : ℤ := ∏ t ∈ (range k).erase i, ((t : ℤ) - (i : ℤ))

/-- The square lift is valid for every common divisor of two entries,
    without a prime, prime-power, or uniqueness restriction. -/
theorem square_transport {x y q A B : ℤ} {k i j : ℕ}
    (hi : i < k) (hj : j < k)
    (hq₁ : q ∣ x + (i : ℤ)) (hq₂ : q ∣ y + (j : ℤ))
    (hProd : A * (∏ t ∈ range k, (y + (t : ℤ))) =
      B * (∏ t ∈ range k, (x + (t : ℤ)))) :
    q ^ 2 ∣ B * edgeWeight k i * (x + (i : ℤ)) -
      A * edgeWeight k j * (y + (j : ℤ)) := by
  have hx := square_lift_at_root hi hq₁
  have hy := square_lift_at_root hj hq₂
  change q ^ 2 ∣ (∏ t ∈ range k, (x + (t : ℤ))) -
    (x + (i : ℤ)) * edgeWeight k i at hx
  change q ^ 2 ∣ (∏ t ∈ range k, (y + (t : ℤ))) -
    (y + (j : ℤ)) * edgeWeight k j at hy
  have hh := dvd_sub (dvd_mul_of_dvd_right hy A) (dvd_mul_of_dvd_right hx B)
  have heq : A * ((∏ t ∈ range k, (y + (t : ℤ))) - (y + (j : ℤ)) * edgeWeight k j) -
      B * ((∏ t ∈ range k, (x + (t : ℤ))) - (x + (i : ℤ)) * edgeWeight k i) =
      B * edgeWeight k i * (x + (i : ℤ)) -
        A * edgeWeight k j * (y + (j : ℤ)) := by
    rw [mul_sub, mul_sub, hProd]
    ring
  rw [heq] at hh
  exact hh

theorem ascFactorial_cast_eq_prod (n k : ℕ) :
    ((n + 1).ascFactorial k : ℤ) = ∏ t ∈ range k, ((n : ℤ) + 1 + (t : ℤ)) := by
  rw [Nat.ascFactorial_eq_prod_range, Nat.cast_prod]
  simp only [Nat.cast_add, Nat.cast_one]

/-- Exact ascending-factorial form usable with a normalized interval-LCM collision equation. -/
theorem ascFactorial_square_transport {n m k i j A B : ℕ} {q : ℤ}
    (hi : i < k) (hj : j < k)
    (hq₁ : q ∣ (n : ℤ) + 1 + (i : ℤ))
    (hq₂ : q ∣ (m : ℤ) + 1 + (j : ℤ))
    (hProd : A * (m + 1).ascFactorial k = B * (n + 1).ascFactorial k) :
    q ^ 2 ∣ (B : ℤ) * edgeWeight k i * ((n : ℤ) + 1 + (i : ℤ)) -
      (A : ℤ) * edgeWeight k j * ((m : ℤ) + 1 + (j : ℤ)) := by
  apply square_transport hi hj hq₁ hq₂
  have hh := congrArg (fun x : ℕ => (x : ℤ)) hProd
  simpa only [Nat.cast_mul, ascFactorial_cast_eq_prod] using hh

/-- The erased upper product exceeds the erased lower product for any two indices.
    Disjointness gives a pointwise separation stronger than same-index comparison. -/
theorem erasedProduct_strict {m n k i j : ℕ} (hsep : n + k ≤ m)
    (hk : 2 ≤ k) (hi : i < k) (hj : j < k) :
    (∏ t ∈ (range k).erase i, (n + 1 + t)) <
      ∏ t ∈ (range k).erase j, (m + 1 + t) := by
  have hleft : (∏ t ∈ (range k).erase i, (n + 1 + t)) ≤ (n + k) ^ (k - 1) := calc
    _ ≤ ∏ t ∈ (range k).erase i, (n + k) := by
      apply Finset.prod_le_prod (fun _ _ => Nat.zero_le _)
      intro t ht
      have ht' := mem_range.mp (mem_of_mem_erase ht)
      omega
    _ = _ := by rw [Finset.prod_const, Finset.card_erase_of_mem (mem_range.mpr hi), Finset.card_range]
  have hright : (m + 1) ^ (k - 1) ≤ (∏ t ∈ (range k).erase j, (m + 1 + t)) := calc
    _ = ∏ t ∈ (range k).erase j, (m + 1) := by
      rw [Finset.prod_const, Finset.card_erase_of_mem (mem_range.mpr hj), Finset.card_range]
    _ ≤ _ := by
      apply Finset.prod_le_prod (fun _ _ => Nat.zero_le _)
      intro t ht
      omega
  exact lt_of_le_of_lt hleft (lt_of_lt_of_le
    (Nat.pow_lt_pow_left (by omega) (by omega)) hright)

/-- Cross-index strengthening: the scaled earlier entry is larger than the
    scaled later entry for every pair of owner positions. -/
theorem cross_scaled_entry_lt {m n k i j A B : ℕ} (hsep : n + k ≤ m)
    (hk : 2 ≤ k) (hi : i < k) (hj : j < k) (hA : 0 < A)
    (hProd : A * (m + 1).ascFactorial k = B * (n + 1).ascFactorial k) :
    A * (m + 1 + j) < B * (n + 1 + i) := by
  have hstrict := erasedProduct_strict hsep hk hi hj
  have hPn : (n + 1).ascFactorial k =
      (n + 1 + i) * (∏ t ∈ (range k).erase i, (n + 1 + t)) := by
    rw [Nat.ascFactorial_eq_prod_range]
    exact (Finset.mul_prod_erase (range k) (fun t => n + 1 + t) (mem_range.mpr hi)).symm
  have hPm : (m + 1).ascFactorial k =
      (m + 1 + j) * (∏ t ∈ (range k).erase j, (m + 1 + t)) := by
    rw [Nat.ascFactorial_eq_prod_range]
    exact (Finset.mul_prod_erase (range k) (fun t => m + 1 + t) (mem_range.mpr hj)).symm
  rw [hPn, hPm, ← Nat.mul_assoc, ← Nat.mul_assoc] at hProd
  by_contra h
  have hle : B * (n + 1 + i) ≤ A * (m + 1 + j) := Nat.le_of_not_gt h
  have ht : B * (n + 1 + i) * (∏ t ∈ (range k).erase i, (n + 1 + t)) <
      A * (m + 1 + j) * (∏ t ∈ (range k).erase j, (m + 1 + t)) := calc
    _ ≤ A * (m + 1 + j) * (∏ t ∈ (range k).erase i, (n + 1 + t)) :=
      Nat.mul_le_mul_right _ hle
    _ < _ := Nat.mul_lt_mul_of_pos_left hstrict (Nat.mul_pos hA (by omega))
  exact (Nat.ne_of_lt ht) hProd.symm

theorem edgeWeight_ne_zero (k i : ℕ) : edgeWeight k i ≠ 0 := by
  unfold edgeWeight
  apply Finset.prod_ne_zero_iff.mpr
  intro t ht
  have hn := (mem_erase.mp ht).1
  omega

/-- A vanishing edge necessarily strictly increases the unsigned factorial
    weight. In particular, directed vanishing edges cannot form a cycle. -/
theorem vanishing_weight_gain {m n k i j A B : ℕ} (hsep : n + k ≤ m)
    (hk : 2 ≤ k) (hi : i < k) (hj : j < k) (hA : 0 < A)
    (hProd : A * (m + 1).ascFactorial k = B * (n + 1).ascFactorial k)
    (hZero : (B : ℤ) * edgeWeight k i * ((n + 1 + i : ℕ) : ℤ) =
      (A : ℤ) * edgeWeight k j * ((m + 1 + j : ℕ) : ℤ)) :
    (edgeWeight k i).natAbs < (edgeWeight k j).natAbs := by
  have hRatio := cross_scaled_entry_lt hsep hk hi hj hA hProd
  have hAbs0 := congrArg Int.natAbs hZero
  simp only [Int.natAbs_mul, Int.natAbs_natCast] at hAbs0
  have hAbs : B * (n + 1 + i) * (edgeWeight k i).natAbs =
      A * (m + 1 + j) * (edgeWeight k j).natAbs := calc
    _ = B * (edgeWeight k i).natAbs * (n + 1 + i) := by ac_rfl
    _ = A * (edgeWeight k j).natAbs * (m + 1 + j) := hAbs0
    _ = _ := by ac_rfl
  have hWi : 0 < (edgeWeight k i).natAbs := by
    have hn := edgeWeight_ne_zero k i
    omega
  by_contra h
  have hle : (edgeWeight k j).natAbs ≤ (edgeWeight k i).natAbs := Nat.le_of_not_gt h
  have hlt : A * (m + 1 + j) * (edgeWeight k j).natAbs <
      B * (n + 1 + i) * (edgeWeight k i).natAbs :=
    lt_of_le_of_lt (Nat.mul_le_mul_left _ hle) (Nat.mul_lt_mul_of_pos_right hRatio hWi)
  exact (Nat.ne_of_lt hlt) hAbs.symm

#print axioms ascFactorial_square_transport
#print axioms vanishing_weight_gain

/-- A finite-product analogue of 1-∏ rᵢ ≤ Σ (1-rᵢ), using only natural
    number inequalities and eliminating division. -/
theorem scaled_product_bound (s : Finset ℕ) {n m : ℕ} (hnm : n ≤ m) :
    (m+1)*(∏ t ∈ s, (m+1+t)) ≤
      (m+1)*(∏ t ∈ s, (n+1+t)) +
        s.card*(m-n)*(∏ t ∈ s, (m+1+t)) := by
  induction s using Finset.induction_on with
  | empty => simp
  | @insert t s ht ih =>
    rw [Finset.prod_insert ht, Finset.prod_insert ht, Finset.card_insert_of_notMem ht]
    let X := n+1+t
    let Y := m+1+t
    let U := ∏ r ∈ s, (n+1+r)
    let V := ∏ r ∈ s, (m+1+r)
    let d := m-n
    change (m+1)*(Y*V) ≤ (m+1)*(X*U)+(s.card+1)*d*(Y*V)
    change (m+1)*V ≤ (m+1)*U+s.card*d*V at ih
    have hYX : Y = X+d := by dsimp [X,Y,d]; omega
    have hUV : U ≤ V := by
      unfold U V
      apply Finset.prod_le_prod (fun _ _ => Nat.zero_le _)
      intro r hr
      omega
    have hM : m+1 ≤ Y := by dsimp [Y]; omega
    have hstep : d*((m+1)*U) ≤ d*(Y*V) :=
      Nat.mul_le_mul_left _ (Nat.mul_le_mul hM hUV)
    calc
      (m+1)*(Y*V) = Y*((m+1)*V) := by ring
      _ ≤ Y*((m+1)*U+s.card*d*V) := Nat.mul_le_mul_left _ ih
      _ = (m+1)*(X*U)+d*((m+1)*U)+s.card*d*(Y*V) := by rw [hYX]; ring
      _ ≤ (m+1)*(X*U)+d*(Y*V)+s.card*d*(Y*V) :=
        Nat.add_le_add_right (Nat.add_le_add_left hstep _) _
      _ = (m+1)*(X*U)+(s.card+1)*d*(Y*V) := by ring

/-- An upper bound for the strictly positive diagonal linear form. -/
theorem diagonal_scaled_entry_bound {m n k i A B : ℕ}
    (hsep : n+k ≤ m) (hk : 2 ≤ k) (hi : i < k) (hA : 0 < A)
    (hProd : A*(m+1).ascFactorial k=B*(n+1).ascFactorial k) :
    B*(n+1+i) < A*(m+1+i) + B*(k-1)*(m-n) := by
  let U := ∏ t ∈ (range k).erase i, (n+1+t)
  let V := ∏ t ∈ (range k).erase i, (m+1+t)
  let X := B*(n+1+i)
  let Y := A*(m+1+i)
  let C := B*(k-1)*(m-n)
  let M := m+1
  have hXY : Y < X := cross_scaled_entry_lt hsep hk hi hi hA hProd
  have hB : 0<B := by
    by_contra h
    have hh : B=0 := by omega
    simp [X,hh] at hXY
  have hC : 0<C := by
    unfold C
    exact Nat.mul_pos (Nat.mul_pos hB (by omega)) (by omega)
  have hV : 0<V := by
    unfold V
    exact Finset.prod_pos (fun _ _ => by omega)
  have hUeq : (n+1).ascFactorial k=(n+1+i)*U := by
    unfold U
    rw [Nat.ascFactorial_eq_prod_range]
    exact (Finset.mul_prod_erase (range k) (fun t => n+1+t) (mem_range.mpr hi)).symm
  have hVeq : (m+1).ascFactorial k=(m+1+i)*V := by
    unfold V
    rw [Nat.ascFactorial_eq_prod_range]
    exact (Finset.mul_prod_erase (range k) (fun t => m+1+t) (mem_range.mpr hi)).symm
  have hXYeq : Y*V=X*U := by
    unfold X Y
    rw [hUeq, hVeq, ← Nat.mul_assoc, ← Nat.mul_assoc] at hProd
    exact hProd
  have hscale : M*V ≤ M*U+(k-1)*(m-n)*V := by
    have h := scaled_product_bound ((range k).erase i) (show n≤m by omega)
    rwa [Finset.card_erase_of_mem (mem_range.mpr hi), Finset.card_range] at h
  have hMineq : M*X ≤ M*Y+X*(k-1)*(m-n) := by
    refine Nat.le_of_mul_le_mul_right ?_ hV
    calc
      (M*X)*V = X*(M*V) := by ring
      _ ≤ X*(M*U+(k-1)*(m-n)*V) := Nat.mul_le_mul_left _ hscale
      _ = M*(X*U)+X*(k-1)*(m-n)*V := by ring
      _ = (M*Y+X*(k-1)*(m-n))*V := by rw [← hXYeq]; ring
  have hsmall : X*(k-1)*(m-n) < M*C := by
    have hi' : n+1+i < M := by unfold M; omega
    have hh := Nat.mul_lt_mul_of_pos_left hi' hC
    unfold X C M at hh ⊢
    calc
      B*(n+1+i)*(k-1)*(m-n) = (B*(k-1)*(m-n))*(n+1+i) := by ring
      _ < (B*(k-1)*(m-n))*(m+1) := hh
      _ = _ := by ring
  have hend : M*X < M*(Y+C) := by
    calc
      M*X ≤ M*Y+X*(k-1)*(m-n) := hMineq
      _ < M*Y+M*C := Nat.add_lt_add_left hsmall _
      _ = M*(Y+C) := by ring
  exact Nat.lt_of_mul_lt_mul_left hend

#print axioms diagonal_scaled_entry_bound

/-- Any common divisor in a diagonal entry, coprime to the signed factorial
    coefficient, has square strictly bounded by B*(k-1)*gap. -/
theorem diagonal_divisor_square_bound {m n k i A B q : ℕ}
    (hsep : n+k≤m) (hk : 2≤k) (hi : i<k) (hA : 0<A)
    (hProd : A*(m+1).ascFactorial k=B*(n+1).ascFactorial k)
    (hq : q ∣ m-n) (hni : q ∣ n+1+i)
    (hCop : q.Coprime (edgeWeight k i).natAbs) :
    q^2 < B*(k-1)*(m-n) := by
  have hqi : q ∣ m+1+i := by
    have hh := Nat.dvd_add hq hni
    have heq : m-n+(n+1+i)=m+1+i := by omega
    rwa [heq] at hh
  have hniZ : (q : ℤ) ∣ (n : ℤ)+1+(i : ℤ) := by exact_mod_cast hni
  have hqiZ : (q : ℤ) ∣ (m : ℤ)+1+(i : ℤ) := by exact_mod_cast hqi
  have hLift := ascFactorial_square_transport hi hi hniZ hqiZ hProd
  have hXY := cross_scaled_entry_lt hsep hk hi hi hA hProd
  have hBound := diagonal_scaled_entry_bound hsep hk hi hA hProd
  let E := B*(n+1+i)-A*(m+1+i)
  have hEpos : 0<E := by unfold E; omega
  have hEBound : E < B*(k-1)*(m-n) := by unfold E; omega
  have hfactor : (B : ℤ)*edgeWeight k i*((n : ℤ)+1+(i : ℤ)) -
      (A : ℤ)*edgeWeight k i*((m : ℤ)+1+(i : ℤ)) =
      edgeWeight k i*(E : ℤ) := by
    unfold E
    rw [Nat.cast_sub hXY.le]
    simp only [Nat.cast_mul, Nat.cast_add, Nat.cast_one]
    ring
  rw [hfactor] at hLift
  obtain ⟨z,hz⟩ := hLift
  have hAbsDvd : q^2 ∣ (edgeWeight k i).natAbs * E := by
    refine ⟨z.natAbs, ?_⟩
    have hh := congrArg Int.natAbs hz
    simpa only [Int.natAbs_mul, Int.natAbs_natCast, Int.natAbs_pow] using hh
  have hCop' : (q^2).Coprime (edgeWeight k i).natAbs := hCop.pow_left 2
  have hqE : q^2 ∣ E := hCop'.dvd_of_dvd_mul_left hAbsDvd
  exact lt_of_le_of_lt (Nat.le_of_dvd hEpos hqE) hEBound

#print axioms diagonal_divisor_square_bound

theorem prime_not_dvd_edgeWeight {d k i : ℕ} (hp : d.Prime)
    (hpk : k < d) (hi : i < k) :
    ¬ d ∣ (edgeWeight k i).natAbs := by
  have hweight : (edgeWeight k i).natAbs =
      ∏ t ∈ (range k).erase i, ((t : ℤ)-(i : ℤ)).natAbs := by
    unfold edgeWeight
    let absHom : ℤ →*₀ ℕ := { toFun := Int.natAbs, map_mul' := Int.natAbs_mul, map_one' := rfl, map_zero' := rfl }
    change absHom (∏ t ∈ (range k).erase i, ((t : ℤ)-(i : ℤ))) =
      ∏ t ∈ (range k).erase i, absHom ((t : ℤ)-(i : ℤ))
    rw [map_prod]
  rw [hweight]
  intro hd
  obtain ⟨t,ht,hdv⟩ := ((Nat.prime_iff.mp hp).dvd_finsetProd_iff
    (fun t : ℕ => ((t : ℤ)-(i : ℤ)).natAbs)).mp hd
  have ht' := mem_range.mp (mem_of_mem_erase ht)
  have hti := (mem_erase.mp ht).1
  have hpos : 0 < ((t : ℤ)-(i : ℤ)).natAbs := by omega
  have hlt : ((t : ℤ)-(i : ℤ)).natAbs < d := by
    omega
  exact (not_le_of_gt hlt) (Nat.le_of_dvd hpos hdv)

/-- For any normalized product equality between disjoint intervals, a prime
    separation larger than the block length is bounded by the upper
    coefficient times k-1. This is independent of the exact LCM definition. -/
theorem prime_gap_bound {n k d A B : ℕ} (hk : 2 ≤ k)
    (hp : d.Prime) (hpk : k < d) (hA : 0<A)
    (hProd : A*(n+d+1).ascFactorial k=B*(n+1).ascFactorial k) :
    d < B*(k-1) := by
  have hsep : n+k≤n+d := by omega
  have hzero : 0<k := by omega
  have hAB : A<B := by
    have hh := cross_scaled_entry_lt (i:=0) (j:=0) hsep hk hzero hzero hA hProd
    by_contra h
    have hBA : B≤A := Nat.le_of_not_gt h
    have hh2 : B*(n+1+0) ≤ A*(n+d+1+0) :=
      Nat.mul_le_mul hBA (by omega)
    exact (not_le_of_gt hh) hh2
  by_contra h
  have hBD : B*(k-1) ≤ d := Nat.le_of_not_gt h
  have hB : B≤d := le_trans (by
    have hh : 1≤k-1 := by omega
    simpa only [Nat.mul_one] using Nat.mul_le_mul_left B hh) hBD
  have hDpos : 0<B-A := by omega
  have hD : ¬ d ∣ B-A := fun hd => (by have hh := Nat.le_of_dvd hDpos hd; omega)
  have hcong : (d : ℤ) ∣
      (∏ t ∈ range k, ((n : ℤ)+(d : ℤ)+1+(t : ℤ))) -
        (∏ t ∈ range k, ((n : ℤ)+1+(t : ℤ))) := by
    apply dvd_prod_diff
    intro t ht
    refine ⟨1, ?_⟩
    ring
  have hProdZ : (A : ℤ)*(∏ t ∈ range k, ((n : ℤ)+(d : ℤ)+1+(t : ℤ))) =
      (B : ℤ)*(∏ t ∈ range k, ((n : ℤ)+1+(t : ℤ))) := by
    have hh := congrArg (fun v : ℕ => (v : ℤ)) hProd
    simpa only [Nat.cast_mul, ascFactorial_cast_eq_prod, Nat.cast_add] using hh
  have hdP := dvd_mul_of_dvd_right hcong (A : ℤ)
  have hre : (A : ℤ)*((∏ t ∈ range k, ((n : ℤ)+(d : ℤ)+1+(t : ℤ))) -
      (∏ t ∈ range k, ((n : ℤ)+1+(t : ℤ)))) =
      (((B-A)*(n+1).ascFactorial k : ℕ) : ℤ) := by
    rw [mul_sub, hProdZ, Nat.cast_mul, Nat.cast_sub hAB.le, ascFactorial_cast_eq_prod]
    ring
  rw [hre] at hdP
  have hdPN : d ∣ (B-A)*(n+1).ascFactorial k := Int.natCast_dvd_natCast.mp hdP
  have hdProd : d ∣ (n+1).ascFactorial k := (hp.dvd_mul.mp hdPN).resolve_left hD
  rw [Nat.ascFactorial_eq_prod_range] at hdProd
  obtain ⟨i,hi',hdi⟩ := ((Nat.prime_iff.mp hp).dvd_finsetProd_iff
    (fun i => n+1+i)).mp hdProd
  have hi := mem_range.mp hi'
  have hCop : d.Coprime (edgeWeight k i).natAbs :=
    hp.coprime_iff_not_dvd.mpr (prime_not_dvd_edgeWeight hp hpk hi)
  have hdd : d ∣ n+d-n := by simp
  have hs := diagonal_divisor_square_bound hsep hk hi hA hProd hdd hdi hCop
  have hmd : n+d-n=d := by omega
  rw [hmd] at hs
  have hsq' : B*(k-1)*d≤d^2 := by rw [pow_two]; exact Nat.mul_le_mul_right _ hBD
  exact (not_le_of_gt hs) hsq'

#print axioms prime_gap_bound

end Erdos677TransportSecond

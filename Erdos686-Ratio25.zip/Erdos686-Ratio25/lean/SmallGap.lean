module

public import Valuation
public import PrimeGap
public import Mathlib.Tactic.Ring

@[expose] public section

namespace Erdos677SmallGap
open Finset Erdos677Valuation

theorem ratio_strict {u v d k : ℕ} (huv : u<v) (hd : 0<d) (hk : 0<k) :
    P (v+d) k * P u k < P (u+d) k * P v k := by
  unfold P
  simp only [Nat.ascFactorial_eq_prod_range, ← Finset.prod_mul_distrib]
  apply Finset.prod_lt_prod_of_nonempty
  · intro i hi
    exact Nat.mul_pos (by omega) (by omega)
  · intro i hi
    have hpos : 0<d*(v-u) := Nat.mul_pos hd (by omega)
    have he : (v+d+1+i)*(u+1+i)+d*(v-u) = (u+d+1+i)*(v+1+i) := by
      obtain ⟨z,rfl⟩ := Nat.exists_eq_add_of_le huv.le
      rw [Nat.add_sub_cancel_left]; ring
    omega
  · exact ⟨0,mem_range.mpr hk⟩

/-- Multiplication by the positive denominators transfers a strict test
at one starting point to every putative root on the same side. -/
theorem reject_left {n t d k A B : ℕ} (hn : n≤t) (hd : 0<d) (hk : 0<k)
    (hA : 0<A) (hgt : B*P t k < A*P (t+d) k) :
    A*P (n+d) k ≠ B*P n k := by
  intro heq
  have hnpos : 0 < P n k := Nat.ascFactorial_pos _ _
  have hratio : P (t+d) k * P n k ≤ P (n+d) k * P t k := by
    rcases hn.eq_or_lt with rfl|h
    · rfl
    · exact (ratio_strict h hd hk).le
  have hlarge := Nat.mul_lt_mul_of_pos_right hgt hnpos
  have hsmall := Nat.mul_le_mul_left A hratio
  rw [← Nat.mul_assoc, ← Nat.mul_assoc, heq] at hsmall
  exact (not_lt_of_ge hsmall) (by simpa only [Nat.mul_assoc, Nat.mul_comm, Nat.mul_left_comm] using hlarge)

theorem reject_right {n t d k A B : ℕ} (hn : t≤n) (hd : 0<d) (hk : 0<k)
    (hlt : A*P (t+d) k < B*P t k) :
    A*P (n+d) k ≠ B*P n k := by
  intro heq
  have hnpos : 0 < P n k := Nat.ascFactorial_pos _ _
  have hratio : P (n+d) k * P t k ≤ P (t+d) k * P n k := by
    rcases hn.eq_or_lt with rfl|h
    · rfl
    · exact (ratio_strict h hd hk).le
  have hsmall := Nat.mul_le_mul_left A hratio
  rw [← Nat.mul_assoc, ← Nat.mul_assoc, heq] at hsmall
  have hlarge := Nat.mul_lt_mul_of_pos_right hlt hnpos
  exact (not_lt_of_ge hsmall) (by simpa only [Nat.mul_assoc, Nat.mul_comm, Nat.mul_left_comm] using hlarge)

def bisect (k d A B : ℕ) : ℕ → ℕ → ℕ → ℕ
  | 0, lo, _ => lo
  | (fuel+1), lo, hi =>
    let t := (lo+hi)/2
    if B*P t k < A*P (t+d) k then bisect k d A B fuel t hi
    else bisect k d A B fuel lo t

def bracket (k d A B : ℕ) : Bool :=
  let t := bisect k d A B (Nat.log2 (k*d*B+2)+2) 0 (k*d*B+1)
  decide (A*P d k < B*P 0 k) ||
    (decide (B*P t k < A*P (t+d) k) && decide (A*P (t+1+d) k < B*P (t+1) k))

theorem bracket_sound {k d A B : ℕ} (h : bracket k d A B = true)
    (hk : 0<k) (hd : 0<d) (hA : 0<A) (n : ℕ) : A*P (n+d) k ≠ B*P n k := by
  unfold bracket at h
  simp only [Bool.or_eq_true, Bool.and_eq_true, decide_eq_true_eq] at h
  rcases h with h|⟨h₁,h₂⟩
  · apply reject_right (t:=0) (by omega) hd hk
    simpa using h
  · let t := bisect k d A B (Nat.log2 (k*d*B+2)+2) 0 (k*d*B+1)
    by_cases hh : n≤t
    · exact reject_left hh hd hk hA h₁
    · exact reject_right (by omega : t+1≤n) hd hk h₂

theorem fixed_coeff {n k d : ℕ} (hk : 0<k) (hd : 0<d) (h : M (n+d) k = M n k) :
    ∃ A : ℕ, 0<A ∧ A<M 0 k/k ∧ A*P (n+d) k = (M 0 k/k)*P n k := by
  have hdk : k ∣ M 0 k := Finset.dvd_lcm (f:=id) (mem_Ioc.mpr (by omega : 0<k ∧ k≤0+k))
  have hr : R k d ∣ M 0 k/k :=
    Nat.div_dvd_div_left (Nat.gcd_dvd_left _ _) (Nat.dvd_gcd hdk (Nat.dvd_lcm_left _ _))
  have hD := (scaled_product_divisibility n (n+d) k hk (by omega) h).1
  rw [Nat.add_sub_cancel_left] at hD
  obtain ⟨A,hA⟩ := hD.trans (Nat.mul_dvd_mul_left _ hr)
  have hBpos := Nat.le_of_dvd (Nat.div_pos (Nat.le_of_dvd (Nat.pos_of_ne_zero (M_ne_zero 0 k)) hdk) hk) hr
  have hn : 0<P n k := Nat.ascFactorial_pos _ _
  have hm : P n k < P (n+d) k := product_strict _ _ _ (by omega) hk
  have hpos := R_pos k d
  refine ⟨A, ?_, ?_, by simpa [Nat.mul_comm] using hA.symm⟩
  · by_contra! hz
    have : A=0 := by omega
    rw [this,Nat.mul_zero] at hA
    exact (Nat.mul_pos hn (by omega : 0<M 0 k/k)).ne' hA
  · by_contra! hz
    have hl := Nat.mul_le_mul_left (P (n+d) k) hz
    rw [← hA] at hl
    exact (not_lt_of_ge hl) (Nat.mul_lt_mul_of_pos_right hm (by omega))

end Erdos677SmallGap

module

public import Mathlib.Algebra.GCDMonoid.FinsetLemmas
public import Mathlib.Order.Interval.Finset.Nat
public import Mathlib.Data.Nat.Choose.Factorization
public import Mathlib.Data.Nat.Choose.Bounds
public import Mathlib.Data.Nat.Choose.Sum

@[expose] public section

namespace Erdos677UpperBound
open Finset
abbrev U (n : ℕ) : ℕ := (Icc 1 n).lcm id

lemma U_ne_zero (n : ℕ) : U n ≠ 0 := by
  apply Finset.lcm_ne_zero_iff.mpr
  intro x hx
  have := Finset.mem_Icc.mp hx
  change x ≠ 0
  omega
lemma U_pos (n : ℕ) : 0 < U n := Nat.pos_of_ne_zero (U_ne_zero n)

lemma U_factorization (n : ℕ) {p : ℕ} (hp : p.Prime) : (U n).factorization p = p.log n := by
  have hfn : ∀ x ∈ Finset.Icc 1 n, id x ≠ 0 := fun x hx => by
    have := Finset.mem_Icc.mp hx
    change x ≠ 0
    omega
  rw [Finset.factorization_lcm hfn]
  apply le_antisymm
  · apply Finset.sup_le_iff.mpr
    intro x hx
    have hx' := Finset.mem_Icc.mp hx
    change x.factorization p ≤ p.log n
    have hx0 : x ≠ 0 := by omega
    exact Nat.le_log_of_pow_le hp.one_lt
      ((Nat.le_of_dvd (Nat.pos_of_ne_zero hx0) ((hp.pow_dvd_iff_le_factorization hx0).mpr le_rfl)).trans hx'.2)
  · by_cases hn : n=0
    · simp [hn]
    · have hq : p^p.log n ≤ n := Nat.pow_log_le_self p hn
      have hqpos : p^p.log n > 0 := Nat.pow_pos hp.pos
      have hmem : p^p.log n ∈ Finset.Icc 1 n := Finset.mem_Icc.mpr ⟨by omega,hq⟩
      have hd : p^p.log n ∣ U n := Finset.dvd_lcm (f:=id) hmem
      simpa only [Finset.factorization_lcm hfn] using (hp.pow_dvd_iff_le_factorization (U_ne_zero n)).mp hd

lemma U_dvd_U_half_choose (r : ℕ) (hr : 1 < r) :
    U r ∣ U ((r+1)/2) * r.choose ((r+1)/2) := by
  let t := (r+1)/2
  change U r ∣ U t * r.choose t
  have ht : 0 < t := by dsimp [t]; omega
  have htr : t ≤ r := by dsimp [t]; omega
  have hsplit : r ≤ 2*t := by dsimp [t]; omega
  apply (Nat.factorization_prime_le_iff_dvd (U_ne_zero r) (Nat.mul_ne_zero (U_ne_zero t) (Nat.choose_ne_zero_iff.mpr htr))).mp
  intro p hp
  rw [Nat.factorization_mul (U_ne_zero t) (Nat.choose_ne_zero_iff.mpr htr), Finsupp.coe_add, Pi.add_apply, U_factorization r hp, U_factorization t hp]
  by_cases hlog : p.log r ≤ p.log t
  · omega
  let e := p.log r
  have he : p.log t < e := Nat.lt_of_not_ge hlog
  have hepos : e > 0 := by omega
  have hq : p^e ≤ r := Nat.pow_log_le_self p (by omega)
  have hqt : t < p^e := (Nat.log_lt_iff_lt_pow hp.one_lt ht.ne').mp he
  have hpre : p^(e-1) ≤ t := by
    apply Nat.le_of_mul_le_mul_right (c := p) ?_ hp.pos
    calc
      p^(e-1)*p = p^e := by rw [← pow_succ, show e-1+1=e by omega]
      _ ≤ r := hq
      _ ≤ 2*t := hsplit
      _ ≤ t*p := by simpa [Nat.mul_comm] using (Nat.mul_le_mul_right t hp.two_le)
  have helog : e-1 ≤ p.log t := Nat.le_log_of_pow_le hp.one_lt hpre
  have hcarry : 0 < (r.choose t).factorization p := by
    rw [Nat.factorization_choose hp htr (Nat.lt_succ_self _)]
    apply Finset.card_pos.mpr
    refine ⟨e, Finset.mem_filter.mpr ⟨Finset.mem_Ico.mpr ⟨by omega, by dsimp [e]; omega⟩, ?_⟩⟩
    have hrest : r-t < p^e := by omega
    rw [Nat.mod_eq_of_lt hqt, Nat.mod_eq_of_lt hrest]
    omega
  omega

lemma U_le_four_pow_pred (r : ℕ) : U r ≤ 4^(r-1) := by
  induction r using Nat.strong_induction_on with
  | h r ih =>
    by_cases hr : 1 < r
    · let t := (r+1)/2
      have ht : t < r := by dsimp [t]; omega
      have hchoose : r.choose t ≤ 2^(r-1) := by
        have h := Nat.choose_succ_le_two_pow (r-1) t
        rwa [show r-1+1=r by omega] at h
      calc
        U r ≤ U t * r.choose t := Nat.le_of_dvd (Nat.mul_pos (U_pos t) (Nat.choose_pos ht.le)) (U_dvd_U_half_choose r hr)
        _ ≤ 4^(t-1) * 2^(r-1) := Nat.mul_le_mul (ih t ht) hchoose
        _ = 2^(2*(t-1)+(r-1)) := by rw [show (4:ℕ)=2^2 by decide, ← pow_mul, ← pow_add]
        _ ≤ 2^(2*(r-1)) := Nat.pow_le_pow_right (by decide) (by dsimp [t]; omega)
        _ = 4^(r-1) := by rw [pow_mul]; rfl
    · have hr' : r=0 ∨ r=1 := by omega
      rcases hr' with rfl | rfl
      · simp [U]
      · simp [U]

lemma U_le_four_pow (r : ℕ) : U r ≤ 4^r :=
  (U_le_four_pow_pred r).trans (Nat.pow_le_pow_right (by decide) (by omega))

abbrev L (n k : ℕ) : ℕ := (Ioc n (n+k)).lcm id

lemma L_zero_eq_U (k : ℕ) : L 0 k = U k := by
  have heq : Ioc 0 k = Icc 1 k := by ext i; simp only [mem_Ioc,mem_Icc]; omega
  simp [L,U,heq]

lemma L_pos (n k : ℕ) : 0 < L n k := by
  apply Nat.pos_of_ne_zero
  apply Finset.lcm_ne_zero_iff.mpr
  intro x hx
  have := Finset.mem_Ioc.mp hx
  change x ≠ 0
  omega

lemma L_one (n : ℕ) : L n 1 = n+1 := by
  simp [L, Nat.Ioc_succ_singleton]

lemma L_mono_right (n k : ℕ) : L n k ∣ L n (k+1) := by
  apply Finset.lcm_mono
  intro i hi
  simp only [mem_Ioc] at hi ⊢
  omega

lemma L_mono_left (n k : ℕ) : L (n+1) k ∣ L n (k+1) := by
  apply Finset.lcm_mono
  intro i hi
  simp only [mem_Ioc] at hi ⊢
  omega

lemma product_dvd_factorial_mul_L (n k : ℕ) (hk : 0 < k) :
    (n+1).ascFactorial k ∣ (Nat.factorial (k-1)) * L n k := by
  induction k generalizing n with
  | zero => omega
  | succ k ih =>
    by_cases hk' : k = 0
    · subst k
      simp [L_one, Nat.ascFactorial_succ]
    have hp : 0 < k := Nat.pos_of_ne_zero hk'
    let c := (Nat.factorial (k-1)) * L n (k+1)
    have ha : (n+1).ascFactorial k ∣ c :=
      (ih n hp).trans (Nat.mul_dvd_mul_left _ (L_mono_right n k))
    have hb : ((n+1)+1).ascFactorial k ∣ c :=
      (ih (n+1) hp).trans (Nat.mul_dvd_mul_left _ (L_mono_left n k))
    have hleft : (n+1).ascFactorial (k+1) ∣ (n+k+1) * c := by
      rw [Nat.ascFactorial_succ, show n+1+k = n+k+1 by omega]
      exact Nat.mul_dvd_mul_left _ ha
    have hright : (n+1).ascFactorial (k+1) ∣ (n+1) * c := by
      rw [Nat.ascFactorial_succ, ← Nat.succ_ascFactorial]
      exact Nat.mul_dvd_mul_left _ hb
    have hsub := Nat.dvd_sub hleft hright
    rw [← Nat.sub_mul, show n+k+1-(n+1) = k by omega] at hsub
    have hfac : k * (Nat.factorial (k-1)) = k.factorial := by
      obtain ⟨j, rfl⟩ := Nat.exists_eq_succ_of_ne_zero hk'
      simp [Nat.factorial_succ]
    simpa only [Nat.add_sub_cancel, c, ← Nat.mul_assoc, hfac] using hsub

lemma choose_dvd_L (n k : ℕ) (hk : 0 < k) : k*(n+k).choose k ∣ L n k := by
  have hp := product_dvd_factorial_mul_L n k hk
  rw [Nat.ascFactorial_eq_factorial_mul_choose'] at hp
  have hfac : k.factorial=(k-1).factorial*k := by
    obtain ⟨j,rfl⟩ := Nat.exists_eq_succ_of_ne_zero hk.ne'
    simp [Nat.factorial_succ, Nat.mul_comm]
  rw [show n+1+k-1=n+k by omega, hfac, Nat.mul_assoc] at hp
  exact Nat.dvd_of_mul_dvd_mul_left (Nat.factorial_pos _) hp

lemma central_binom_lower (k : ℕ) (hk : 0<k) : 4^(k-1) < k*(2*k).choose k := by
  have h := Nat.four_pow_le_two_mul_add_one_mul_central_binom k
  have hpos : 0 < (2*k).choose k := Nat.choose_pos (by omega)
  have hpow : 4^k=4*4^(k-1) := by
    conv_lhs => rw [show k=k-1+1 by omega, pow_succ']
  rw [hpow] at h
  have hmul : (2*k+1)*(2*k).choose k < 4*(k*(2*k).choose k) := by
    have hcoef : 2*k+1 < 4*k := by omega
    simpa [Nat.mul_assoc] using Nat.mul_lt_mul_of_pos_right hcoef hpos
  omega

/-- The conjecture is valid for every positive length when the first block starts at 1. -/
theorem no_collision_start_zero (m k : ℕ) (hk : 0<k) (hm : k ≤ m) :
    L m k ≠ L 0 k := by
  intro h
  have hlow := Nat.le_of_dvd (L_pos m k) (choose_dvd_L m k hk)
  have hc := Nat.mul_le_mul_left k (Nat.choose_le_choose k (by omega : 2*k ≤ m+k))
  have hhi := U_le_four_pow_pred k
  rw [h, L_zero_eq_U] at hlow
  exact (not_lt_of_ge (hc.trans (hlow.trans hhi))) (central_binom_lower k hk)

/-- Strong linear-in-length bound for collisions with a bounded relative
separation, given the previously verified cross-difference transport. -/
theorem short_gap_linear_bound (n m k C : ℕ) (hk : k > 0)
    (hgap : m-n ≤ C*k) (htrans : L m k ∣ U (m-n+k-1)) :
    m+1 ≤ 4^(C+1)*k := by
  have hL : L m k ≤ 4^((C+1)*k) := by
    apply (Nat.le_of_dvd (U_pos _) htrans).trans
    apply (U_le_four_pow _).trans
    apply Nat.pow_le_pow_right (by decide)
    rw [Nat.add_mul, Nat.one_mul]
    omega
  have hfac : (k-1).factorial ≤ k^k := by
    calc
      _ ≤ (k-1)^(k-1) := Nat.factorial_le_pow _
      _ ≤ k^(k-1) := Nat.pow_le_pow_left (by omega) _
      _ ≤ k^k := Nat.pow_le_pow_right hk (by omega)
  have hp : (m+1)^k ≤ (4^(C+1)*k)^k := by
    calc
      _ ≤ (m+1).ascFactorial k := Nat.pow_succ_le_ascFactorial _ _
      _ ≤ (k-1).factorial * L m k := Nat.le_of_dvd (Nat.mul_pos (Nat.factorial_pos _) (L_pos _ _)) (product_dvd_factorial_mul_L _ _ hk)
      _ ≤ k^k * 4^((C+1)*k) := Nat.mul_le_mul hfac hL
      _ = (4^(C+1)*k)^k := by rw [mul_pow, ← pow_mul, Nat.mul_comm]
  exact (Nat.pow_le_pow_iff_left hk.ne').mp hp

/-- Uniform factor-four bound given the verified scaled product bound.
The ratio bound for a hypothetical collision implies the premise. -/
theorem later_endpoint_lt_four (n m k : ℕ) (hk : 0<k)
    (hprod : (m+1).ascFactorial k ≤ (n+1).ascFactorial k * U k) :
    m+1 < 4*(n+k) := by
  have hU : U k < 4^k := by
    apply (U_le_four_pow_pred k).trans_lt
    exact Nat.pow_lt_pow_right (by decide) (by omega)
  have hp : (m+1)^k < (4*(n+k))^k := by
    calc
      _ ≤ (m+1).ascFactorial k := Nat.pow_succ_le_ascFactorial _ _
      _ ≤ (n+1).ascFactorial k * U k := hprod
      _ ≤ (n+k)^k * U k := Nat.mul_le_mul_right _ (Nat.ascFactorial_le_pow_add n k)
      _ < (n+k)^k * 4^k := Nat.mul_lt_mul_of_pos_left hU (Nat.pow_pos (by omega))
      _ = (4*(n+k))^k := by rw [mul_pow, Nat.mul_comm]
  by_contra! hn
  exact (not_lt_of_ge (Nat.pow_le_pow_left hn k)) hp

#print axioms U_dvd_U_half_choose
#print axioms U_le_four_pow_pred
#print axioms choose_dvd_L
#print axioms no_collision_start_zero
#print axioms short_gap_linear_bound
#print axioms later_endpoint_lt_four
end Erdos677UpperBound

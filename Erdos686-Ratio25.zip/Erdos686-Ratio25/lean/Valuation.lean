module

public import Mathlib.Tactic.Ring.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Choose.Factorization
public import Mathlib.Order.Interval.Finset.Nat

@[expose] public section

open Finset

namespace Erdos677Valuation

def M (n k : ℕ) : ℕ := (Finset.Ioc n (n + k)).lcm id

def P (n k : ℕ) : ℕ := (n + 1).ascFactorial k

def C (n k q : ℕ) : ℕ := (n + k) / q - n / q

/-- A positive prime power divides an LCM of positive integers only if it divides one of them. -/
theorem primePow_dvd_finsetLcm {s : Finset ℕ} {f : ℕ → ℕ}
    {p e : ℕ} (hp : p.Prime) (he : 0 < e) (hf : ∀ i ∈ s, f i ≠ 0) :
    p ^ e ∣ s.lcm f → ∃ i ∈ s, p ^ e ∣ f i := by
  induction s using Finset.induction_on with
  | empty =>
    simp only [Finset.lcm_empty, Finset.notMem_empty, false_and, exists_false]
    exact fun h => (Nat.not_le_of_lt (one_lt_pow₀ hp.one_lt he.ne') (Nat.le_of_dvd (by decide) h)).elim
  | @insert a s ha ih =>
    intro h
    have hfa : f a ≠ 0 := hf a (mem_insert_self a s)
    have hfs : ∀ i ∈ s, f i ≠ 0 := fun i hi => hf i (mem_insert_of_mem hi)
    have hl : s.lcm f ≠ 0 := Finset.lcm_ne_zero_iff.mpr hfs
    rw [Finset.lcm_insert] at h
    change p ^ e ∣ Nat.lcm (f a) (s.lcm f) at h
    rw [hp.pow_dvd_iff_le_factorization (Nat.lcm_ne_zero hfa hl),
      Nat.factorization_lcm hfa hl, Finsupp.sup_apply, le_max_iff] at h
    rcases h with h | h
    · exact ⟨a, mem_insert_self a s, (hp.pow_dvd_iff_le_factorization hfa).mpr h⟩
    · obtain ⟨i, hi, hdiv⟩ := ih hfs ((hp.pow_dvd_iff_le_factorization hl).mpr h)
      exact ⟨i, mem_insert_of_mem hi, hdiv⟩

lemma count_formula (n k q : ℕ) (hq : q > 0) :
    C n k q = k / q + if q ≤ n % q + k % q then 1 else 0 := by
  unfold C
  rw [Nat.add_div hq, Nat.add_assoc, Nat.add_sub_cancel_left]

lemma count_le (n m k q : ℕ) (hq : q > 0) :
    C m k q ≤ C n k q + 1 := by
  rw [count_formula _ _ _ hq, count_formula _ _ _ hq]
  split <;> split <;> omega

lemma count_eq_if_dvd_length (n m k q : ℕ) (hq : q > 0) (h : q ∣ k) :
    C m k q = C n k q := by
  rw [count_formula _ _ _ hq, count_formula _ _ _ hq, Nat.mod_eq_zero_of_dvd h]
  have hn := Nat.mod_lt n hq
  have hm := Nat.mod_lt m hq
  simp [show ¬ q ≤ n % q from by omega, show ¬ q ≤ m % q from by omega]

lemma count_eq_if_dvd_gap (n m k q : ℕ) (hq : q > 0)
    (hmn : n ≤ m) (h : q ∣ m-n) : C m k q = C n k q := by
  rw [show m = n +(m-n) by omega, count_formula _ _ _ hq, count_formula _ _ _ hq]
  rw [Nat.add_mod, Nat.mod_eq_zero_of_dvd h, Nat.add_zero, Nat.mod_mod]

lemma count_pos_iff_exists (n k q : ℕ) (hq : q > 0) :
    0 < C n k q ↔ ∃ x ∈ Finset.Ioc n (n+k), q ∣ x := by
  constructor
  · intro h
    have hn : n/q < (n+k)/q := by unfold C at h; omega
    use (n/q+1)*q
    refine ⟨Finset.mem_Ioc.mpr ⟨?_,?_⟩, Nat.dvd_mul_left _ _⟩
    · exact (Nat.div_lt_iff_lt_mul hq).mp (by omega)
    · exact (Nat.le_div_iff_mul_le hq).mp (by omega)
  · rintro ⟨x,hx,hxd⟩
    obtain ⟨a,ha⟩ := hxd
    have hx' := Finset.mem_Ioc.mp hx
    have hl : n/q < a := (Nat.div_lt_iff_lt_mul hq).mpr (by simpa [ha,Nat.mul_comm] using hx'.1)
    have hu : a ≤ (n+k)/q := (Nat.le_div_iff_mul_le hq).mpr (by simpa [ha,Nat.mul_comm] using hx'.2)
    unfold C
    omega

lemma count_big_le_one (n k q : ℕ) (hq : q > k) : C n k q ≤ 1 := by
  rw [count_formula _ _ _ (by omega), Nat.div_eq_of_lt hq]
  split <;> omega

lemma count_pos_iff_dvd_M {n k p a : ℕ} (hp : p.Prime) (ha : a > 0) :
    0 < C n k (p^a) ↔ p^a ∣ M n k := by
  rw [count_pos_iff_exists _ _ _ (pow_pos hp.pos _)]
  constructor
  · rintro ⟨x,hx,hdiv⟩
    exact hdiv.trans (Finset.dvd_lcm (f := id) hx)
  · intro hd
    exact primePow_dvd_finsetLcm hp ha (fun i hi => by have := Finset.mem_Ioc.mp hi; omega) hd

lemma count_eq_big_under_collision (n m k p a : ℕ)
    (hp : p.Prime) (ha : a > 0) (hbig : k < p^a)
    (h : M m k = M n k) : C m k (p^a) = C n k (p^a) := by
  have hm := count_big_le_one m k (p^a) hbig
  have hn := count_big_le_one n k (p^a) hbig
  have heq : 0 < C m k (p^a) ↔ 0 < C n k (p^a) := by
    rw [count_pos_iff_dvd_M hp ha, count_pos_iff_dvd_M hp ha, h]
  omega

lemma factorization_product_eq_sum_counts {n k p b : ℕ}
    (hp : p.Prime) (hb : Nat.log p (n+k) < b) :
    (P n k).factorization p = ∑ a ∈ Finset.Ico 1 b, C n k (p^a) := by
  have h := Nat.factorial_mul_ascFactorial n k
  have hfac := congrArg (fun t : ℕ => t.factorization p) h
  have hnz : (n+1).ascFactorial k ≠ 0 := (Nat.ascFactorial_pos _ _).ne'
  have hnlog : Nat.log p n < b := (Nat.log_mono_right (by omega : n ≤ n+k)).trans_lt hb
  change (n.factorial * (n+1).ascFactorial k).factorization p = ((n+k).factorial).factorization p at hfac
  rw [Nat.factorization_mul (Nat.factorial_ne_zero _) hnz] at hfac
  simp only [Finsupp.add_apply, Nat.factorization_factorial hp hnlog, Nat.factorization_factorial hp hb] at hfac
  change ((n+1).ascFactorial k).factorization p = _ 
  unfold C
  rw [Finset.sum_tsub_distrib _ (fun i hi => Nat.div_le_div_right (by omega : n ≤ n+k))]
  omega

def eligible (p a k d : ℕ) : Prop :=
  p^a ≤ k ∧ ¬ p^a ∣ k ∧ ¬ p^a ∣ d

instance (p a k d : ℕ) : Decidable (eligible p a k d) := by
  unfold eligible
  infer_instance

def eligibleCount (p k d b : ℕ) : ℕ :=
  ((Finset.Ico 1 b).filter (fun a => eligible p a k d)).card

lemma count_difference_under_collision (n m k p a : ℕ)
    (hmn : n ≤ m) (hp : p.Prime) (ha : a > 0) (h : M m k = M n k) :
    C m k (p^a) ≤ C n k (p^a) + (if eligible p a k (m-n) then 1 else 0) ∧
    C n k (p^a) ≤ C m k (p^a) + (if eligible p a k (m-n) then 1 else 0) := by
  by_cases he : eligible p a k (m-n)
  · simp only [if_pos he]
    exact ⟨count_le n m k _ (pow_pos hp.pos _), count_le m n k _ (pow_pos hp.pos _)⟩
  · simp only [if_neg he, Nat.add_zero]
    have heq : C m k (p^a) = C n k (p^a) := by
      by_cases hb : p^a ≤ k
      · by_cases hk : p^a ∣ k
        · exact count_eq_if_dvd_length n m k _ (pow_pos hp.pos _) hk
        · have hd : p^a ∣ m-n := by
            by_contra hnd
            exact he ⟨hb,hk,hnd⟩
          exact count_eq_if_dvd_gap n m k _ (pow_pos hp.pos _) hmn hd
      · exact count_eq_big_under_collision n m k p a hp ha (by omega) h
    exact ⟨heq.le,heq.ge⟩

theorem valuation_difference_bound (n m k p b : ℕ)
    (hmn : n ≤ m) (hp : p.Prime) (h : M m k = M n k)
    (hb : Nat.log p (m+k) < b) :
    (P m k).factorization p ≤ (P n k).factorization p + eligibleCount p k (m-n) b ∧
    (P n k).factorization p ≤ (P m k).factorization p + eligibleCount p k (m-n) b := by
  have hbn : Nat.log p (n+k) < b := (Nat.log_mono_right (by omega : n+k ≤ m+k)).trans_lt hb
  rw [factorization_product_eq_sum_counts hp hb, factorization_product_eq_sum_counts hp hbn]
  have hc : eligibleCount p k (m-n) b = ∑ a ∈ Finset.Ico 1 b, (if eligible p a k (m-n) then 1 else 0) := by
    simp [eligibleCount, Finset.sum_boole]
  rw [hc, ← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
  exact ⟨Finset.sum_le_sum fun a ha => (count_difference_under_collision n m k p a hmn hp
      (by have := Finset.mem_Ico.mp ha; omega) h).1,
    Finset.sum_le_sum fun a ha => (count_difference_under_collision n m k p a hmn hp
      (by have := Finset.mem_Ico.mp ha; omega) h).2⟩

lemma product_strict (n m k : ℕ) (hnm : n < m) (hk : 0 < k) :
    P n k < P m k := by
  obtain ⟨j,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : k ≠ 0)
  unfold P
  rw [Nat.ascFactorial_succ, Nat.ascFactorial_succ]
  exact Nat.mul_lt_mul_of_pos_right (show n+1+j < m+1+j by omega) (Nat.ascFactorial_pos _ _) |>.trans_le
    (Nat.mul_le_mul_left _ (Nat.ascFactorial_le _ (by omega)))

/-- More general than the basic periodic-shift obstruction:
for each prime power bounded by the block length, it suffices that
it divides either the shift OR the length. -/
theorem no_collision_if_prime_powers_divide_length_or_gap (n m k : ℕ)
    (hmn : n < m) (hk : 0 < k)
    (hd : ∀ p a : ℕ, p.Prime → 0 < a → p^a ≤ k → p^a ∣ k ∨ p^a ∣ m-n) :
    M m k ≠ M n k := by
  intro h
  have hfac : (P m k).factorization = (P n k).factorization := by
    ext p
    by_cases hp : p.Prime
    · let b := Nat.log p (m+k)+1
      have hb : Nat.log p (m+k) < b := by omega
      have hzero : eligibleCount p k (m-n) b = 0 := by
        unfold eligibleCount
        apply Finset.card_eq_zero.mpr
        apply Finset.filter_eq_empty_iff.mpr
        intro a ha he
        have ha' : 0 < a := by have := Finset.mem_Ico.mp ha; omega
        rcases hd p a hp ha' he.1 with h1|h2
        · exact he.2.1 h1
        · exact he.2.2 h2
      have hv := valuation_difference_bound n m k p b hmn.le hp h hb
      omega
    · rw [Nat.factorization_eq_zero_of_not_prime _ hp, Nat.factorization_eq_zero_of_not_prime _ hp]
  have hP := Nat.factorization_inj (by exact (Nat.ascFactorial_pos _ _).ne') (by exact (Nat.ascFactorial_pos _ _).ne') hfac
  exact (ne_of_gt (product_strict n m k hmn hk)) hP

/-- The gap-adjusted defect-ratio multiplier. -/
def R (k d : ℕ) : ℕ := M 0 k / Nat.gcd (M 0 k) (Nat.lcm k d)

lemma M_ne_zero (n k : ℕ) : M n k ≠ 0 := by
  unfold M
  apply Finset.lcm_ne_zero_iff.mpr
  intro x hx
  have := Finset.mem_Ioc.mp hx
  change x ≠ 0
  omega

lemma R_pos (k d : ℕ) : 0 < R k d := by
  exact Nat.div_gcd_pos_of_pos_left _ (Nat.pos_of_ne_zero (M_ne_zero 0 k))

lemma eligibleCount_log_bound (p k d b : ℕ) (hp : p.Prime)
    (hk : 0 < k) (hd : 0 < d) :
    eligibleCount p k d b ≤ Nat.log p k - max (k.factorization p) (d.factorization p) := by
  unfold eligibleCount
  have hsub : (Finset.Ico 1 b).filter (fun a => eligible p a k d) ⊆
      Finset.Ioc (max (k.factorization p) (d.factorization p)) (Nat.log p k) := by
    intro a ha
    have he : eligible p a k d := (Finset.mem_filter.mp ha).2
    unfold eligible at he
    have h1 : k.factorization p < a := by
      by_contra! hc
      exact he.2.1 ((hp.pow_dvd_iff_le_factorization hk.ne').mpr hc)
    have h2 : d.factorization p < a := by
      by_contra! hc
      exact he.2.2 ((hp.pow_dvd_iff_le_factorization hd.ne').mpr hc)
    have h3 : a ≤ Nat.log p k := Nat.le_log_of_pow_le hp.one_lt he.1
    exact Finset.mem_Ioc.mpr ⟨max_lt h1 h2,h3⟩
  simpa only [Nat.card_Ioc] using Finset.card_le_card hsub

lemma log_le_factorization_M0 (p k : ℕ) (hp : p.Prime) (hk : 0 < k) :
    Nat.log p k ≤ (M 0 k).factorization p := by
  apply (hp.pow_dvd_iff_le_factorization (M_ne_zero 0 k)).mp
  apply Finset.dvd_lcm (f := id)
  apply Finset.mem_Ioc.mpr
  exact ⟨Nat.pow_pos hp.pos, by simpa using Nat.pow_log_le_self p hk.ne'⟩

lemma eligibleCount_R_bound (p k d b : ℕ) (hp : p.Prime)
    (hk : 0 < k) (hd : 0 < d) :
    eligibleCount p k d b ≤ (R k d).factorization p := by
  unfold R
  rw [Nat.factorization_div (Nat.gcd_dvd_left _ _), Finsupp.coe_tsub, Pi.sub_apply,
    Nat.factorization_gcd (M_ne_zero 0 k) (Nat.lcm_ne_zero hk.ne' hd.ne'),
    Finsupp.inf_apply, Nat.factorization_lcm hk.ne' hd.ne', Finsupp.sup_apply]
  have h1 := eligibleCount_log_bound p k d b hp hk hd
  have h2 := log_le_factorization_M0 p k hp hk
  omega

/-- Any equal-LCM pair has both of its products dividing the other
times the small, gap-adjusted multiplier R(k,d). Equivalently, the
reduced numerator and denominator of their product ratio divide R. -/
theorem scaled_product_divisibility (n m k : ℕ) (hk : 0 < k)
    (hmn : n < m) (h : M m k = M n k) :
    P m k ∣ P n k * R k (m-n) ∧ P n k ∣ P m k * R k (m-n) := by
  have hp0 (i : ℕ) : P i k ≠ 0 := (Nat.ascFactorial_pos _ _).ne'
  have hr0 := (R_pos k (m-n)).ne'
  have hb (p : ℕ) : Nat.log p (m+k) < Nat.log p (m+k)+1 := by omega
  have hf (p : ℕ) : (P m k).factorization p ≤ (P n k).factorization p + (R k (m-n)).factorization p ∧
      (P n k).factorization p ≤ (P m k).factorization p + (R k (m-n)).factorization p := by
    by_cases hp : p.Prime
    · have h1 := valuation_difference_bound n m k p _ hmn.le hp h (hb p)
      have h2 := eligibleCount_R_bound p k (m-n) (Nat.log p (m+k)+1) hp hk (by omega)
      omega
    · rw [Nat.factorization_eq_zero_of_not_prime (P m k) hp,
        Nat.factorization_eq_zero_of_not_prime (P n k) hp]
      omega
  constructor
  · apply (Nat.factorization_le_iff_dvd (hp0 m) (Nat.mul_ne_zero (hp0 n) hr0)).mp
    intro p
    rw [Nat.factorization_mul (hp0 n) hr0, Finsupp.add_apply]
    exact (hf p).1
  · apply (Nat.factorization_le_iff_dvd (hp0 n) (Nat.mul_ne_zero (hp0 m) hr0)).mp
    intro p
    rw [Nat.factorization_mul (hp0 m) hr0, Finsupp.add_apply]
    exact (hf p).2

/-- The gap-adjusted multiplier yields a stronger product inequality
than the simpler factorial defect bound. -/
theorem scaled_product_bound (n m k : ℕ) (hk : 0 < k)
    (hmn : n < m) (h : M m k = M n k) :
    P m k ≤ P n k * R k (m-n) :=
  Nat.le_of_dvd (Nat.mul_pos (Nat.ascFactorial_pos _ _) (R_pos _ _))
    (scaled_product_divisibility n m k hk hmn h).1

lemma product_loss_bound (n m k : ℕ) (hmn : n ≤ m) :
    (m+1)*P m k ≤ (m+1)*P n k + k*(m-n)*P m k := by
  induction k with
  | zero => simp [P]
  | succ k ih =>
    have hPnm : P n k ≤ P m k := Nat.ascFactorial_le _ (by omega)
    have hd : m+1+k = n+1+k+(m-n) := by omega
    have hmid : (m+1)*(m-n)*P n k ≤ (m-n)*((m+1+k)*P m k) := by
      calc
        _ = (m-n)*((m+1)*P n k) := by ac_rfl
        _ ≤ (m-n)*((m+1+k)*P m k) :=
          Nat.mul_le_mul_left _ (Nat.mul_le_mul (by omega) hPnm)
    have hPs (v : ℕ) : P v (k+1) = (v+1+k)*P v k := by
      exact Nat.ascFactorial_succ
    rw [hPs, hPs]
    calc
      _ = (m+1+k)*((m+1)*P m k) := by ac_rfl
      _ ≤ (m+1+k)*((m+1)*P n k + k*(m-n)*P m k) :=
        Nat.mul_le_mul_left _ ih
      _ = (m+1+k)*((m+1)*P n k) + (m+1+k)*(k*(m-n)*P m k) := by rw [Nat.mul_add]
      _ = (m+1)*((n+1+k)*P n k) + (m+1)*(m-n)*P n k +
          k*(m-n)*((m+1+k)*P m k) := by
        conv_lhs => arg 1; rw [hd, Nat.add_mul]
        ac_rfl
      _ ≤ (m+1)*((n+1+k)*P n k) + (m-n)*((m+1+k)*P m k) +
          k*(m-n)*((m+1+k)*P m k) := Nat.add_le_add_right (Nat.add_le_add_left hmid _) _
      _ = _ := by
        ring

/-- A collision forces a linear upper bound for its endpoint in terms
of the shift and the gap-adjusted multiplier, improving the earlier
fixed-gap LCM bound for large shifts. -/
theorem scaled_linear_gap_bound (n m k : ℕ) (hk : 0 < k)
    (hmn : n < m) (h : M m k = M n k) :
    m+1 ≤ k*(m-n)*R k (m-n) := by
  let r := R k (m-n)
  have hrp : r > 0 := R_pos _ _
  have hPmp : 0 < P m k := Nat.ascFactorial_pos _ _
  obtain ⟨q,hq⟩ := (scaled_product_divisibility n m k hk hmn h).1
  change P n k*r = P m k*q at hq
  have hq_lt : q < r := by
    by_contra! hnq
    have hg := Nat.mul_le_mul_left (P m k) hnq
    rw [← hq] at hg
    exact (not_lt_of_ge hg) (Nat.mul_lt_mul_of_pos_right (product_strict n m k hmn hk) hrp)
  have hqsum : P n k*r+P m k ≤ P m k*r := by
    rw [hq, ← Nat.mul_succ]
    exact Nat.mul_le_mul_left _ (by omega)
  have hloss := Nat.mul_le_mul_right r (product_loss_bound n m k hmn.le)
  rw [Nat.add_mul ((m+1)*P n k) _ r] at hloss
  have hleft := Nat.mul_le_mul_left (m+1) hqsum
  rw [Nat.mul_add, ← Nat.mul_assoc, ← Nat.mul_assoc] at hleft
  have hcomb := hleft.trans hloss
  have hcan : (m+1)*P m k ≤ k*(m-n)*P m k*r := by omega
  have hcan' : (m+1)*P m k ≤ (k*(m-n)*r)*P m k := by
    convert hcan using 1 <;> ac_rfl
  exact Nat.le_of_mul_le_mul_right hcan' hPmp

#print axioms valuation_difference_bound
#print axioms no_collision_if_prime_powers_divide_length_or_gap
#print axioms scaled_product_divisibility
#print axioms scaled_product_bound
#print axioms scaled_linear_gap_bound

end Erdos677Valuation

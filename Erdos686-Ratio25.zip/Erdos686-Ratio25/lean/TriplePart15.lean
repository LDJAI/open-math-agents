import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem cell62_0 {n k d : ℕ} (ak : 62≤k) (kb : k≤62) (sd : k≤d) (lo : 62≤d) (hi : d≤167) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=62) (b:=62) (f:=62) (s:=228) (U':=3602643278425739253328337678574471712869034806754130758672576135355655981160655084304633628752000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell62_1 {n k d : ℕ} (ak : 62≤k) (kb : k≤62) (sd : k≤d) (lo : 168≤d) (hi : d≤186) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=62) (b:=62) (f:=168) (s:=247) (U':=33216117145210841975416352095172082371056423324521218824612457552866313497868591504764276025256988217808000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row62 {n k d : ℕ} (ak : 62≤k) (kb : k≤62) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤167
  · exact cell62_0 ak kb sd (by omega) c0
  exact cell62_1 ak kb sd (by omega) (by omega)
private theorem cell63_0 {n k d : ℕ} (ak : 63≤k) (kb : k≤63) (sd : k≤d) (lo : 63≤d) (hi : d≤170) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=63) (b:=63) (f:=63) (s:=232) (U':=825005310759494289012189328393554022247008970746695943736019934996445219685790014305761100984208000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell63_1 {n k d : ℕ} (ak : 63≤k) (kb : k≤63) (sd : k≤d) (lo : 171≤d) (hi : d≤189) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=63) (b:=63) (f:=171) (s:=251) (U':=8337245403447921335829504375888192675135162254454825924977726845769444687965016467695833282339504042669808000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row63 {n k d : ℕ} (ak : 63≤k) (kb : k≤63) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤170
  · exact cell63_0 ak kb sd (by omega) c0
  exact cell63_1 ak kb sd (by omega) (by omega)
private theorem cell64_0 {n k d : ℕ} (ak : 64≤k) (kb : k≤64) (sd : k≤d) (lo : 64≤d) (hi : d≤177) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=64) (b:=64) (f:=64) (s:=240) (U':=45942070740263958472221787130251842836869188553971257018827742120147044948642588526644918430507590896000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell64_1 {n k d : ℕ} (ak : 64≤k) (kb : k≤64) (sd : k≤d) (lo : 178≤d) (hi : d≤192) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=64) (b:=64) (f:=178) (s:=255) (U':=8337245403447921335829504375888192675135162254454825924977726845769444687965016467695833282339504042669808000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row64 {n k d : ℕ} (ak : 64≤k) (kb : k≤64) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤177
  · exact cell64_0 ak kb sd (by omega) c0
  exact cell64_1 ak kb sd (by omega) (by omega)
private theorem cell65_0 {n k d : ℕ} (ak : 65≤k) (kb : k≤65) (sd : k≤d) (lo : 65≤d) (hi : d≤186) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=65) (b:=65) (f:=65) (s:=250) (U':=33216117145210841975416352095172082371056423324521218824612457552866313497868591504764276025256988217808000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell65_1 {n k d : ℕ} (ak : 65≤k) (kb : k≤65) (sd : k≤d) (lo : 187≤d) (hi : d≤195) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=65) (b:=65) (f:=187) (s:=259) (U':=4285344137372231566616365249206531035019473398789780525438551598725494569614018464395658307122505077932281312000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row65 {n k d : ℕ} (ak : 65≤k) (kb : k≤65) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤186
  · exact cell65_0 ak kb sd (by omega) c0
  exact cell65_1 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

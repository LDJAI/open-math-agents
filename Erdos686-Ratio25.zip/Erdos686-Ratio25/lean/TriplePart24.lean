import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem cell182_0 {n k d : ℕ} (ak : 182≤k) (kb : k≤219) (sd : k≤d) (lo : 182≤d) (hi : d≤657) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=182) (b:=219) (f:=182) (s:=875) (U':=759814026426817311399311870795445962172365487847147335555153858199548963979450757856999756769434296350513113370690209352732814528839624526020139522419699305430769176328050683822002078804706495279532037507333917099692379872105052464596038412336064804900402778628290656205400529320302778462827446472913220553953045542838861376865281479472801475763493663363912017828249203732160000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row182 {n k d : ℕ} (ak : 182≤k) (kb : k≤219) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  exact cell182_0 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

import Bound

namespace Ratio25
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem height2 {n m : ℕ} (hn : 1 ≤ n) (hm : n < m) : block m 2 ≠ 25*block n 2 :=
  no_large (t:=1) (d:=2) (h:=[5, 2]) (sgn:=(1)) (by decide +kernel) hn hm

theorem height4 {n m : ℕ} (hn : 0 ≤ n) (hm : n < m) : block m 4 ≠ 25*block n 4 :=
  no_large (t:=0) (d:=1) (h:=[5, 5, 1]) (sgn:=(1)) (by decide +kernel) hn hm

theorem height6 {n m : ℕ} (hn : 139 ≤ n) (hm : n < m) : block m 6 ≠ 25*block n 6 :=
  no_large (t:=139) (d:=16) (h:=[46288275, 974630, 6840, 16]) (sgn:=(1)) (by decide +kernel) hn hm

theorem height8 {n m : ℕ} (hn : 10 ≤ n) (hm : n < m) : block m 8 ≠ 25*block n 8 :=
  no_large (t:=10) (d:=1) (h:=[42004, 11890, 1251, 58, 1]) (sgn:=(1)) (by decide +kernel) hn hm

theorem height10 {n m : ℕ} (hn : 121683 ≤ n) (hm : n < m) : block m 10 ≠ 25*block n 10 :=
  no_large (t:=121683) (d:=256) (h:=[6831052979777378436266801875, 280677836590275512356214, 4613054425152016720, 37908713037280, 155761280, 256]) (sgn:=(1)) (by decide +kernel) hn hm

theorem height12 {n m : ℕ} (hn : 222 ≤ n) (hm : n < m) : block m 12 ≠ 25*block n 12 :=
  no_large (t:=222) (d:=2) (h:=[284478728295933, 7471606549419, 81761172965, 477154614, 1566296, 2742, 2]) (sgn:=(1)) (by decide +kernel) hn hm

theorem height14 {n m : ℕ} (hn : 123641932 ≤ n) (hm : n < m) : block m 14 ≠ 25*block n 14 :=
  no_large (t:=123641932) (d:=2048) (h:=[904670888036669354437759193388107364032351501467139439269213, 51218027166717909763473714314567202964117211081233230, 1242734319127644106542980943593521884507100024, 16751790481357999445972964453133468208, 135486312727713304346163968640, 657477454376457847552, 1772530844672, 2048]) (sgn:=(1)) (by decide +kernel) hn hm

theorem height16 {n m : ℕ} (hn : 2495 ≤ n) (hm : n < m) : block m 16 ≠ 25*block n 16 :=
  no_large (t:=2495) (d:=1) (h:=[1543031798315421208353672128, 4930815354492271091651472, 6893510643007920943324, 5507111913468794460, 2749711695196881, 878678870616, 175490258, 20028, 1]) (sgn:=(1)) (by decide +kernel) hn hm

end Ratio25

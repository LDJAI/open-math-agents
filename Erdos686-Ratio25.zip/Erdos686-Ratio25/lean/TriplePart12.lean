import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem cell50_0 {n k d : ℕ} (ak : 50≤k) (kb : k≤50) (sd : k≤d) (lo : 50≤d) (hi : d≤129) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=50) (b:=50) (f:=50) (s:=178) (U':=7203880527456061926730046032397876988312400372513092634469173493103827472000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell50_1 {n k d : ℕ} (ak : 50≤k) (kb : k≤50) (sd : k≤d) (lo : 130≤d) (hi : d≤150) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=50) (b:=50) (f:=130) (s:=199) (U':=337293588832926264639465766794841407432394382785157234228847021917234018060677390066992000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row50 {n k d : ℕ} (ak : 50≤k) (kb : k≤50) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤129
  · exact cell50_0 ak kb sd (by omega) c0
  exact cell50_1 ak kb sd (by omega) (by omega)
private theorem cell51_0 {n k d : ℕ} (ak : 51≤k) (kb : k≤51) (sd : k≤d) (lo : 51≤d) (hi : d≤128) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=51) (b:=51) (f:=51) (s:=178) (U':=7203880527456061926730046032397876988312400372513092634469173493103827472000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell51_1 {n k d : ℕ} (ak : 51≤k) (kb : k≤51) (sd : k≤d) (lo : 129≤d) (hi : d≤153) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=51) (b:=51) (f:=129) (s:=203) (U':=337293588832926264639465766794841407432394382785157234228847021917234018060677390066992000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row51 {n k d : ℕ} (ak : 51≤k) (kb : k≤51) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤128
  · exact cell51_0 ak kb sd (by omega) c0
  exact cell51_1 ak kb sd (by omega) (by omega)
private theorem cell52_0 {n k d : ℕ} (ak : 52≤k) (kb : k≤52) (sd : k≤d) (lo : 52≤d) (hi : d≤129) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=52) (b:=52) (f:=52) (s:=180) (U':=1289494614414635084884678239799219980907919666679843581569982055265585117488000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell52_1 {n k d : ℕ} (ak : 52≤k) (kb : k≤52) (sd : k≤d) (lo : 130≤d) (hi : d≤156) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=52) (b:=52) (f:=130) (s:=207) (U':=337293588832926264639465766794841407432394382785157234228847021917234018060677390066992000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row52 {n k d : ℕ} (ak : 52≤k) (kb : k≤52) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤129
  · exact cell52_0 ak kb sd (by omega) c0
  exact cell52_1 ak kb sd (by omega) (by omega)
private theorem cell53_0 {n k d : ℕ} (ak : 53≤k) (kb : k≤53) (sd : k≤d) (lo : 53≤d) (hi : d≤138) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=53) (b:=53) (f:=53) (s:=190) (U':=233398525209048950364126761403658816544333459669051688264166752003070906265328000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell53_1 {n k d : ℕ} (ak : 53≤k) (kb : k≤53) (sd : k≤d) (lo : 139≤d) (hi : d≤159) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=53) (b:=53) (f:=139) (s:=211) (U':=71168947243747441838927276793711536968235214767668176422286721624536377810802929304135312000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row53 {n k d : ℕ} (ak : 53≤k) (kb : k≤53) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤138
  · exact cell53_0 ak kb sd (by omega) c0
  exact cell53_1 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

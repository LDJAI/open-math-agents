import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem cell38_0 {n k d : ℕ} (ak : 38≤k) (kb : k≤38) (sd : k≤d) (lo : 38≤d) (hi : d≤83) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=38) (b:=38) (f:=38) (s:=120) (U':=955888052326228459513511038256280353796626534577600) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell38_1 {n k d : ℕ} (ak : 38≤k) (kb : k≤38) (sd : k≤d) (lo : 84≤d) (hi : d≤113) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=38) (b:=38) (f:=84) (s:=150) (U':=4963595372164418730243844250278933730416682962970482173955824000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell38_2 {n k d : ℕ} (ak : 38≤k) (kb : k≤38) (sd : k≤d) (lo : 114≤d) (hi : d≤114) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=38) (b:=38) (f:=114) (s:=151) (U':=749502901196827228266820481792118993292919127408542808267329424000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row38 {n k d : ℕ} (ak : 38≤k) (kb : k≤38) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤83
  · exact cell38_0 ak kb sd (by omega) c0
  by_cases c1 : d≤113
  · exact cell38_1 ak kb sd (by omega) c1
  exact cell38_2 ak kb sd (by omega) (by omega)
private theorem cell39_0 {n k d : ℕ} (ak : 39≤k) (kb : k≤39) (sd : k≤d) (lo : 39≤d) (hi : d≤86) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=39) (b:=39) (f:=39) (s:=124) (U':=10514768575588513054648621420819083891762891880353600) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell39_1 {n k d : ℕ} (ak : 39≤k) (kb : k≤39) (sd : k≤d) (lo : 87≤d) (hi : d≤117) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=39) (b:=39) (f:=87) (s:=155) (U':=749502901196827228266820481792118993292919127408542808267329424000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row39 {n k d : ℕ} (ak : 39≤k) (kb : k≤39) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤86
  · exact cell39_0 ak kb sd (by omega) c0
  exact cell39_1 ak kb sd (by omega) (by omega)
private theorem cell40_0 {n k d : ℕ} (ak : 40≤k) (kb : k≤40) (sd : k≤d) (lo : 40≤d) (hi : d≤97) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=40) (b:=40) (f:=40) (s:=136) (U':=1749342047920660916901891145781670987072592322134428432000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell40_1 {n k d : ℕ} (ak : 40≤k) (kb : k≤40) (sd : k≤d) (lo : 98≤d) (hi : d≤120) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=40) (b:=40) (f:=98) (s:=159) (U':=117671955487901874837890815641362681946988303003141220897970719568000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row40 {n k d : ℕ} (ak : 40≤k) (kb : k≤40) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤97
  · exact cell40_0 ak kb sd (by omega) c0
  exact cell40_1 ak kb sd (by omega) (by omega)
private theorem cell41_0 {n k d : ℕ} (ak : 41≤k) (kb : k≤41) (sd : k≤d) (lo : 41≤d) (hi : d≤96) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=41) (b:=41) (f:=41) (s:=136) (U':=1749342047920660916901891145781670987072592322134428432000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell41_1 {n k d : ℕ} (ak : 41≤k) (kb : k≤41) (sd : k≤d) (lo : 97≤d) (hi : d≤123) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=41) (b:=41) (f:=97) (s:=163) (U':=19180528744528005598576202949542117157359093389512019006369227289584000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row41 {n k d : ℕ} (ak : 41≤k) (kb : k≤41) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤96
  · exact cell41_0 ak kb sd (by omega) c0
  exact cell41_1 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

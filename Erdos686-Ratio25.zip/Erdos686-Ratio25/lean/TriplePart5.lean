import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem small22 : allGaps 22 = true := by decide +kernel
theorem row22 {n k d : ℕ} (ak : 22≤k) (kb : k≤22) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=22 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small22
private theorem small23 : allGaps 23 = true := by decide +kernel
theorem row23 {n k d : ℕ} (ak : 23≤k) (kb : k≤23) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=23 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small23
private theorem small24 : allGaps 24 = true := by decide +kernel
theorem row24 {n k d : ℕ} (ak : 24≤k) (kb : k≤24) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=24 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small24
private theorem small25 : allGaps 25 = true := by decide +kernel
theorem row25 {n k d : ℕ} (ak : 25≤k) (kb : k≤25) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=25 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small25
end Ratio25.TripleBlocks

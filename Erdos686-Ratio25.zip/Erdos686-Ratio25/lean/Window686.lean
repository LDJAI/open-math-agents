import WindowBase
import Transfer
import Center
import DifferenceWindow

namespace Ratio25.Window
open Erdos677Valuation Erdos677UpperBound Erdos677PrimePower Erdos677DifferenceWindow Finset

/-- The LCM of an interval is bounded by its binomial coefficient times the
LCM of the first w integers. Each prime power above w produces a carry. -/
theorem lcm_dvd_choose (z w : ℕ) : M z w ∣ U w*(z+w).choose w := by
  apply Finset.lcm_dvd
  intro x hx
  have hx' := mem_Ioc.mp hx
  have hxn : x≠0 := by omega
  have hch : 0<(z+w).choose w := Nat.choose_pos (by omega)
  change x ∣ _
  rw [← Nat.factorization_prime_le_iff_dvd hxn (Nat.mul_pos (U_pos _) hch).ne']
  intro p hp
  let e := x.factorization p
  let t := p.log w
  let b := p.log (z+w)+1
  have hpow : p^e ≤ z+w := (Nat.le_of_dvd (Nat.pos_of_ne_zero hxn) ((hp.pow_dvd_iff_le_factorization hxn).mpr le_rfl)).trans hx'.2
  have hle : e<b := Nat.lt_succ_of_le (Nat.le_log_of_pow_le hp.one_lt hpow)
  have hsub : Ico (t+1) (e+1) ⊆
      {i ∈ Ico 1 b | p^i ≤ w % p^i + z % p^i} := by
    intro i hi
    have hm := mem_Ico.mp hi
    have hbig : w<p^i := by
      apply Nat.lt_pow_of_log_lt hp.one_lt
      omega
    have hi' : i ≤ e := by omega
    have hd : p^i∣x := (hp.pow_dvd_iff_le_factorization hxn).mpr hi'
    have pos := (count_pos_iff_exists z w (p^i) (Nat.pow_pos hp.pos)).mpr ⟨x,hx,hd⟩
    rw [count_formula _ _ _ (Nat.pow_pos hp.pos),Nat.div_eq_of_lt hbig] at pos
    refine mem_filter.mpr ⟨mem_Ico.mpr (by omega),?_⟩
    by_contra! bad
    rw [Nat.add_comm (z % _) (w % _), if_neg bad.not_ge] at pos
    omega
  have count := Finset.card_le_card hsub
  rw [Nat.card_Ico] at count
  rw [Nat.factorization_mul (U_ne_zero _) hch.ne',Finsupp.add_apply,U_factorization _ hp,
    Nat.factorization_choose' hp (by dsimp [b]; omega : p.log (z+w)<b)]
  change e ≤ t+_
  omega

theorem choose_window_height {n k d s a : ℕ} (hk : 0<k) (hd : k≤d)
    (he : block (n+d) k=s*block n k) (ha : 0<a)
    (hs : 16*(d+k-1)≤a*(2*k-1)) : n+1≤k*a^2 := by
  let z := d-k
  let w := 2*k-1
  let T := d+k-1
  have hw : 0<w := by dsimp [w];omega
  have hzw : z+w=T := by dsimp [z,w,T];omega
  have hl := choose_window hk hd he
  have hdiv := hl.trans (lcm_dvd_choose z w)
  have hcc : 0 < (z+w).choose w := Nat.choose_pos (by omega)
  have hupper : (U w*(z+w).choose w)*w^w ≤ a^w*w^w := by
    calc _ ≤ (4^w*(z+w).choose w)*(w.factorial*4^w) :=
              Nat.mul_le_mul (Nat.mul_le_mul_right _ (U_le_four_pow w)) (factorial_power w)
         _ = (16:ℕ)^w*(w.factorial*(z+w).choose w) := by
              rw [show (16:ℕ)=4*4 by decide,mul_pow];ring
         _ ≤ 16^w*T^w := by
              rw [← Nat.ascFactorial_eq_factorial_mul_choose]
              exact Nat.mul_le_mul_left _ (by simpa only [hzw] using Nat.ascFactorial_le_pow_add z w)
         _ = (16*T)^w := (mul_pow _ _ _).symm
         _ ≤ (a*w)^w := Nat.pow_le_pow_left hs _
         _ = _ := mul_pow _ _ _
  have hm := Nat.le_of_mul_le_mul_right hupper (Nat.pow_pos hw)
  have hch : (n+k).choose k ≤ a^w := calc
    _ ≤ k*(n+k).choose k := Nat.le_mul_of_pos_left _ hk
    _ ≤ U w*(z+w).choose w := Nat.le_of_dvd (Nat.mul_pos (U_pos _) hcc) hdiv
    _ ≤ _ := hm
  have hnh : (n+1)^k ≤ (k*a^2)^k := calc
    _ ≤ (n+1).ascFactorial k := Nat.pow_succ_le_ascFactorial _ _
    _ = k.factorial*(n+k).choose k := Nat.ascFactorial_eq_factorial_mul_choose n k
    _ ≤ k^k*a^w := Nat.mul_le_mul (Nat.factorial_le_pow _) hch
    _ ≤ k^k*a^(2*k) := Nat.mul_le_mul_left _ (Nat.pow_le_pow_right ha (by dsimp [w];omega))
    _ = _ := by rw [mul_pow,← pow_mul]
  exact (Nat.pow_le_pow_iff_left hk.ne').mp hnh

/-- All integer-ratio-25 witnesses with separation at most 25k have length below 10000. -/
theorem k_lt_10000 {n k d : ℕ} (hk : 2≤k) (hd : k≤d) (hd' : d≤25*k)
    (he : block (n+d) k=25*block n k) : k<10000 := by
  by_contra! hh
  let j := d/k
  have hpos : 0<k := by omega
  have hj : 1≤j := (Nat.le_div_iff_mul_le hpos).mpr (by simpa using hd)
  have hj' : j≤25 := by dsimp [j]; exact (Nat.div_le_div_right hd').trans (by simp [hpos.ne'])
  have jsmall : ∀ t : Fin 26, 1≤t.val → (t.val+2)^2≤30*t.val := by decide +kernel
  have q := jsmall ⟨j,by omega⟩ hj
  have divle : j*k≤d := Nat.div_mul_le_self _ _
  have divlt : d<(j+1)*k := by
    have rem := Nat.mod_add_div d k
    have sm := Nat.mod_lt d hpos
    dsimp [j];nlinarith only [rem,sm]
  have hs : 16*(d+k-1) ≤ (10*(j+2))*(2*k-1) := by
    have w : 8*k≤5*(2*k-1) := by omega
    have q' := Nat.mul_le_mul_left (2*(j+2)) w
    have l : d+k-1≤(j+2)*k := by
      have : d+k ≤ (j+2)*k := by nlinarith only [divlt]
      omega
    nlinarith only [q',Nat.mul_le_mul_left 16 l]
  have upper := choose_window_height hpos hd he (show 0<10*(j+2) by positivity) hs
  have u : n+1≤3000*d := calc
    _ ≤ k*(10*(j+2))^2 := upper
    _ = 100*k*(j+2)^2 := by ring
    _ ≤ 100*k*(30*j) := Nat.mul_le_mul_left _ q
    _ = 3000*(j*k) := by ring
    _ ≤ _ := Nat.mul_le_mul_left _ divle
  have lo := lower_start he
  have l : 39≤k/256 := by omega
  have big := Nat.mul_le_mul_right d (Nat.mul_le_mul_left 158 l)
  omega

/-- A quadratic lower bound on the gap for every sufficiently long witness. -/
theorem quadratic_gap {n k d : ℕ} (hk : 10000≤k) (hd : k≤d)
    (he : block (n+d) k=25*block n k) : k^2 < 280*d := by
  have hpk : 0<k := by omega
  have hdlarge : 25*k<d := by
    by_contra! ha
    exact (not_lt_of_ge hk) (k_lt_10000 (by omega) hd ha he)
  let j := d/k
  have hj : 25≤j := (Nat.le_div_iff_mul_le hpk).mpr hdlarge.le
  have divle : j*k≤d := Nat.div_mul_le_self _ _
  have divlt : d<(j+1)*k := by
    have rem := Nat.mod_add_div d k
    have sm := Nat.mod_lt d hpk
    dsimp [j];nlinarith only [rem,sm]
  have scale : 16*(d+k-1) ≤ (9*j)*(2*k-1) := by
    have hkk : 2*k-1+1=2*k := by omega
    have hprod := Nat.mul_le_mul (show 20≤j by omega) (show 100≤k by omega)
    have h1 := Nat.mul_le_mul_right (k-9) (show 25≤j by omega)
    have h2 := Nat.mul_le_mul_right k (show 25≤j by omega)
    have hk9 : k-9+9=k := by omega
    have dd : d+k-1 ≤ d+k := Nat.sub_le _ _
    nlinarith only [divlt,h1,h2,congrArg (j*·) hk9,congrArg (j*·) hkk,hk,dd]
  have upper := choose_window_height hpk hd he (show 0<9*j by positivity) scale
  have up2 : (n+1)*k ≤ 81*d^2 := calc
    _ ≤ (k*(9*j)^2)*k := Nat.mul_le_mul_right _ upper
    _ = 81*(j*k)^2 := by ring
    _ ≤ _ := Nat.mul_le_mul_left _ (Nat.pow_le_pow_left divle 2)
  have c : 3*k ≤ 5*(158*(k/256)) := by omega
  have low := lower_start he
  have a := Nat.mul_le_mul_right d c
  have b := Nat.mul_le_mul_left k (show 50≤d by omega)
  have low2 : 29*k*d < 100*(n+1) := by nlinarith only [low,a,b]
  have f : (k^2)*d < (280*d)*d := by
    have m := Nat.mul_lt_mul_of_pos_right low2 hpk
    nlinarith only [m,up2,Nat.zero_le (d^2)]
  exact Nat.lt_of_mul_lt_mul_right f

/-- The external finite check has a sharply delimited role in the prime-power result. -/
theorem rough_prime_power_of_finite
    (finite : ∀ k n d : ℕ, 2≤k → k<10000 → k≤d → d≤25*k →
      block (n+d) k≠25*block n k)
    {n k p e d : ℕ} (hk : 3≤k) (hd : k≤d) (hp : p.Prime) (hpk : k<p)
    (heq : d=p^e) : block (n+d) k≠25*block n k := by
  intro he
  have b := gap_prime_power hk hd hp hpk (by rw [heq]) he
  rw [←heq,pow_two] at b
  have ds : d≤25*k := by have := Nat.lt_of_mul_lt_mul_right b; omega
  exact finite k n d (by omega) (k_lt_10000 (by omega) hd ds he) hd ds he

#print axioms quadratic_gap
#print axioms rough_prime_power_of_finite
#print axioms choose_window
#print axioms k_lt_10000
end Ratio25.Window

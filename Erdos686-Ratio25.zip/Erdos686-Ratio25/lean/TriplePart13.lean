import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem cell54_0 {n k d : ℕ} (ak : 54≤k) (kb : k≤54) (sd : k≤d) (lo : 54≤d) (hi : d≤137) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=54) (b:=54) (f:=54) (s:=190) (U':=233398525209048950364126761403658816544333459669051688264166752003070906265328000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell54_1 {n k d : ℕ} (ak : 54≤k) (kb : k≤54) (sd : k≤d) (lo : 138≤d) (hi : d≤162) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=54) (b:=54) (f:=138) (s:=215) (U':=71168947243747441838927276793711536968235214767668176422286721624536377810802929304135312000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row54 {n k d : ℕ} (ak : 54≤k) (kb : k≤54) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤137
  · exact cell54_0 ak kb sd (by omega) c0
  exact cell54_1 ak kb sd (by omega) (by omega)
private theorem cell55_0 {n k d : ℕ} (ak : 55≤k) (kb : k≤55) (sd : k≤d) (lo : 55≤d) (hi : d≤138) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=55) (b:=55) (f:=55) (s:=192) (U':=44579118314928349519548211428098833959967690796788872458455849632586543096677648000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell55_1 {n k d : ℕ} (ak : 55≤k) (kb : k≤55) (sd : k≤d) (lo : 139≤d) (hi : d≤165) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=55) (b:=55) (f:=139) (s:=219) (U':=71168947243747441838927276793711536968235214767668176422286721624536377810802929304135312000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row55 {n k d : ℕ} (ak : 55≤k) (kb : k≤55) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤138
  · exact cell55_0 ak kb sd (by omega) c0
  exact cell55_1 ak kb sd (by omega) (by omega)
private theorem cell56_0 {n k d : ℕ} (ak : 56≤k) (kb : k≤56) (sd : k≤d) (lo : 56≤d) (hi : d≤143) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=56) (b:=56) (f:=56) (s:=198) (U':=1694942657451890777082742546707745765991931571784709719742949858880572955078780854608000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell56_1 {n k d : ℕ} (ak : 56≤k) (kb : k≤56) (sd : k≤d) (lo : 144≤d) (hi : d≤168) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=56) (b:=56) (f:=144) (s:=223) (U':=15870675235355679530080782724997672743916452893190003342169938922271612251809053234822174576000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row56 {n k d : ℕ} (ak : 56≤k) (kb : k≤56) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤143
  · exact cell56_0 ak kb sd (by omega) c0
  exact cell56_1 ak kb sd (by omega) (by omega)
private theorem cell57_0 {n k d : ℕ} (ak : 57≤k) (kb : k≤57) (sd : k≤d) (lo : 57≤d) (hi : d≤154) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=57) (b:=57) (f:=57) (s:=210) (U':=337293588832926264639465766794841407432394382785157234228847021917234018060677390066992000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell57_1 {n k d : ℕ} (ak : 57≤k) (kb : k≤57) (sd : k≤d) (lo : 155≤d) (hi : d≤171) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=57) (b:=57) (f:=155) (s:=227) (U':=3602643278425739253328337678574471712869034806754130758672576135355655981160655084304633628752000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row57 {n k d : ℕ} (ak : 57≤k) (kb : k≤57) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤154
  · exact cell57_0 ak kb sd (by omega) c0
  exact cell57_1 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

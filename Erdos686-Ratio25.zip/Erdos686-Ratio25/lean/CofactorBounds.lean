import TripleResult
import Window686
import SmallCases

namespace Ratio25.CofactorBounds
open Ratio25.Window

theorem square_length {n k d : ℕ} (hk : 2≤k) (hd : k≤d)
    (he : block (n+d) k=25*block n k) : k^2 < 3333*d := by
  by_cases big : 10000≤k
  · have h := quadratic_gap big hd he
    omega
  have sep : 3*k<d := by
    by_contra! h
    exact TripleBlocks.short_separation hk (by omega : n+k≤n+d) (by simpa using h)
      ((ratio_iff n (n+d) k).mpr he)
  calc k^2 = k*k := pow_two _
       _ ≤ 9999*k := Nat.mul_le_mul_right k (by omega)
       _ = 3333*(3*k) := by ring
       _ < 3333*d := Nat.mul_lt_mul_of_pos_left sep (by decide)

theorem square_length_of_wide {n k d : ℕ} (hd : k≤d) (wide : 25*k<d)
    (he : block (n+d) k=25*block n k) : k^2 < 400*d := by
  by_cases big : 10000≤k
  · have h := quadratic_gap big hd he
    omega
  calc k^2 = k*k := pow_two _
       _ ≤ 10000*k := Nat.mul_le_mul_right k (by omega)
       _ = 400*(25*k) := by ring
       _ < 400*d := Nat.mul_lt_mul_of_pos_left wide (by decide)

theorem prime_bound {n k p d : ℕ} (hk : 2≤k) (hd : k≤d) (hp : p.Prime) (div : p∣d)
    (he : block (n+d) k=25*block n k) : p^2 < 25*k*d := by
  by_cases small : p≤k
  · have pd := Nat.le_of_dvd (by omega : 0<d) div
    have h0 : 0<k*d := Nat.mul_pos (by omega) (by omega)
    calc p^2 = p*p := pow_two _
         _ ≤ k*d := Nat.mul_le_mul small pd
         _ < 25*k*d := by rw [Nat.mul_assoc];omega
  have hk3 : 3≤k := by
    by_contra! h
    have e : k=2 := by omega
    subst k
    exact exclude2 (by omega) he
  have h := gap_prime_power (e:=1) hk3 hd hp (by omega) (by simpa using div) he
  simp only [pow_one] at h
  exact h.trans_le (Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ (Nat.sub_le _ _)))

/-- The argument also applies to any prime power q with base greater than k. -/
theorem quartic_bound {q k d t D : ℕ} (hq : 0<q) (dt : d=q*t)
    (len : k^2 < D*d) (fac : q^2 < 25*k*d) : d < (625*D)*t^4 := by
  have pos : 0<d := by
    by_contra! h
    have hh : d=0 := by omega
    simpa [hh] using fac
  have a := Nat.pow_lt_pow_left fac (by decide : 2≠0)
  have b : q^4 < 625*D*d^3 := calc
    q^4 = (q^2)^2 := by ring
    _ < (25*k*d)^2 := a
    _ = (k^2)*(625*d^2) := by ring
    _ < (D*d)*(625*d^2) := Nat.mul_lt_mul_of_pos_right len (by positivity)
    _ = 625*D*d^3 := by ring
  rw [dt] at b
  have qq : q < (625*D)*t^3 := Nat.lt_of_mul_lt_mul_right (a:=q^3)
    (by convert b using 1 <;> ring)
  have tp : 0<t := by
    by_contra! h
    have hh : t=0 := by omega
    simpa [dt,hh] using pos
  rw [dt]
  calc q*t < ((625*D)*t^3)*t := Nat.mul_lt_mul_of_pos_right qq tp
       _ = _ := by ring

theorem prime_cofactor {n k p d t : ℕ} (hk : 2≤k) (hd : k≤d) (hp : p.Prime)
    (dt : d=p*t) (he : block (n+d) k=25*block n k) :
    d < 2083125*t^4 ∧ n+1≤1024*d^3 := by
  constructor
  · exact quartic_bound hp.pos dt (square_length hk hd he) (prime_bound hk hd hp ⟨t,dt⟩ he)
  have h1 : 1≤2*k-1 := by omega
  have h2 := Nat.mul_le_mul_left (32*d) h1
  have h3 : 16*(d+k-1)≤32*d*(2*k-1) := by omega
  have hh := choose_window_height (by omega : 0<k) hd he (by omega : 0<32*d) h3
  calc n+1 ≤ k*(32*d)^2 := hh
       _ ≤ d*(32*d)^2 := Nat.mul_le_mul_right _ hd
       _ = 1024*d^3 := by ring

theorem prime_cofactor_of_wide {n k p d t : ℕ} (hk : 2≤k) (hd : k≤d) (hp : p.Prime)
    (dt : d=p*t) (wide : 25*k<d) (he : block (n+d) k=25*block n k) :
    d < 250000*t^4 :=
  quartic_bound hp.pos dt (square_length_of_wide hd wide he) (prime_bound hk hd hp ⟨t,dt⟩ he)

/-- For each fixed cofactor the original existential question on that family has a finite box. -/
theorem finite_prime_family (t : ℕ) :
    (∃ k n d p : ℕ, 2≤k ∧ k≤d ∧ p.Prime ∧ d=p*t ∧ block (n+d) k=25*block n k) ↔
    (let B := 2083125*t^4
     ∃ k ≤ B, ∃ n ≤ 1024*B^3, ∃ d ≤ B, ∃ p ≤ B,
       2≤k ∧ k≤d ∧ p.Prime ∧ d=p*t ∧ block (n+d) k=25*block n k) := by
  dsimp only
  constructor
  · rintro ⟨k,n,d,p,hk,hd,hp,dt,he⟩
    obtain ⟨bd,bn⟩ := prime_cofactor hk hd hp dt he
    have scale := Nat.mul_le_mul_left 1024 (Nat.pow_le_pow_left bd.le 3)
    have pd := Nat.le_of_dvd (by omega : 0<d) (show p∣d from ⟨t,dt⟩)
    exact ⟨k, by omega, n, by omega, d, bd.le, p, by omega, hk, hd, hp, dt, he⟩
  · rintro ⟨k,_,n,_,d,_,p,_,hk,hd,hp,dt,he⟩
    exact ⟨k,n,d,p,hk,hd,hp,dt,he⟩

#print axioms finite_prime_family
#print axioms prime_cofactor
#print axioms prime_cofactor_of_wide
end Ratio25.CofactorBounds

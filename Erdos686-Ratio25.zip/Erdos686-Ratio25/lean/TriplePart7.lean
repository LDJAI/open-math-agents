import GivenBracket
import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem small30 : GivenBracket.row 30 30 [249, 258, 267, 276, 284, 293, 302, 311, 320, 329, 337, 346, 355, 364, 373, 381, 390, 399, 408, 417, 426, 434, 443, 452, 461, 470, 479, 487, 496, 505, 514, 523, 532, 540, 549, 558, 567, 576, 584, 593, 602, 611, 620, 629, 637, 646, 655, 664, 673, 682, 690, 699, 708, 717, 726, 735, 743, 752, 761, 770, 779] = true := by decide +kernel
theorem row30 {n k d : ℕ} (ak : 30≤k) (kb : k≤30) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=30 := by omega
  subst k
  exact GivenBracket.row_sound [249, 258, 267, 276, 284, 293, 302, 311, 320, 329, 337, 346, 355, 364, 373, 381, 390, 399, 408, 417, 426, 434, 443, 452, 461, 470, 479, 487, 496, 505, 514, 523, 532, 540, 549, 558, 567, 576, 584, 593, 602, 611, 620, 629, 637, 646, 655, 664, 673, 682, 690, 699, 708, 717, 726, 735, 743, 752, 761, 770, 779] 30 d (by decide) (by omega) sd (by simp;omega) small30
private theorem small31 : GivenBracket.row 31 31 [267, 276, 285, 294, 304, 313, 322, 331, 340, 349, 358, 368, 377, 386, 395, 404, 413, 422, 431, 441, 450, 459, 468, 477, 486, 495, 505, 514, 523, 532, 541, 550, 559, 569, 578, 587, 596, 605, 614, 623, 633, 642, 651, 660, 669, 678, 687, 696, 706, 715, 724, 733, 742, 751, 760, 770, 779, 788, 797, 806, 815, 824, 834] = true := by decide +kernel
theorem row31 {n k d : ℕ} (ak : 31≤k) (kb : k≤31) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=31 := by omega
  subst k
  exact GivenBracket.row_sound [267, 276, 285, 294, 304, 313, 322, 331, 340, 349, 358, 368, 377, 386, 395, 404, 413, 422, 431, 441, 450, 459, 468, 477, 486, 495, 505, 514, 523, 532, 541, 550, 559, 569, 578, 587, 596, 605, 614, 623, 633, 642, 651, 660, 669, 678, 687, 696, 706, 715, 724, 733, 742, 751, 760, 770, 779, 788, 797, 806, 815, 824, 834] 31 d (by decide) (by omega) sd (by simp;omega) small31
private theorem cell32_0 {n k d : ℕ} (ak : 32≤k) (kb : k≤32) (sd : k≤d) (lo : 32≤d) (hi : d≤71) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=32) (b:=32) (f:=32) (s:=102) (U':=7041757898200960193617914702466542659236800) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell32_1 {n k d : ℕ} (ak : 32≤k) (kb : k≤32) (sd : k≤d) (lo : 72≤d) (hi : d≤95) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=32) (b:=32) (f:=72) (s:=126) (U':=52573842877942565273243107104095419458814459401768000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell32_2 {n k d : ℕ} (ak : 32≤k) (kb : k≤32) (sd : k≤d) (lo : 96≤d) (hi : d≤96) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=32) (b:=32) (f:=96) (s:=127) (U':=6676878045498705789701874602220118271269436344024536000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row32 {n k d : ℕ} (ak : 32≤k) (kb : k≤32) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤71
  · exact cell32_0 ak kb sd (by omega) c0
  by_cases c1 : d≤95
  · exact cell32_1 ak kb sd (by omega) c1
  exact cell32_2 ak kb sd (by omega) (by omega)
private theorem cell33_0 {n k d : ℕ} (ak : 33≤k) (kb : k≤33) (sd : k≤d) (lo : 33≤d) (hi : d≤70) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=33) (b:=33) (f:=33) (s:=102) (U':=7041757898200960193617914702466542659236800) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell33_1 {n k d : ℕ} (ak : 33≤k) (kb : k≤33) (sd : k≤d) (lo : 71≤d) (hi : d≤98) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=33) (b:=33) (f:=71) (s:=130) (U':=13353756090997411579403749204440236542538872688049072000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell33_2 {n k d : ℕ} (ak : 33≤k) (kb : k≤33) (sd : k≤d) (lo : 99≤d) (hi : d≤99) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=33) (b:=33) (f:=99) (s:=131) (U':=1749342047920660916901891145781670987072592322134428432000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row33 {n k d : ℕ} (ak : 33≤k) (kb : k≤33) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤70
  · exact cell33_0 ak kb sd (by omega) c0
  by_cases c1 : d≤98
  · exact cell33_1 ak kb sd (by omega) c1
  exact cell33_2 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

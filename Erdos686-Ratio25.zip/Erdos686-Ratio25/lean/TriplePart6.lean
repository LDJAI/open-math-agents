import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem small26 : allGaps 26 = true := by decide +kernel
theorem row26 {n k d : ℕ} (ak : 26≤k) (kb : k≤26) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=26 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small26
private theorem small27 : allGaps 27 = true := by decide +kernel
theorem row27 {n k d : ℕ} (ak : 27≤k) (kb : k≤27) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=27 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small27
private theorem small28 : allGaps 28 = true := by decide +kernel
theorem row28 {n k d : ℕ} (ak : 28≤k) (kb : k≤28) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=28 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small28
private theorem small29 : allGaps 29 = true := by decide +kernel
theorem row29 {n k d : ℕ} (ak : 29≤k) (kb : k≤29) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=29 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small29
end Ratio25.TripleBlocks

import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem cell70_0 {n k d : ℕ} (ak : 70≤k) (kb : k≤70) (sd : k≤d) (lo : 70≤d) (hi : d≤199) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=70) (b:=70) (f:=70) (s:=268) (U':=1127045508128896902020104060541317662210121503881712278190339070464805071808486856136058134773218835496189985056000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell70_1 {n k d : ℕ} (ak : 70≤k) (kb : k≤70) (sd : k≤d) (lo : 200≤d) (hi : d≤210) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=70) (b:=70) (f:=200) (s:=279) (U':=22758455867693502107120707756904220003315214360678005312879915227694429505545426681153113044812707729207780780605464288000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row70 {n k d : ℕ} (ak : 70≤k) (kb : k≤70) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤199
  · exact cell70_0 ak kb sd (by omega) c0
  exact cell70_1 ak kb sd (by omega) (by omega)
private theorem cell71_0 {n k d : ℕ} (ak : 71≤k) (kb : k≤71) (sd : k≤d) (lo : 71≤d) (hi : d≤200) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=71) (b:=71) (f:=71) (s:=270) (U':=303175241686673266643407992285614451134522684544180602833201209955032564316482964300599638253995866748475105980064000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell71_1 {n k d : ℕ} (ak : 71≤k) (kb : k≤71) (sd : k≤d) (lo : 201≤d) (hi : d≤213) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=71) (b:=71) (f:=201) (s:=283) (U':=1809820685966590368064560042952294287323635791604197016496149498651944117569488965965339008662640956749790351016088336574624000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row71 {n k d : ℕ} (ak : 71≤k) (kb : k≤71) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤200
  · exact cell71_0 ak kb sd (by omega) c0
  exact cell71_1 ak kb sd (by omega) (by omega)
private theorem cell72_0 {n k d : ℕ} (ak : 72≤k) (kb : k≤72) (sd : k≤d) (lo : 72≤d) (hi : d≤209) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=72) (b:=72) (f:=72) (s:=280) (U':=22758455867693502107120707756904220003315214360678005312879915227694429505545426681153113044812707729207780780605464288000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell72_1 {n k d : ℕ} (ak : 72≤k) (kb : k≤72) (sd : k≤d) (lo : 210≤d) (hi : d≤216) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=72) (b:=72) (f:=210) (s:=287) (U':=1809820685966590368064560042952294287323635791604197016496149498651944117569488965965339008662640956749790351016088336574624000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row72 {n k d : ℕ} (ak : 72≤k) (kb : k≤72) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤209
  · exact cell72_0 ak kb sd (by omega) c0
  exact cell72_1 ak kb sd (by omega) (by omega)
private theorem cell73_0 {n k d : ℕ} (ak : 73≤k) (kb : k≤73) (sd : k≤d) (lo : 73≤d) (hi : d≤210) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=73) (b:=73) (f:=73) (s:=282) (U':=6395126098821874092100918879690085820931575235350519492919256178982134691058264897404024765592370871907386399350135464928000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell73_1 {n k d : ℕ} (ak : 73≤k) (kb : k≤73) (sd : k≤d) (lo : 211≤d) (hi : d≤219) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=73) (b:=73) (f:=211) (s:=291) (U':=30766951661432036257097520730189002884501808457271349280434541477083049998681312421410763147264896264746435967273501721768608000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row73 {n k d : ℕ} (ak : 73≤k) (kb : k≤73) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤210
  · exact cell73_0 ak kb sd (by omega) c0
  exact cell73_1 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

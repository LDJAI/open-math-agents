import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Linarith
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Rat.Lemmas
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Data.Nat.Factorial.BigOperators

namespace Ratio25
open Finset

def block (n k : ℕ) := (n+1).ascFactorial k

theorem block_pos (n k : ℕ) : 0 < block n k := Nat.ascFactorial_pos n k

theorem block_mono (k : ℕ) : Monotone (fun n => block n k) := by
  intro a b h
  induction k with
  | zero => simp [block]
  | succ k ih =>
    simp only [block,Nat.ascFactorial_succ] at *
    exact Nat.mul_le_mul (by omega) ih

theorem block_step (n k : ℕ) :
    (n+1)*block (n+1) k = (n+k+1)*block n k := by
  unfold block
  rw [Nat.succ_ascFactorial]
  congr 1; omega

abbrev Coeff := List ℤ

def ev : Coeff → ℤ → ℤ
  | [], _ => 0
  | a::l, x => a+x*ev l x

def add : Coeff → Coeff → Coeff
  | [], b => b
  | a, [] => a
  | a::as, b::bs => (a+b)::add as bs

def scale (c : ℤ) (a : Coeff) := a.map (c*·)

def mul (a b : Coeff) : Coeff :=
  match a with
  | [] => []
  | c::cs => add (scale c b) (0::mul cs b)

/-- Multiply a coefficient list by a linear factor in a single traversal. -/
def lin (a b : ℤ) : ℤ → Coeff → Coeff
  | carry, [] => [carry]
  | carry, c::cs => (carry+a*c)::lin a b (b*c) cs

theorem ev_lin (a b z : ℤ) (l : Coeff) (carry : ℤ) :
    ev (lin a b carry l) z = carry+(a+b*z)*ev l z := by
  induction l generalizing carry with
  | nil => simp [lin,ev]
  | cons c l ih => simp only [lin,ev,ih]; ring

def shift (a : Coeff) : Coeff :=
  match a with
  | [] => []
  | c::cs => lin 1 1 c (shift cs)

theorem ev_add (a b : Coeff) (x : ℤ) : ev (add a b) x = ev a x + ev b x := by
  induction a generalizing b with
  | nil => simp [add,ev]
  | cons a l ih => cases b with
    | nil => simp [add,ev]
    | cons b s => simp only [add,ev,ih]; ring

theorem ev_scale (c : ℤ) (a : Coeff) (x : ℤ) : ev (scale c a) x = c * ev a x := by
  induction a with
  | nil => simp [scale,ev]
  | cons b l ih =>
    change c*b+x*ev (scale c l) x = c*(b+x*ev l x)
    rw [ih]; ring

theorem ev_mul (a b : Coeff) (x : ℤ) : ev (mul a b) x = ev a x * ev b x := by
  induction a with
  | nil => simp [mul,ev]
  | cons c cs ih => simp only [mul,ev_add,ev_scale,ev,ih]; ring

theorem ev_shift (a : Coeff) (x : ℤ) : ev (shift a) x = ev a (x+1) := by
  induction a with
  | nil => rfl
  | cons c l ih => simp only [shift,ev_lin,ev,ih]; ring

def sub (a b : Coeff) := add a (scale (-1) b)

theorem ev_sub (a b : Coeff) (x : ℤ) : ev (sub a b) x = ev a x - ev b x := by
  simp [sub,ev_add,ev_scale,sub_eq_add_neg]

def blockPoly (t : ℕ) : ℕ → Coeff
  | 0 => [1]
  | k+1 => lin ((t+k+1 : ℕ) : ℤ) 1 0 (blockPoly t k)

theorem eval_block (t k u : ℕ) : ev (blockPoly t k) u = (block (t+u) k : ℤ) := by
  induction k with
  | zero => simp [blockPoly,block,ev]
  | succ k ih =>
    simp only [blockPoly,ev_lin,ev,ih,block,Nat.ascFactorial_succ]
    push_cast
    ring

def positive (a : Coeff) : Bool :=
  decide (0 < a.headD 0) && a.all (fun z => decide (0≤z))

theorem nonneg_eval (a : Coeff) (x : ℤ) (hx : 0≤x)
    (h : a.all (fun z => decide (0≤z)) = true) : 0 ≤ ev a x := by
  induction a with
  | nil => rfl
  | cons c l ih =>
    simp only [List.all_cons,Bool.and_eq_true,decide_eq_true_eq] at h
    exact add_nonneg h.1 (mul_nonneg hx (ih h.2))

theorem positive_eval {a : Coeff} (h : positive a = true) (u : ℕ) : 0 < ev a u := by
  cases a with
  | nil => simp [positive] at h
  | cons c l =>
    simp only [positive,List.headD_cons,Bool.and_eq_true,decide_eq_true_eq,List.all_cons] at h
    exact add_pos_of_pos_of_nonneg (of_decide_eq_true h.1) (mul_nonneg (Int.natCast_nonneg _) (nonneg_eval _ _ (Int.natCast_nonneg _) h.2.2))

/-- Each positivity test bounds an integer polynomial on all inputs beyond t.
The last test certifies strict decrease of the residual divided by the block product. -/
def valid (k t d : ℕ) (h : Coeff) (sgn : ℤ) : Bool :=
  let p := blockPoly t k
  let dp := scale ((d:ℤ)^2) p
  let rem := scale sgn (sub (mul h h) dp)
  let lo := sub (scale 6 h) [1]
  let hi := add (scale 6 h) [1]
  positive lo && positive (sub (scale 36 dp) (mul lo lo)) &&
    positive (sub (mul hi hi) (scale 36 dp)) &&
    positive (sub (mul [((t+k+1:ℕ):ℤ),1] rem)
                  (mul [((t+1:ℕ):ℤ),1] (shift rem)))

theorem pin {a b z : ℤ} (ha : 0 < 6*a-1) (hb : 0 < 6*b-1)
    (la : (6*a-1)^2 < z) (ua : z < (6*a+1)^2)
    (lb : (6*b-1)^2 < 25*z) (ub : 25*z < (6*b+1)^2) : b = 5*a := by
  have l : 6*b-1 < 5*(6*a+1) := by
    by_contra! hh
    have h := mul_self_le_mul_self (by omega : 0 ≤ 5*(6*a+1)) hh
    nlinarith only [h,lb,ua]
  have r : 5*(6*a-1) < 6*b+1 := by
    by_contra! hh
    have h := mul_self_le_mul_self (by omega : 0 ≤ 6*b+1) hh
    nlinarith only [h,la,ub]
  omega

theorem no_large {k t d : ℕ} {h : Coeff} {sgn : ℤ} (hc : valid k t d h sgn = true)
    {n m : ℕ} (hn : t ≤ n) (hm : n < m) : block m k ≠ 25 * block n k := by
  let B (u : ℕ) : ℤ := block (t+u) k
  let H (u : ℕ) : ℤ := ev h u
  let R (u : ℕ) : ℤ := sgn * (H u ^ 2 - (d:ℤ)^2 * B u)
  have hp (u : ℕ) : 0 < B u := by dsimp [B]; exact_mod_cast block_pos (t+u) k
  simp only [valid,Bool.and_eq_true] at hc
  obtain ⟨⟨⟨hlo,ha⟩,hb⟩,hr⟩ := hc
  have strip (u : ℕ) : 0 < 6*H u-1 ∧ (6*H u-1)^2 < 36*(d:ℤ)^2*B u ∧
      36*(d:ℤ)^2*B u < (6*H u+1)^2 := by
    have aa := positive_eval ha u
    have bb := positive_eval hb u
    have ll := positive_eval hlo u
    simp only [ev_sub,ev_scale,ev_add,ev_mul,ev,eval_block,mul_zero,add_zero] at aa bb ll
    dsimp [H,B]; exact ⟨ll, by nlinarith only [aa], by nlinarith only [bb]⟩
  have step (u : ℕ) : R (u+1) * B u < R u * B (u+1) := by
    have hh := positive_eval hr u
    simp only [ev_sub,ev_mul,ev_scale,ev_shift,ev,eval_block,mul_zero,add_zero,mul_one] at hh
    have bs : ((t+u:ℕ)+1:ℤ) * B (u+1) = ((t+u:ℕ)+k+1:ℤ) * B u := by
      simpa [B,Nat.add_assoc,add_assoc] using (show (((t+u+1)*block (t+u+1) k:ℕ):ℤ) =
        (((t+u+k+1)*block (t+u) k:ℕ):ℤ) by exact_mod_cast block_step (t+u) k)
    have rr : ((t+u:ℕ)+1:ℤ) * R (u+1) < ((t+u:ℕ)+k+1:ℤ) * R u := by
      dsimp [R,H,B]
      have heval := eval_block t k (u+1)
      push_cast at heval
      rw [heval] at hh
      push_cast at hh ⊢
      linarith only [hh]
    have v := mul_lt_mul_of_pos_right rr (hp u)
    have eq : (((t+u:ℕ)+1:ℤ)*R (u+1))*B u < (((t+u:ℕ)+1:ℤ)*R u)*B (u+1) := by
      calc _ < _ := v
           _ = R u * (((t+u:ℕ)+k+1:ℤ)*B u) := by ring
           _ = _ := by rw [← bs]; ring
    exact lt_of_mul_lt_mul_left (a:=((t+u:ℕ)+1:ℤ)) (by linarith only [show ((t+u:ℕ)+1:ℤ)*(R (u+1)*B u) < ((t+u:ℕ)+1:ℤ)*(R u*B (u+1)) by simpa only [mul_assoc] using eq]) (by positivity)
  have dec (u v : ℕ) (huv : u < v) : R v * B u < R u * B v := by
    induction v, huv using Nat.le_induction with
    | base => exact step u
    | succ v hv ih =>
      have e := mul_lt_mul_of_pos_right (step v) (hp u)
      have f := mul_lt_mul_of_pos_right ih (hp (v+1))
      apply lt_of_mul_lt_mul_left (a:=B v) _ (hp v).le
      linarith only [show B v * (R (v+1) * B u) < B v * (R u * B (v+1)) by
        calc _ = (R (v+1)*B v)*B u := by ring
             _ < _ := e
             _ = (R v*B u)*B (v+1) := by ring
             _ < _ := f
             _ = _ := by ring]
  obtain ⟨u,rfl⟩ := Nat.exists_eq_add_of_le hn
  obtain ⟨v,rfl⟩ := Nat.exists_eq_add_of_le (show t≤m by omega)
  intro he
  have he' : B v = 25*B u := by dsimp [B]; exact_mod_cast he
  obtain ⟨l,a,b⟩ := strip u
  obtain ⟨l',a',b'⟩ := strip v
  rw [he'] at a' b'
  have e := pin l l' a b (by linarith only [a']) (by linarith only [b'])
  have rr : R v = 25*R u := by dsimp [R]; rw [he',e]; ring
  have bad := dec u v (by omega)
  rw [he',rr] at bad
  linarith only [show 25*R u*B u = R u*(25*B u) by ring, bad]

end Ratio25

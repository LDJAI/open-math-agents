import TriplePart0
import TriplePart1
import TriplePart2
import TriplePart3
import TriplePart4
import TriplePart5
import TriplePart6
import TriplePart7
import TriplePart8
import TriplePart9
import TriplePart10
import TriplePart11
import TriplePart12
import TriplePart13
import TriplePart14
import TriplePart15
import TriplePart16
import TriplePart17
import TriplePart18
import TriplePart19
import TriplePart20
import TriplePart21
import TriplePart22
import TriplePart23
import TriplePart24
import TriplePart25
import TriplePart26
import TriplePart27
import TriplePart28
import TriplePart29
namespace Ratio25.TripleBlocks
set_option maxHeartbeats 0
theorem short_separation {n m k : ℕ} (hk : 2≤k) (hs : n+k≤m) (hh : m-n≤3*k) :
    (25:ℚ) ≠ (∏ i ∈ Finset.Icc 1 k, (m+i)) / (∏ i ∈ Finset.Icc 1 k, (n+i)) := by
  intro ee
  have eq := (ratio_iff n m k).mp ee
  obtain ⟨d, rfl⟩ := Nat.exists_eq_add_of_le (show n≤m by omega)
  rw [Nat.add_sub_cancel_left] at hh
  have sd : k≤d := by omega
  have cap := length_cap (by omega : 0<k) sd hh eq
  by_cases c2 : k≤2
  · exact row2 (by omega) c2 sd hh eq
  by_cases c3 : k≤3
  · exact row3 (by omega) c3 sd hh eq
  by_cases c4 : k≤4
  · exact row4 (by omega) c4 sd hh eq
  by_cases c5 : k≤5
  · exact row5 (by omega) c5 sd hh eq
  by_cases c6 : k≤6
  · exact row6 (by omega) c6 sd hh eq
  by_cases c7 : k≤7
  · exact row7 (by omega) c7 sd hh eq
  by_cases c8 : k≤8
  · exact row8 (by omega) c8 sd hh eq
  by_cases c9 : k≤9
  · exact row9 (by omega) c9 sd hh eq
  by_cases c10 : k≤10
  · exact row10 (by omega) c10 sd hh eq
  by_cases c11 : k≤11
  · exact row11 (by omega) c11 sd hh eq
  by_cases c12 : k≤12
  · exact row12 (by omega) c12 sd hh eq
  by_cases c13 : k≤13
  · exact row13 (by omega) c13 sd hh eq
  by_cases c14 : k≤14
  · exact row14 (by omega) c14 sd hh eq
  by_cases c15 : k≤15
  · exact row15 (by omega) c15 sd hh eq
  by_cases c16 : k≤16
  · exact row16 (by omega) c16 sd hh eq
  by_cases c17 : k≤17
  · exact row17 (by omega) c17 sd hh eq
  by_cases c18 : k≤18
  · exact row18 (by omega) c18 sd hh eq
  by_cases c19 : k≤19
  · exact row19 (by omega) c19 sd hh eq
  by_cases c20 : k≤20
  · exact row20 (by omega) c20 sd hh eq
  by_cases c21 : k≤21
  · exact row21 (by omega) c21 sd hh eq
  by_cases c22 : k≤22
  · exact row22 (by omega) c22 sd hh eq
  by_cases c23 : k≤23
  · exact row23 (by omega) c23 sd hh eq
  by_cases c24 : k≤24
  · exact row24 (by omega) c24 sd hh eq
  by_cases c25 : k≤25
  · exact row25 (by omega) c25 sd hh eq
  by_cases c26 : k≤26
  · exact row26 (by omega) c26 sd hh eq
  by_cases c27 : k≤27
  · exact row27 (by omega) c27 sd hh eq
  by_cases c28 : k≤28
  · exact row28 (by omega) c28 sd hh eq
  by_cases c29 : k≤29
  · exact row29 (by omega) c29 sd hh eq
  by_cases c30 : k≤30
  · exact row30 (by omega) c30 sd hh eq
  by_cases c31 : k≤31
  · exact row31 (by omega) c31 sd hh eq
  by_cases c32 : k≤32
  · exact row32 (by omega) c32 sd hh eq
  by_cases c33 : k≤33
  · exact row33 (by omega) c33 sd hh eq
  by_cases c34 : k≤34
  · exact row34 (by omega) c34 sd hh eq
  by_cases c35 : k≤35
  · exact row35 (by omega) c35 sd hh eq
  by_cases c36 : k≤36
  · exact row36 (by omega) c36 sd hh eq
  by_cases c37 : k≤37
  · exact row37 (by omega) c37 sd hh eq
  by_cases c38 : k≤38
  · exact row38 (by omega) c38 sd hh eq
  by_cases c39 : k≤39
  · exact row39 (by omega) c39 sd hh eq
  by_cases c40 : k≤40
  · exact row40 (by omega) c40 sd hh eq
  by_cases c41 : k≤41
  · exact row41 (by omega) c41 sd hh eq
  by_cases c42 : k≤42
  · exact row42 (by omega) c42 sd hh eq
  by_cases c43 : k≤43
  · exact row43 (by omega) c43 sd hh eq
  by_cases c44 : k≤44
  · exact row44 (by omega) c44 sd hh eq
  by_cases c45 : k≤45
  · exact row45 (by omega) c45 sd hh eq
  by_cases c46 : k≤46
  · exact row46 (by omega) c46 sd hh eq
  by_cases c47 : k≤47
  · exact row47 (by omega) c47 sd hh eq
  by_cases c48 : k≤48
  · exact row48 (by omega) c48 sd hh eq
  by_cases c49 : k≤49
  · exact row49 (by omega) c49 sd hh eq
  by_cases c50 : k≤50
  · exact row50 (by omega) c50 sd hh eq
  by_cases c51 : k≤51
  · exact row51 (by omega) c51 sd hh eq
  by_cases c52 : k≤52
  · exact row52 (by omega) c52 sd hh eq
  by_cases c53 : k≤53
  · exact row53 (by omega) c53 sd hh eq
  by_cases c54 : k≤54
  · exact row54 (by omega) c54 sd hh eq
  by_cases c55 : k≤55
  · exact row55 (by omega) c55 sd hh eq
  by_cases c56 : k≤56
  · exact row56 (by omega) c56 sd hh eq
  by_cases c57 : k≤57
  · exact row57 (by omega) c57 sd hh eq
  by_cases c58 : k≤58
  · exact row58 (by omega) c58 sd hh eq
  by_cases c59 : k≤59
  · exact row59 (by omega) c59 sd hh eq
  by_cases c60 : k≤60
  · exact row60 (by omega) c60 sd hh eq
  by_cases c61 : k≤61
  · exact row61 (by omega) c61 sd hh eq
  by_cases c62 : k≤62
  · exact row62 (by omega) c62 sd hh eq
  by_cases c63 : k≤63
  · exact row63 (by omega) c63 sd hh eq
  by_cases c64 : k≤64
  · exact row64 (by omega) c64 sd hh eq
  by_cases c65 : k≤65
  · exact row65 (by omega) c65 sd hh eq
  by_cases c66 : k≤66
  · exact row66 (by omega) c66 sd hh eq
  by_cases c67 : k≤67
  · exact row67 (by omega) c67 sd hh eq
  by_cases c68 : k≤68
  · exact row68 (by omega) c68 sd hh eq
  by_cases c69 : k≤69
  · exact row69 (by omega) c69 sd hh eq
  by_cases c70 : k≤70
  · exact row70 (by omega) c70 sd hh eq
  by_cases c71 : k≤71
  · exact row71 (by omega) c71 sd hh eq
  by_cases c72 : k≤72
  · exact row72 (by omega) c72 sd hh eq
  by_cases c73 : k≤73
  · exact row73 (by omega) c73 sd hh eq
  by_cases c74 : k≤74
  · exact row74 (by omega) c74 sd hh eq
  by_cases c75 : k≤75
  · exact row75 (by omega) c75 sd hh eq
  by_cases c76 : k≤76
  · exact row76 (by omega) c76 sd hh eq
  by_cases c77 : k≤77
  · exact row77 (by omega) c77 sd hh eq
  by_cases c78 : k≤78
  · exact row78 (by omega) c78 sd hh eq
  by_cases c79 : k≤79
  · exact row79 (by omega) c79 sd hh eq
  by_cases c80 : k≤80
  · exact row80 (by omega) c80 sd hh eq
  by_cases c81 : k≤82
  · exact row81 (by omega) c81 sd hh eq
  by_cases c83 : k≤84
  · exact row83 (by omega) c83 sd hh eq
  by_cases c85 : k≤86
  · exact row85 (by omega) c85 sd hh eq
  by_cases c87 : k≤88
  · exact row87 (by omega) c87 sd hh eq
  by_cases c89 : k≤91
  · exact row89 (by omega) c89 sd hh eq
  by_cases c92 : k≤94
  · exact row92 (by omega) c92 sd hh eq
  by_cases c95 : k≤97
  · exact row95 (by omega) c95 sd hh eq
  by_cases c98 : k≤104
  · exact row98 (by omega) c98 sd hh eq
  by_cases c105 : k≤112
  · exact row105 (by omega) c105 sd hh eq
  by_cases c113 : k≤122
  · exact row113 (by omega) c113 sd hh eq
  by_cases c123 : k≤136
  · exact row123 (by omega) c123 sd hh eq
  by_cases c137 : k≤154
  · exact row137 (by omega) c137 sd hh eq
  by_cases c155 : k≤181
  · exact row155 (by omega) c155 sd hh eq
  by_cases c182 : k≤219
  · exact row182 (by omega) c182 sd hh eq
  by_cases c220 : k≤273
  · exact row220 (by omega) c220 sd hh eq
  by_cases c274 : k≤361
  · exact row274 (by omega) c274 sd hh eq
  by_cases c362 : k≤499
  · exact row362 (by omega) c362 sd hh eq
  by_cases c500 : k≤724
  · exact row500 (by omega) c500 sd hh eq
  exact row725 (by omega) (by omega) sd hh eq
#print axioms short_separation
end Ratio25.TripleBlocks

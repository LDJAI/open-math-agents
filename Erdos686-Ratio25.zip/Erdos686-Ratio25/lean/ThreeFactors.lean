import Transfer
import SmallCases
import Mathlib.Analysis.Complex.Exponential
namespace Ratio25.ThreeFactors
open Finset Erdos677Valuation Erdos677TransportSecond Erdos677PrimePower

theorem scale (k n d a b : ℕ) (hn : a*d ≤ b*(n+1)) :
    a^k * block (n+d) k ≤ (a+b)^k * block n k := by
  induction k with
  | zero => simp [block]
  | succ k ih =>
    have hf : a*(n+d+1+k) ≤ (a+b)*(n+1+k) := by nlinarith only [hn,Nat.zero_le (b*k)]
    simp only [pow_succ,block,Nat.ascFactorial_succ] at ih ⊢
    simpa only [Nat.mul_comm,Nat.mul_left_comm,Nat.mul_assoc] using Nat.mul_le_mul ih hf

theorem pow_bound {k : ℕ} (hk : 0<k) : (k+3)^k < 25*k^k := by
  have kr : (0:ℝ)<k := by exact_mod_cast hk
  have e := Real.exp_bound' (x:=1) (n:=3) (by norm_num) (by norm_num) (by decide)
  norm_num [Finset.sum_range_succ,Nat.factorial] at e
  have e1 : Real.exp 1 ≤ 14/5 := by linarith
  have e3 : Real.exp 3 < 25 := by
    calc Real.exp 3 = Real.exp 1 ^ 3 := by simpa using Real.exp_nat_mul 1 3
         _ ≤ (14/5:ℝ)^3 := pow_le_pow_left₀ (Real.exp_pos _).le e1 _
         _ < 25 := by norm_num
  have pow := pow_le_pow_left₀ (by positivity : 0≤3/(k:ℝ)+1) (Real.add_one_le_exp (3/(k:ℝ))) k
  rw [←Real.exp_nat_mul, show (k:ℝ)*(3/k)=3 by field_simp] at pow
  have frac : (((k:ℝ)+3)/(k:ℝ))^k < 25 := by
    rw [show ((k:ℝ)+3)/k=3/k+1 by field_simp;ring]
    exact pow.trans_lt e3
  rw [div_pow] at frac
  have last := (div_lt_iff₀ (pow_pos kr k)).mp frac
  exact_mod_cast last

theorem start {k n d q t : ℕ} (hk : 0<k) (dt : d=q*t) (ts : t≤3)
    (he : block (n+d) k=25*block n k) : n+1<k*q := by
  by_contra! h
  have h0 : k*d ≤ 3*(n+1) := calc
    k*d = (k*q)*t := by rw [dt];ring
    _ ≤ (n+1)*3 := Nat.mul_le_mul h ts
    _ = _ := by ring
  have h1 := scale k n d k 3 h0
  rw [he] at h1
  have h2 := Nat.mul_lt_mul_of_pos_right (pow_bound hk) (block_pos n k)
  have h3 : (25*k^k)*block n k = k^k*(25*block n k) := by ring
  omega

theorem diagonal_divisor {m n k i A B q : ℕ}
    (hsep : n+k≤m) (hk : 2≤k) (hi : i<k) (hA : 0<A)
    (hProd : A*(m+1).ascFactorial k=B*(n+1).ascFactorial k)
    (hq : q ∣ m-n) (hni : q ∣ n+1+i)
    (hCop : q.Coprime (edgeWeight k i).natAbs) :
    q^2 ∣ B*(n+1+i)-A*(m+1+i) := by
  have hqi : q ∣ m+1+i := by
    have hh := Nat.dvd_add hq hni
    have heq : m-n+(n+1+i)=m+1+i := by omega
    rwa [heq] at hh
  have hniZ : (q : ℤ) ∣ (n : ℤ)+1+(i : ℤ) := by exact_mod_cast hni
  have hqiZ : (q : ℤ) ∣ (m : ℤ)+1+(i : ℤ) := by exact_mod_cast hqi
  have hLift := ascFactorial_square_transport hi hi hniZ hqiZ hProd
  have hXY := cross_scaled_entry_lt hsep hk hi hi hA hProd
  let E := B*(n+1+i)-A*(m+1+i)
  have hfactor : (B : ℤ)*edgeWeight k i*((n : ℤ)+1+(i : ℤ)) -
      (A : ℤ)*edgeWeight k i*((m : ℤ)+1+(i : ℤ)) =
      edgeWeight k i*(E : ℤ) := by
    unfold E
    rw [Nat.cast_sub hXY.le]
    simp only [Nat.cast_mul, Nat.cast_add, Nat.cast_one]
    ring
  rw [hfactor] at hLift
  obtain ⟨z,hz⟩ := hLift
  have hAbsDvd : q^2 ∣ (edgeWeight k i).natAbs * E := by
    refine ⟨z.natAbs, ?_⟩
    have hh := congrArg Int.natAbs hz
    simpa only [Int.natAbs_mul, Int.natAbs_natCast, Int.natAbs_pow] using hh
  have hCop' : (q^2).Coprime (edgeWeight k i).natAbs := hCop.pow_left 2
  have hqE : q^2 ∣ E := hCop'.dvd_of_dvd_mul_left hAbsDvd
  exact hqE

theorem has_owner {n k d p e : ℕ} (hk : 3≤k) (hsep : k≤d) (hp : p.Prime)
    (hpk : k<p) (hqd : p^e∣d) (he : block (n+d) k = 25*block n k) :
    ∃ i<k, p^e ∣ n+1+i ∧ (p^e).Coprime (edgeWeight k i).natAbs := by
  have h2 : 2≤k := by omega
  have he' : 1*P (n+d) k=25*P n k := by simpa [P,block] using he
  have hdiv := (gap_dvd_difference_product h2 hsep (by decide : 0<1) he').2
  have hl : P n k ∣ (k-1).factorial*M n k :=
    Erdos677UpperBound.product_dvd_factorial_mul_L n k (by omega)
  have hmul : p^e ∣ (24*(k-1).factorial)*M n k := by
    rw [Nat.mul_assoc]
    exact (hqd.trans hdiv).trans (Nat.mul_dvd_mul_left 24 hl)
  have hn : ¬p∣24 := by
    intro hh
    rw [show 24=2*2*2*3 by decide] at hh
    rcases hp.dvd_mul.mp hh with hh|h3
    · rcases hp.dvd_mul.mp hh with hh|h2
      · rcases hp.dvd_mul.mp hh with h2|h2 <;> have := Nat.le_of_dvd (by decide : 0<2) h2 <;> omega
      · have := Nat.le_of_dvd (by decide : 0<2) h2; omega
    · have := Nat.le_of_dvd (by decide : 0<3) h3; omega
  have hf : ¬p∣(k-1).factorial := fun hh => (by have := prime_le_of_dvd_factorial hp hh; omega)
  have hlcm := ((hp.coprime_iff_not_dvd.mpr (fun hh => (hp.dvd_mul.mp hh).elim hn hf)).pow_left e).dvd_of_dvd_mul_left hmul
  obtain ⟨i,hi,ho⟩ := owner (by omega : 0<k) hp hlcm
  have hcop := (hp.coprime_iff_not_dvd.mpr (prime_not_dvd_edgeWeight hp hpk hi)).pow_left e
  exact ⟨i,hi,ho,hcop⟩


/-- A large-base prime power, multiplied by at most three, forces a short gap. -/
theorem small_cofactor {n k d p e t : ℕ} (hk : 2≤k) (hs : k≤d)
    (hp : p.Prime) (kp : k<p) (dt : d=p^e*t) (ht : t≤3)
    (he : block (n+d) k=25*block n k) : d≤25*k := by
  by_contra! wide
  have hk3 : 3≤k := by
    by_contra! h
    have kk : k=2 := by omega
    subst k
    exact exclude2 (by omega) he
  let q := p^e
  have hdt : d=q*t := dt
  have pos : 0<q := Nat.pow_pos hp.pos
  have tq : 0<t := by
    by_contra! h
    have hh : t=0 := by omega
    have h0 : d=0 := by simp [hdt,hh]
    omega
  have kq : k<q := by
    by_contra! hh
    have b := Nat.mul_le_mul hh ht
    omega
  have tc : ¬p∣t := by intro h;have := Nat.le_of_dvd tq h;omega
  have cop : q.Coprime t := (hp.coprime_iff_not_dvd.mpr tc).pow_left e
  have tf : t∣24 := by interval_cases t <;> decide
  obtain ⟨i,hi,own,edge⟩ := has_owner hk3 hs hp kp (show p^e∣d from ⟨t,dt⟩) he
  obtain ⟨u,hu⟩ : q∣n+1+i := own
  have hpos : 0<u := by
    by_contra! h
    have hh : u=0 := by omega
    simp [hh] at hu
  have ub := start (by omega : 0<k) hdt ht he
  have uq : u≤k := by
    by_contra! hu'
    have h := Nat.mul_le_mul_left q (show k+1≤u by omega)
    rw [Nat.mul_add,Nat.mul_one,Nat.mul_comm q k] at h
    omega
  have prod : 1*(n+d+1).ascFactorial k = 25*(n+1).ascFactorial k := by simpa [block] using he
  have dv := diagonal_divisor (by omega : n+k≤n+d) hk hi (by decide : 0<1) prod
    (by simpa using (show q∣d from ⟨t,hdt⟩)) (show q∣n+1+i from ⟨u,hu⟩) edge
  simp only [Nat.one_mul] at dv
  have ep : t<24*u := by omega
  have eq : 25*(n+1+i) - (n+d+1+i) = q*(24*u-t) := by
    rw [Nat.mul_sub,show q*(24*u)=24*(q*u) by ring,←hu,←hdt]
    omega
  rw [eq,pow_two] at dv
  have qdiv : q∣24*u-t := Nat.dvd_of_mul_dvd_mul_left pos dv
  have tdiv : t∣24*u-t := Nat.dvd_sub (tf.trans (dvd_mul_right _ _)) (dvd_refl _)
  have pair := Nat.le_of_dvd (by omega : 0<24*u-t) (cop.mul_dvd_of_dvd_of_dvd qdiv tdiv)
  omega

/-- Applies to every prime, including primes smaller than the length. -/
theorem prime_times_three {n k d p t : ℕ} (hk : 2≤k) (hs : k≤d)
    (hp : p.Prime) (dt : d=p*t) (ht : t≤3)
    (he : block (n+d) k=25*block n k) : d≤25*k := by
  by_cases kp : k<p
  · exact small_cofactor (e:=1) hk hs hp kp (by simpa using dt) ht he
  · have h := Nat.mul_le_mul (show p≤k by omega) ht
    omega

#print axioms prime_times_three
#print axioms small_cofactor
end Ratio25.ThreeFactors

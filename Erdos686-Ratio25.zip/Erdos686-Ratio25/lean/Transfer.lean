import PrimePower
import Finite

namespace Ratio25
open Finset Erdos677Valuation Erdos677PrimePower Erdos677TransportSecond

/-- A large prime-power factor of the gap forces a quadratic bound at every length. -/
theorem gap_prime_power {n k d p e : ℕ} (hk : 3≤k) (hsep : k≤d) (hp : p.Prime)
    (hpk : k<p) (hqd : p^e∣d) (he : block (n+d) k = 25*block n k) :
    (p^e)^2 < 25*(k-1)*d := by
  have h2 : 2≤k := by omega
  have he' : 1*P (n+d) k=25*P n k := by simpa [P,block] using he
  have hdiv := (gap_dvd_difference_product h2 hsep (by decide : 0<1) he').2
  have hl : P n k ∣ (k-1).factorial*M n k :=
    Erdos677UpperBound.product_dvd_factorial_mul_L n k (by omega)
  have hmul : p^e ∣ (24*(k-1).factorial)*M n k := by
    rw [Nat.mul_assoc]
    exact (hqd.trans hdiv).trans (Nat.mul_dvd_mul_left 24 hl)
  have hn : ¬p∣24 := by
    intro hh
    rw [show 24=2*2*2*3 by decide] at hh
    rcases hp.dvd_mul.mp hh with hh|h3
    · rcases hp.dvd_mul.mp hh with hh|h2
      · rcases hp.dvd_mul.mp hh with h2|h2 <;> have := Nat.le_of_dvd (by decide : 0<2) h2 <;> omega
      · have := Nat.le_of_dvd (by decide : 0<2) h2; omega
    · have := Nat.le_of_dvd (by decide : 0<3) h3; omega
  have hf : ¬p∣(k-1).factorial := fun hh => (by have := prime_le_of_dvd_factorial hp hh; omega)
  have hlcm := ((hp.coprime_iff_not_dvd.mpr (fun hh => (hp.dvd_mul.mp hh).elim hn hf)).pow_left e).dvd_of_dvd_mul_left hmul
  obtain ⟨i,hi,ho⟩ := owner (by omega : 0<k) hp hlcm
  have hcop := (hp.coprime_iff_not_dvd.mpr (prime_not_dvd_edgeWeight hp hpk hi)).pow_left e
  have result := diagonal_divisor_square_bound (by omega : n+k≤n+d) h2 hi
    (by decide : 0<1) he' (by simpa using hqd) ho hcop
  simpa using result

#print axioms gap_prime_power
end Ratio25

import Finite
import Strips
namespace Ratio25.Length18
open Strips
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private theorem high {n m : ℕ} (hn : 918715824950≤n) (hm : n<m) : block m 18 ≠ 25*block n 18 :=
  no_large (t:=918715824950) (d:=65536) (h:=[30556999382974449541680003974025288768401103232184715702626855488810421633948226116377646921827481197280629515357, 299345006339575699190641047067999840333528386298872341711279866391400625145220303615729289915180094886, 1303319255887518021827959782759315406541948388388903765167626931471548337506193608776697568, 3310140286166946925641277863021716126696745014249719113534841418848430070540992, 5404511704660473343322201866699763309100141478273453836924048490752, 5882680539326425453882878607633446060372211980093715968, 4268770516052123272346386650911035053404160, 1991337286901204723588066697216, 541880642740912128, 65536]) (sgn:=(1)) (by decide +kernel) hn hm
private theorem small {n m : ℕ} (hn : n<100) (hm : n+2≤m) : block m 18 ≠ 25*block n 18 :=
  separated_sound (l:=[1, 2, 3, 4, 6, 7, 8, 9, 11, 12, 13, 14, 15, 17, 18, 19, 20, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 34, 35, 36, 37, 38, 40, 41, 42, 43, 44, 46, 47, 48, 49, 50, 51, 53, 54, 55, 56, 57, 59, 60, 61, 62, 63, 65, 66, 67, 68, 69, 71, 72, 73, 74, 75, 77, 78, 79, 80, 81, 83, 84, 85, 86, 87, 89, 90, 91, 92, 93, 95, 96, 97, 98, 99, 101, 102, 103, 104, 105, 107, 108, 109, 110, 111, 113, 114, 115, 116, 117, 119, 120]) (t:=0) (by decide +kernel) (Nat.zero_le _) (by simpa using hn) hm
private theorem part0 {n m : ℕ} (ha : 100≤n) (hb : n≤199) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=6) (q:=5) (l:=(5)) (cs:=[[150], []]) (by decide +kernel) ha hb
private theorem part1 {n m : ℕ} (ha : 200≤n) (hb : n≤399) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=55) (q:=46) (l:=(85)) (cs:=[[200], [292], []]) (by decide +kernel) ha hb
private theorem part2 {n m : ℕ} (ha : 400≤n) (hb : n≤799) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=171) (q:=143) (l:=(264)) (cs:=[[432], [724], []]) (by decide +kernel) ha hb
private theorem part3 {n m : ℕ} (ha : 800≤n) (hb : n≤1599) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=171) (q:=143) (l:=(266)) (cs:=[[1210], []]) (by decide +kernel) ha hb
private theorem part4 {n m : ℕ} (ha : 1600≤n) (hb : n≤3199) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=171) (q:=143) (l:=(267)) (cs:=[[1839], [2538], []]) (by decide +kernel) ha hb
private theorem part5 {n m : ℕ} (ha : 3200≤n) (hb : n≤6399) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=971) (q:=812) (l:=(1510)) (cs:=[[4559], []]) (by decide +kernel) ha hb
private theorem part6 {n m : ℕ} (ha : 6400≤n) (hb : n≤12799) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=971) (q:=812) (l:=(1511)) (cs:=[[6931], [9741], [12779], []]) (by decide +kernel) ha hb
private theorem part7 {n m : ℕ} (ha : 12800≤n) (hb : n≤25599) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=3713) (q:=3105) (l:=(5773)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part8 {n m : ℕ} (ha : 25600≤n) (hb : n≤51199) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=12110) (q:=10127) (l:=(18837)) (cs:=[[39960], []]) (by decide +kernel) ha hb
private theorem part9 {n m : ℕ} (ha : 51200≤n) (hb : n≤102399) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=12110) (q:=10127) (l:=(18838)) (cs:=[[67484], []]) (by decide +kernel) ha hb
private theorem part10 {n m : ℕ} (ha : 102400≤n) (hb : n≤204799) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=12110) (q:=10127) (l:=(18839)) (cs:=[[107627], [155015], []]) (by decide +kernel) ha hb
private theorem part11 {n m : ℕ} (ha : 204800≤n) (hb : n≤409599) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=64263) (q:=53740) (l:=(99966)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part12 {n m : ℕ} (ha : 409600≤n) (hb : n≤819199) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=64263) (q:=53740) (l:=(99966)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part13 {n m : ℕ} (ha : 819200≤n) (hb : n≤1638399) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=64263) (q:=53740) (l:=(99964)) (cs:=[[1411938], [947698], []]) (by decide +kernel) ha hb
private theorem part14 {n m : ℕ} (ha : 1638400≤n) (hb : n≤3276799) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=526214) (q:=440047) (l:=(818583)) (cs:=[[2796937], []]) (by decide +kernel) ha hb
private theorem part15 {n m : ℕ} (ha : 3276800≤n) (hb : n≤6553599) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=526214) (q:=440047) (l:=(818582)) (cs:=[[4936441], []]) (by decide +kernel) ha hb
private theorem part16 {n m : ℕ} (ha : 6553600≤n) (hb : n≤13107199) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=2040593) (q:=1706448) (l:=(3174375)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part17 {n m : ℕ} (ha : 13107200≤n) (hb : n≤26214399) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=2040593) (q:=1706448) (l:=(3174373)) (cs:=[[22709641], [13754848], []]) (by decide +kernel) ha hb
private theorem part18 {n m : ℕ} (ha : 26214400≤n) (hb : n≤52428799) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=7636158) (q:=6385745) (l:=(11878924)) (cs:=[[34588741], [45866008], []]) (by decide +kernel) ha hb
private theorem part19 {n m : ℕ} (ha : 52428800≤n) (hb : n≤104857599) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=17312909) (q:=14477938) (l:=(26932223)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part20 {n m : ℕ} (ha : 104857600≤n) (hb : n≤209715199) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=17312909) (q:=14477938) (l:=(26932223)) (cs:=[[130467877], []]) (by decide +kernel) ha hb
private theorem part21 {n m : ℕ} (ha : 209715200≤n) (hb : n≤419430399) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=17312909) (q:=14477938) (l:=(26932224)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part22 {n m : ℕ} (ha : 419430400≤n) (hb : n≤838860799) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=17312909) (q:=14477938) (l:=(26932224)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part23 {n m : ℕ} (ha : 838860800≤n) (hb : n≤1677721599) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=17312909) (q:=14477938) (l:=(26932224)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part24 {n m : ℕ} (ha : 1677721600≤n) (hb : n≤3355443199) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=17312909) (q:=14477938) (l:=(26932224)) (cs:=[[1893898631], []]) (by decide +kernel) ha hb
private theorem part25 {n m : ℕ} (ha : 3355443200≤n) (hb : n≤6710886399) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=17312909) (q:=14477938) (l:=(26932225)) (cs:=[[5336593876], []]) (by decide +kernel) ha hb
private theorem part26 {n m : ℕ} (ha : 6710886400≤n) (hb : n≤13421772799) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=17312909) (q:=14477938) (l:=(26932226)) (cs:=[[8845089371], [12364000144], []]) (by decide +kernel) ha hb
private theorem part27 {n m : ℕ} (ha : 13421772800≤n) (hb : n≤26843545599) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=4216713638) (q:=3526231127) (l:=(6559583853)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part28 {n m : ℕ} (ha : 26843545600≤n) (hb : n≤53687091199) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=4216713638) (q:=3526231127) (l:=(6559583853)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part29 {n m : ℕ} (ha : 53687091200≤n) (hb : n≤107374182399) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=4216713638) (q:=3526231127) (l:=(6559583853)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part30 {n m : ℕ} (ha : 107374182400≤n) (hb : n≤214748364799) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=4216713638) (q:=3526231127) (l:=(6559583851)) (cs:=[[195430332210], [108797492792], []]) (by decide +kernel) ha hb
private theorem part31 {n m : ℕ} (ha : 214748364800≤n) (hb : n≤429496729599) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=97001726583) (q:=81117793859) (l:=(150897360876)) (cs:=[[]]) (by decide +kernel) ha hb
private theorem part32 {n m : ℕ} (ha : 429496729600≤n) (hb : n≤858993459199) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=97001726583) (q:=81117793859) (l:=(150897360876)) (cs:=[[460241133988, 490985538377], []]) (by decide +kernel) ha hb
private theorem part33 {n m : ℕ} (ha : 858993459200≤n) (hb : n≤918715824949) : block m 18 ≠ 25*block n 18 :=
  band_sound (p:=97001726583) (q:=81117793859) (l:=(150897360877)) (cs:=[[]]) (by decide +kernel) ha hb
theorem exclusion {n m : ℕ} (hm : n+2≤m) : block m 18 ≠ 25*block n 18 := by
  by_cases hh : n<100
  · exact small hh hm
  by_cases h0 : n≤199
  · exact part0 (by omega) h0
  by_cases h1 : n≤399
  · exact part1 (by omega) h1
  by_cases h2 : n≤799
  · exact part2 (by omega) h2
  by_cases h3 : n≤1599
  · exact part3 (by omega) h3
  by_cases h4 : n≤3199
  · exact part4 (by omega) h4
  by_cases h5 : n≤6399
  · exact part5 (by omega) h5
  by_cases h6 : n≤12799
  · exact part6 (by omega) h6
  by_cases h7 : n≤25599
  · exact part7 (by omega) h7
  by_cases h8 : n≤51199
  · exact part8 (by omega) h8
  by_cases h9 : n≤102399
  · exact part9 (by omega) h9
  by_cases h10 : n≤204799
  · exact part10 (by omega) h10
  by_cases h11 : n≤409599
  · exact part11 (by omega) h11
  by_cases h12 : n≤819199
  · exact part12 (by omega) h12
  by_cases h13 : n≤1638399
  · exact part13 (by omega) h13
  by_cases h14 : n≤3276799
  · exact part14 (by omega) h14
  by_cases h15 : n≤6553599
  · exact part15 (by omega) h15
  by_cases h16 : n≤13107199
  · exact part16 (by omega) h16
  by_cases h17 : n≤26214399
  · exact part17 (by omega) h17
  by_cases h18 : n≤52428799
  · exact part18 (by omega) h18
  by_cases h19 : n≤104857599
  · exact part19 (by omega) h19
  by_cases h20 : n≤209715199
  · exact part20 (by omega) h20
  by_cases h21 : n≤419430399
  · exact part21 (by omega) h21
  by_cases h22 : n≤838860799
  · exact part22 (by omega) h22
  by_cases h23 : n≤1677721599
  · exact part23 (by omega) h23
  by_cases h24 : n≤3355443199
  · exact part24 (by omega) h24
  by_cases h25 : n≤6710886399
  · exact part25 (by omega) h25
  by_cases h26 : n≤13421772799
  · exact part26 (by omega) h26
  by_cases h27 : n≤26843545599
  · exact part27 (by omega) h27
  by_cases h28 : n≤53687091199
  · exact part28 (by omega) h28
  by_cases h29 : n≤107374182399
  · exact part29 (by omega) h29
  by_cases h30 : n≤214748364799
  · exact part30 (by omega) h30
  by_cases h31 : n≤429496729599
  · exact part31 (by omega) h31
  by_cases h32 : n≤858993459199
  · exact part32 (by omega) h32
  by_cases h33 : n≤918715824949
  · exact part33 (by omega) h33
  exact high (by omega) (by omega)
#print axioms exclusion
end Ratio25.Length18

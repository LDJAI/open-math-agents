import WindowBase
import Center
import SmallGap

namespace Ratio25.CloseBlocks
open Erdos677Valuation Erdos677UpperBound Ratio25.Window Finset

theorem upperLCM {n k d : ℕ} (hk : 0<k) (hs : k≤d) (h : block (n+d) k = 25*block n k) :
    k*(n+k).choose k ≤ U (d+k-1) := by
  apply Nat.le_of_dvd (U_pos _)
  apply (choose_window hk hs h).trans
  change (Ioc (d-k) ((d-k)+(2*k-1))).lcm id ∣ (Icc 1 (d+k-1)).lcm id
  apply Finset.lcm_dvd
  intro i hi
  exact Finset.dvd_lcm (f:=id) (mem_Icc.mpr (by have := mem_Ioc.mp hi;omega))

theorem length_cap {n k d : ℕ} (hk : 0<k) (hs : k≤d) (hh : 2*d≤3*k)
    (h : block (n+d) k=25*block n k) : k<136 := by
  have hc : (n+k).choose k ≤ U (d+k-1) :=
    (Nat.le_mul_of_pos_left _ hk).trans (upperLCM hk hs h)
  have u : U (d+k-1)^2 ≤ (32^k)^2 := calc
    _ ≤ (4^(d+k-1))^2 := Nat.pow_le_pow_left (U_le_four_pow _) _
    _ = 4^((d+k-1)*2) := (pow_mul _ _ _).symm
    _ ≤ 4^(5*k) := Nat.pow_le_pow_right (by decide) (by omega)
    _ = _ := by
      calc 4^(5*k) = ((32:ℕ)^2)^k := by rw [pow_mul];rfl
           _ = _ := by rw [←pow_mul,←pow_mul,Nat.mul_comm 2 k]
  have upper := hc.trans ((Nat.pow_le_pow_iff_left (by decide : 2≠0)).mp u)
  have b : (n+1)^k ≤ (32*k)^k := calc
    _ ≤ block n k := Nat.pow_succ_le_ascFactorial _ _
    _ = k.factorial*(n+k).choose k := Nat.ascFactorial_eq_factorial_mul_choose _ _
    _ ≤ k^k*32^k := Nat.mul_le_mul (Nat.factorial_le_pow _) upper
    _ = _ := by rw [mul_pow]; ac_rfl
  have size := (Nat.pow_le_pow_iff_left hk.ne').mp b
  have lower := uniform_bound (l:=8) (c:=2) (by decide) (by decide) h
  change 4*(k/8)*d < 2*n+k+1 at lower
  by_contra! no
  have prod := Nat.mul_le_mul (show 68≤4*(k/8) by omega) hs
  omega

/-- Monotone row exclusion. The lower estimate uses d≥k and the upper LCM
is evaluated at the greatest difference in the entire row. -/
def cutoff (k : ℕ) := (4*(k/8)*k-(k+1))/2

def rowClear (k : ℕ) : Bool :=
  decide (U (k+k*3/2)*k.factorial < k*block (cutoff k) k)

theorem row_sound {n k d : ℕ} (hk : 0<k) (hs : k≤d) (hh : 2*d≤3*k)
    (c : rowClear k = true) : block (n+d) k≠25*block n k := by
  intro h
  have lower := uniform_bound (l:=8) (c:=2) (by decide) (by decide) h
  change 4*(k/8)*d < 2*n+k+1 at lower
  have prod := Nat.mul_le_mul_left (4*(k/8)) hs
  have hn : cutoff k ≤ n := by dsimp [cutoff];omega
  have cmp := Nat.choose_le_choose k (Nat.add_le_add_right hn k)
  have ua : U (d+k-1) ∣ U (k+k*3/2) := by
    apply Finset.lcm_dvd
    intro i hi
    exact Finset.dvd_lcm (f:=id) (mem_Icc.mpr (by have := mem_Icc.mp hi;omega))
  have upper := (upperLCM hk hs h).trans (Nat.le_of_dvd (U_pos _) ua)
  have low := Nat.mul_le_mul_left k cmp
  have raw := of_decide_eq_true c
  change U (k+k*3/2)*k.factorial < k*(cutoff k+1).ascFactorial k at raw
  rw [Nat.ascFactorial_eq_factorial_mul_choose] at raw
  have c' : U (k+k*3/2) < k*(cutoff k+k).choose k :=
    Nat.lt_of_mul_lt_mul_right (by simpa only [Nat.mul_comm,Nat.mul_assoc,Nat.mul_left_comm] using raw : U (k+k*3/2)*k.factorial < (k*(cutoff k+k).choose k)*k.factorial)
  omega

def allGaps (k : ℕ) := (List.range (k/2+1)).all (fun j => Erdos677SmallGap.bracket k (k+j) 1 25)

theorem allGaps_sound {n k d : ℕ} (hk : 0<k) (hs : k≤d) (hh : 2*d≤3*k)
    (c : allGaps k = true) : block (n+d) k≠25*block n k := by
  have test := List.all_eq_true.mp c (d-k) (List.mem_range.mpr (by omega))
  rw [Nat.add_sub_of_le hs] at test
  have hh := Erdos677SmallGap.bracket_sound test hk (by omega) (by decide) n
  simpa [P,block] using hh

end Ratio25.CloseBlocks

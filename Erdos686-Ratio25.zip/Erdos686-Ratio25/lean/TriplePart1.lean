import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem small6 : allGaps 6 = true := by decide +kernel
theorem row6 {n k d : ℕ} (ak : 6≤k) (kb : k≤6) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=6 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small6
private theorem small7 : allGaps 7 = true := by decide +kernel
theorem row7 {n k d : ℕ} (ak : 7≤k) (kb : k≤7) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=7 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small7
private theorem small8 : allGaps 8 = true := by decide +kernel
theorem row8 {n k d : ℕ} (ak : 8≤k) (kb : k≤8) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=8 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small8
private theorem small9 : allGaps 9 = true := by decide +kernel
theorem row9 {n k d : ℕ} (ak : 9≤k) (kb : k≤9) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=9 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small9
end Ratio25.TripleBlocks

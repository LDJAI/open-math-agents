import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem small14 : allGaps 14 = true := by decide +kernel
theorem row14 {n k d : ℕ} (ak : 14≤k) (kb : k≤14) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=14 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small14
private theorem small15 : allGaps 15 = true := by decide +kernel
theorem row15 {n k d : ℕ} (ak : 15≤k) (kb : k≤15) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=15 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small15
private theorem small16 : allGaps 16 = true := by decide +kernel
theorem row16 {n k d : ℕ} (ak : 16≤k) (kb : k≤16) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=16 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small16
private theorem small17 : allGaps 17 = true := by decide +kernel
theorem row17 {n k d : ℕ} (ak : 17≤k) (kb : k≤17) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=17 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small17
end Ratio25.TripleBlocks

import CloseBlocks
import Center
import SmallGap

namespace Ratio25.TripleBlocks
open Ratio25.CloseBlocks Erdos677Valuation Erdos677UpperBound Ratio25.Window Finset

theorem length_cap {n k d : ℕ} (hk : 0<k) (hs : k≤d) (hh : d≤3*k)
    (h : block (n+d) k=25*block n k) : k<1032 := by
  have hc : (n+k).choose k ≤ U (d+k-1) :=
    (Nat.le_mul_of_pos_left _ hk).trans (upperLCM hk hs h)
  have upper : (n+k).choose k ≤ 256^k := calc
    _ ≤ U (d+k-1) := hc
    _ ≤ 4^(d+k-1) := U_le_four_pow _
    _ ≤ 4^(4*k) := Nat.pow_le_pow_right (by decide) (by omega)
    _ = 256^k := by rw [pow_mul];rfl
  have b : (n+1)^k ≤ (256*k)^k := calc
    _ ≤ block n k := Nat.pow_succ_le_ascFactorial _ _
    _ = k.factorial*(n+k).choose k := Nat.ascFactorial_eq_factorial_mul_choose _ _
    _ ≤ k^k*256^k := Nat.mul_le_mul (Nat.factorial_le_pow _) upper
    _ = _ := by rw [mul_pow]; ac_rfl
  have size := (Nat.pow_le_pow_iff_left hk.ne').mp b
  have lower := uniform_bound (l:=8) (c:=2) (by decide) (by decide) h
  change 4*(k/8)*d < 2*n+k+1 at lower
  by_contra! no
  have prod := Nat.mul_le_mul (show 516≤4*(k/8) by omega) hs
  omega

def allGaps (k : ℕ) := (List.range (2*k+1)).all (fun j => Erdos677SmallGap.bracket k (k+j) 1 25)

theorem allGaps_sound {n k d : ℕ} (hk : 0<k) (hs : k≤d) (hh : d≤3*k)
    (c : allGaps k = true) : block (n+d) k≠25*block n k := by
  have test := List.all_eq_true.mp c (d-k) (List.mem_range.mpr (by omega))
  rw [Nat.add_sub_of_le hs] at test
  have hh := Erdos677SmallGap.bracket_sound test hk (by omega) (by decide) n
  simpa [P,block] using hh

end Ratio25.TripleBlocks

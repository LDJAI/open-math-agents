import Bound
import Mathlib.Data.Nat.GCD.Basic
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic

namespace Ratio25

/-- A length-three witness gives a primitive integral solution of one of
sixty cubic Thue equations, with a further square constraint. -/
theorem cubic_reduction {n m : ℕ} (hm : n<m) (he : block m 3 = 25*block n 3) :
    ∃ a b g d : ℕ, 0<b ∧ b<a ∧ 0<g ∧ a.Coprime b ∧ 0<d ∧ d∣15600 ∧
      (a^3+d = 25*b^3) ∧ (a+d*g^2 = 25*b) ∧ m+2=a*g ∧ n+2=b*g := by
  let g := (m+2).gcd (n+2)
  have hg : 0<g := Nat.gcd_pos_of_pos_left _ (by omega)
  obtain ⟨a,b,hab,ha,hb⟩ := Nat.exists_coprime (m+2) (n+2)
  change m+2=a*g at ha
  change n+2=b*g at hb
  have hbpos : 0<b := by
    by_contra! hh
    have hb0 : b=0 := by omega
    rw [hb0,Nat.zero_mul] at hb
    omega
  have hablt : b<a := by
    by_contra! hh
    have := Nat.mul_le_mul_right g hh
    omega
  have id3 (u : ℕ) : (u+2)^3=block u 3+(u+2) := by
    simp [block,Nat.ascFactorial]; ring
  have e : (a^3*g^2+25*b)*g = (25*b^3*g^2+a)*g := by
    have mm := id3 m
    have nn := id3 n
    rw [he,ha] at mm
    rw [hb] at nn
    nlinarith only [mm,nn]
  have e' := Nat.eq_of_mul_eq_mul_right hg e
  have alow : a < 25*b := by
    have bb : block (25*n+48) 3 > 25*block n 3 := by
      simp [block,Nat.ascFactorial]
      nlinarith only [Nat.zero_le n, Nat.zero_le (n^2), Nat.zero_le (n^3)]
    by_contra! hh
    have hh' := Nat.mul_le_mul_right g hh
    have : 25*n+48 ≤ m := by nlinarith only [ha,hb,hh']
    exact (not_lt_of_ge (he ▸ block_mono 3 this)) bb
  have hab3 : a^3<25*b^3 := by
    by_contra! q
    have q' := Nat.mul_le_mul_right (g^2) q
    omega
  obtain ⟨d,hd⟩ := Nat.exists_eq_add_of_le hab3.le
  have dpos : 0<d := by omega
  have eq2 : a+d*g^2=25*b := by rw [hd,Nat.add_mul] at e'; omega
  have d1 : d ∣ 15600*b^3 := by
    have hh : (25*b)^3 = (a+d*g^2)^3 := by rw [eq2]
    refine ⟨g^2*((25*b)^2+(25*b)*a+a^2)-1, ?_⟩
    have hs : 0<g^2*((25*b)^2+(25*b)*a+a^2) := by positivity
    have hdiff : (25*b)^3 = a^3 + d*(g^2*((25*b)^2+(25*b)*a+a^2)) := by
      conv_lhs => rw [← eq2]
      conv_rhs => rw [← eq2]
      ring
    rw [Nat.mul_sub, Nat.mul_one]
    have htot : d + 15600*b^3 = d*(g^2*((25*b)^2+(25*b)*a+a^2)) := by
      nlinarith only [hd,hdiff]
    omega
  have cp : d.Coprime b := by
    apply Nat.coprime_of_dvd'
    intro p pp pd pb
    have hpb : p ∣ 25*b^3 := dvd_mul_of_dvd_right (dvd_pow pb (by decide : 3≠0)) _
    have pa3 : p∣a^3 := (Nat.dvd_add_iff_left pd).mpr (hd ▸ hpb)
    exact ((Nat.not_coprime_of_dvd_of_dvd pp.one_lt (pp.dvd_of_dvd_pow pa3) pb) hab).elim
  exact ⟨a,b,g,d,hbpos,hablt,hg,hab,dpos,(cp.pow_right 3).dvd_of_dvd_mul_right d1,hd.symm,eq2,ha,hb⟩

#print axioms cubic_reduction
end Ratio25

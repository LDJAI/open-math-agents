import CloseBlocks
import Mathlib.Tactic.IntervalCases
namespace Ratio25.CloseBlocks
set_option maxRecDepth 20000
set_option maxHeartbeats 0
private theorem c2 : allGaps 2 = true := by decide +kernel
private theorem c3 : allGaps 3 = true := by decide +kernel
private theorem c4 : allGaps 4 = true := by decide +kernel
private theorem c5 : allGaps 5 = true := by decide +kernel
private theorem c6 : allGaps 6 = true := by decide +kernel
private theorem c7 : allGaps 7 = true := by decide +kernel
private theorem c8 : allGaps 8 = true := by decide +kernel
private theorem c9 : allGaps 9 = true := by decide +kernel
private theorem c10 : allGaps 10 = true := by decide +kernel
private theorem c11 : allGaps 11 = true := by decide +kernel
private theorem c12 : allGaps 12 = true := by decide +kernel
private theorem c13 : allGaps 13 = true := by decide +kernel
private theorem c14 : allGaps 14 = true := by decide +kernel
private theorem c15 : allGaps 15 = true := by decide +kernel
private theorem c16 : rowClear 16 = true := by decide +kernel
private theorem c17 : rowClear 17 = true := by decide +kernel
private theorem c18 : allGaps 18 = true := by decide +kernel
private theorem c19 : allGaps 19 = true := by decide +kernel
private theorem c20 : allGaps 20 = true := by decide +kernel
private theorem c21 : rowClear 21 = true := by decide +kernel
private theorem c22 : allGaps 22 = true := by decide +kernel
private theorem c23 : rowClear 23 = true := by decide +kernel
private theorem c24 : rowClear 24 = true := by decide +kernel
private theorem c25 : rowClear 25 = true := by decide +kernel
private theorem c26 : rowClear 26 = true := by decide +kernel
private theorem c27 : rowClear 27 = true := by decide +kernel
private theorem c28 : rowClear 28 = true := by decide +kernel
private theorem c29 : rowClear 29 = true := by decide +kernel
private theorem c30 : rowClear 30 = true := by decide +kernel
private theorem c31 : rowClear 31 = true := by decide +kernel
private theorem c32 : rowClear 32 = true := by decide +kernel
private theorem c33 : rowClear 33 = true := by decide +kernel
private theorem c34 : rowClear 34 = true := by decide +kernel
private theorem c35 : rowClear 35 = true := by decide +kernel
private theorem c36 : rowClear 36 = true := by decide +kernel
private theorem c37 : rowClear 37 = true := by decide +kernel
private theorem c38 : rowClear 38 = true := by decide +kernel
private theorem c39 : rowClear 39 = true := by decide +kernel
private theorem c40 : rowClear 40 = true := by decide +kernel
private theorem c41 : rowClear 41 = true := by decide +kernel
private theorem c42 : rowClear 42 = true := by decide +kernel
private theorem c43 : rowClear 43 = true := by decide +kernel
private theorem c44 : rowClear 44 = true := by decide +kernel
private theorem c45 : rowClear 45 = true := by decide +kernel
private theorem c46 : rowClear 46 = true := by decide +kernel
private theorem c47 : rowClear 47 = true := by decide +kernel
private theorem c48 : rowClear 48 = true := by decide +kernel
private theorem c49 : rowClear 49 = true := by decide +kernel
private theorem c50 : rowClear 50 = true := by decide +kernel
private theorem c51 : rowClear 51 = true := by decide +kernel
private theorem c52 : rowClear 52 = true := by decide +kernel
private theorem c53 : rowClear 53 = true := by decide +kernel
private theorem c54 : rowClear 54 = true := by decide +kernel
private theorem c55 : rowClear 55 = true := by decide +kernel
private theorem c56 : rowClear 56 = true := by decide +kernel
private theorem c57 : rowClear 57 = true := by decide +kernel
private theorem c58 : rowClear 58 = true := by decide +kernel
private theorem c59 : rowClear 59 = true := by decide +kernel
private theorem c60 : rowClear 60 = true := by decide +kernel
private theorem c61 : rowClear 61 = true := by decide +kernel
private theorem c62 : rowClear 62 = true := by decide +kernel
private theorem c63 : rowClear 63 = true := by decide +kernel
private theorem c64 : rowClear 64 = true := by decide +kernel
private theorem c65 : rowClear 65 = true := by decide +kernel
private theorem c66 : rowClear 66 = true := by decide +kernel
private theorem c67 : rowClear 67 = true := by decide +kernel
private theorem c68 : rowClear 68 = true := by decide +kernel
private theorem c69 : rowClear 69 = true := by decide +kernel
private theorem c70 : rowClear 70 = true := by decide +kernel
private theorem c71 : rowClear 71 = true := by decide +kernel
private theorem c72 : rowClear 72 = true := by decide +kernel
private theorem c73 : rowClear 73 = true := by decide +kernel
private theorem c74 : rowClear 74 = true := by decide +kernel
private theorem c75 : rowClear 75 = true := by decide +kernel
private theorem c76 : rowClear 76 = true := by decide +kernel
private theorem c77 : rowClear 77 = true := by decide +kernel
private theorem c78 : rowClear 78 = true := by decide +kernel
private theorem c79 : rowClear 79 = true := by decide +kernel
private theorem c80 : rowClear 80 = true := by decide +kernel
private theorem c81 : rowClear 81 = true := by decide +kernel
private theorem c82 : rowClear 82 = true := by decide +kernel
private theorem c83 : rowClear 83 = true := by decide +kernel
private theorem c84 : rowClear 84 = true := by decide +kernel
private theorem c85 : rowClear 85 = true := by decide +kernel
private theorem c86 : rowClear 86 = true := by decide +kernel
private theorem c87 : rowClear 87 = true := by decide +kernel
private theorem c88 : rowClear 88 = true := by decide +kernel
private theorem c89 : rowClear 89 = true := by decide +kernel
private theorem c90 : rowClear 90 = true := by decide +kernel
private theorem c91 : rowClear 91 = true := by decide +kernel
private theorem c92 : rowClear 92 = true := by decide +kernel
private theorem c93 : rowClear 93 = true := by decide +kernel
private theorem c94 : rowClear 94 = true := by decide +kernel
private theorem c95 : rowClear 95 = true := by decide +kernel
private theorem c96 : rowClear 96 = true := by decide +kernel
private theorem c97 : rowClear 97 = true := by decide +kernel
private theorem c98 : rowClear 98 = true := by decide +kernel
private theorem c99 : rowClear 99 = true := by decide +kernel
private theorem c100 : rowClear 100 = true := by decide +kernel
private theorem c101 : rowClear 101 = true := by decide +kernel
private theorem c102 : rowClear 102 = true := by decide +kernel
private theorem c103 : rowClear 103 = true := by decide +kernel
private theorem c104 : rowClear 104 = true := by decide +kernel
private theorem c105 : rowClear 105 = true := by decide +kernel
private theorem c106 : rowClear 106 = true := by decide +kernel
private theorem c107 : rowClear 107 = true := by decide +kernel
private theorem c108 : rowClear 108 = true := by decide +kernel
private theorem c109 : rowClear 109 = true := by decide +kernel
private theorem c110 : rowClear 110 = true := by decide +kernel
private theorem c111 : rowClear 111 = true := by decide +kernel
private theorem c112 : rowClear 112 = true := by decide +kernel
private theorem c113 : rowClear 113 = true := by decide +kernel
private theorem c114 : rowClear 114 = true := by decide +kernel
private theorem c115 : rowClear 115 = true := by decide +kernel
private theorem c116 : rowClear 116 = true := by decide +kernel
private theorem c117 : rowClear 117 = true := by decide +kernel
private theorem c118 : rowClear 118 = true := by decide +kernel
private theorem c119 : rowClear 119 = true := by decide +kernel
private theorem c120 : rowClear 120 = true := by decide +kernel
private theorem c121 : rowClear 121 = true := by decide +kernel
private theorem c122 : rowClear 122 = true := by decide +kernel
private theorem c123 : rowClear 123 = true := by decide +kernel
private theorem c124 : rowClear 124 = true := by decide +kernel
private theorem c125 : rowClear 125 = true := by decide +kernel
private theorem c126 : rowClear 126 = true := by decide +kernel
private theorem c127 : rowClear 127 = true := by decide +kernel
private theorem c128 : rowClear 128 = true := by decide +kernel
private theorem c129 : rowClear 129 = true := by decide +kernel
private theorem c130 : rowClear 130 = true := by decide +kernel
private theorem c131 : rowClear 131 = true := by decide +kernel
private theorem c132 : rowClear 132 = true := by decide +kernel
private theorem c133 : rowClear 133 = true := by decide +kernel
private theorem c134 : rowClear 134 = true := by decide +kernel
private theorem c135 : rowClear 135 = true := by decide +kernel
private theorem range2 {n k d : ℕ} (hk : 2≤k) (hk2 : k<10) (hs : k≤d) (hh : 2*d≤3*k) : block (n+d) k≠25*block n k := by
  interval_cases k
  · exact allGaps_sound (by decide) hs hh c2
  · exact allGaps_sound (by decide) hs hh c3
  · exact allGaps_sound (by decide) hs hh c4
  · exact allGaps_sound (by decide) hs hh c5
  · exact allGaps_sound (by decide) hs hh c6
  · exact allGaps_sound (by decide) hs hh c7
  · exact allGaps_sound (by decide) hs hh c8
  · exact allGaps_sound (by decide) hs hh c9
private theorem range10 {n k d : ℕ} (hk : 10≤k) (hk2 : k<18) (hs : k≤d) (hh : 2*d≤3*k) : block (n+d) k≠25*block n k := by
  interval_cases k
  · exact allGaps_sound (by decide) hs hh c10
  · exact allGaps_sound (by decide) hs hh c11
  · exact allGaps_sound (by decide) hs hh c12
  · exact allGaps_sound (by decide) hs hh c13
  · exact allGaps_sound (by decide) hs hh c14
  · exact allGaps_sound (by decide) hs hh c15
  · exact row_sound (by decide) hs hh c16
  · exact row_sound (by decide) hs hh c17
private theorem range18 {n k d : ℕ} (hk : 18≤k) (hk2 : k<26) (hs : k≤d) (hh : 2*d≤3*k) : block (n+d) k≠25*block n k := by
  interval_cases k
  · exact allGaps_sound (by decide) hs hh c18
  · exact allGaps_sound (by decide) hs hh c19
  · exact allGaps_sound (by decide) hs hh c20
  · exact row_sound (by decide) hs hh c21
  · exact allGaps_sound (by decide) hs hh c22
  · exact row_sound (by decide) hs hh c23
  · exact row_sound (by decide) hs hh c24
  · exact row_sound (by decide) hs hh c25
private theorem range26 {n k d : ℕ} (hk : 26≤k) (hk2 : k<34) (hs : k≤d) (hh : 2*d≤3*k) : block (n+d) k≠25*block n k := by
  interval_cases k
  · exact row_sound (by decide) hs hh c26
  · exact row_sound (by decide) hs hh c27
  · exact row_sound (by decide) hs hh c28
  · exact row_sound (by decide) hs hh c29
  · exact row_sound (by decide) hs hh c30
  · exact row_sound (by decide) hs hh c31
  · exact row_sound (by decide) hs hh c32
  · exact row_sound (by decide) hs hh c33
private theorem range34 {n k d : ℕ} (hk : 34≤k) (hk2 : k<42) (hs : k≤d) (hh : 2*d≤3*k) : block (n+d) k≠25*block n k := by
  interval_cases k
  · exact row_sound (by decide) hs hh c34
  · exact row_sound (by decide) hs hh c35
  · exact row_sound (by decide) hs hh c36
  · exact row_sound (by decide) hs hh c37
  · exact row_sound (by decide) hs hh c38
  · exact row_sound (by decide) hs hh c39
  · exact row_sound (by decide) hs hh c40
  · exact row_sound (by decide) hs hh c41
private theorem range42 {n k d : ℕ} (hk : 42≤k) (hk2 : k<50) (hs : k≤d) (hh : 2*d≤3*k) : block (n+d) k≠25*block n k := by
  interval_cases k
  · exact row_sound (by decide) hs hh c42
  · exact row_sound (by decide) hs hh c43
  · exact row_sound (by decide) hs hh c44
  · exact row_sound (by decide) hs hh c45
  · exact row_sound (by decide) hs hh c46
  · exact row_sound (by decide) hs hh c47
  · exact row_sound (by decide) hs hh c48
  · exact row_sound (by decide) hs hh c49
private theorem range50 {n k d : ℕ} (hk : 50≤k) (hk2 : k<58) (hs : k≤d) (hh : 2*d≤3*k) : block (n+d) k≠25*block n k := by
  interval_cases k
  · exact row_sound (by decide) hs hh c50
  · exact row_sound (by decide) hs hh c51
  · exact row_sound (by decide) hs hh c52
  · exact row_sound (by decide) hs hh c53
  · exact row_sound (by decide) hs hh c54
  · exact row_sound (by decide) hs hh c55
  · exact row_sound (by decide) hs hh c56
  · exact row_sound (by decide) hs hh c57
private theorem range58 {n k d : ℕ} (hk : 58≤k) (hk2 : k<66) (hs : k≤d) (hh : 2*d≤3*k) : block (n+d) k≠25*block n k := by
  interval_cases k
  · exact row_sound (by decide) hs hh c58
  · exact row_sound (by decide) hs hh c59
  · exact row_sound (by decide) hs hh c60
  · exact row_sound (by decide) hs hh c61
  · exact row_sound (by decide) hs hh c62
  · exact row_sound (by decide) hs hh c63
  · exact row_sound (by decide) hs hh c64
  · exact row_sound (by decide) hs hh c65
private theorem range66 {n k d : ℕ} (hk : 66≤k) (hk2 : k<74) (hs : k≤d) (hh : 2*d≤3*k) : block (n+d) k≠25*block n k := by
  interval_cases k
  · exact row_sound (by decide) hs hh c66
  · exact row_sound (by decide) hs hh c67
  · exact row_sound (by decide) hs hh c68
  · exact row_sound (by decide) hs hh c69
  · exact row_sound (by decide) hs hh c70
  · exact row_sound (by decide) hs hh c71
  · exact row_sound (by decide) hs hh c72
  · exact row_sound (by decide) hs hh c73
private theorem range74 {n k d : ℕ} (hk : 74≤k) (hk2 : k<82) (hs : k≤d) (hh : 2*d≤3*k) : block (n+d) k≠25*block n k := by
  interval_cases k
  · exact row_sound (by decide) hs hh c74
  · exact row_sound (by decide) hs hh c75
  · exact row_sound (by decide) hs hh c76
  · exact row_sound (by decide) hs hh c77
  · exact row_sound (by decide) hs hh c78
  · exact row_sound (by decide) hs hh c79
  · exact row_sound (by decide) hs hh c80
  · exact row_sound (by decide) hs hh c81
private theorem range82 {n k d : ℕ} (hk : 82≤k) (hk2 : k<90) (hs : k≤d) (hh : 2*d≤3*k) : block (n+d) k≠25*block n k := by
  interval_cases k
  · exact row_sound (by decide) hs hh c82
  · exact row_sound (by decide) hs hh c83
  · exact row_sound (by decide) hs hh c84
  · exact row_sound (by decide) hs hh c85
  · exact row_sound (by decide) hs hh c86
  · exact row_sound (by decide) hs hh c87
  · exact row_sound (by decide) hs hh c88
  · exact row_sound (by decide) hs hh c89
private theorem range90 {n k d : ℕ} (hk : 90≤k) (hk2 : k<98) (hs : k≤d) (hh : 2*d≤3*k) : block (n+d) k≠25*block n k := by
  interval_cases k
  · exact row_sound (by decide) hs hh c90
  · exact row_sound (by decide) hs hh c91
  · exact row_sound (by decide) hs hh c92
  · exact row_sound (by decide) hs hh c93
  · exact row_sound (by decide) hs hh c94
  · exact row_sound (by decide) hs hh c95
  · exact row_sound (by decide) hs hh c96
  · exact row_sound (by decide) hs hh c97
private theorem range98 {n k d : ℕ} (hk : 98≤k) (hk2 : k<106) (hs : k≤d) (hh : 2*d≤3*k) : block (n+d) k≠25*block n k := by
  interval_cases k
  · exact row_sound (by decide) hs hh c98
  · exact row_sound (by decide) hs hh c99
  · exact row_sound (by decide) hs hh c100
  · exact row_sound (by decide) hs hh c101
  · exact row_sound (by decide) hs hh c102
  · exact row_sound (by decide) hs hh c103
  · exact row_sound (by decide) hs hh c104
  · exact row_sound (by decide) hs hh c105
private theorem range106 {n k d : ℕ} (hk : 106≤k) (hk2 : k<114) (hs : k≤d) (hh : 2*d≤3*k) : block (n+d) k≠25*block n k := by
  interval_cases k
  · exact row_sound (by decide) hs hh c106
  · exact row_sound (by decide) hs hh c107
  · exact row_sound (by decide) hs hh c108
  · exact row_sound (by decide) hs hh c109
  · exact row_sound (by decide) hs hh c110
  · exact row_sound (by decide) hs hh c111
  · exact row_sound (by decide) hs hh c112
  · exact row_sound (by decide) hs hh c113
private theorem range114 {n k d : ℕ} (hk : 114≤k) (hk2 : k<122) (hs : k≤d) (hh : 2*d≤3*k) : block (n+d) k≠25*block n k := by
  interval_cases k
  · exact row_sound (by decide) hs hh c114
  · exact row_sound (by decide) hs hh c115
  · exact row_sound (by decide) hs hh c116
  · exact row_sound (by decide) hs hh c117
  · exact row_sound (by decide) hs hh c118
  · exact row_sound (by decide) hs hh c119
  · exact row_sound (by decide) hs hh c120
  · exact row_sound (by decide) hs hh c121
private theorem range122 {n k d : ℕ} (hk : 122≤k) (hk2 : k<130) (hs : k≤d) (hh : 2*d≤3*k) : block (n+d) k≠25*block n k := by
  interval_cases k
  · exact row_sound (by decide) hs hh c122
  · exact row_sound (by decide) hs hh c123
  · exact row_sound (by decide) hs hh c124
  · exact row_sound (by decide) hs hh c125
  · exact row_sound (by decide) hs hh c126
  · exact row_sound (by decide) hs hh c127
  · exact row_sound (by decide) hs hh c128
  · exact row_sound (by decide) hs hh c129
private theorem range130 {n k d : ℕ} (hk : 130≤k) (hk2 : k<136) (hs : k≤d) (hh : 2*d≤3*k) : block (n+d) k≠25*block n k := by
  interval_cases k
  · exact row_sound (by decide) hs hh c130
  · exact row_sound (by decide) hs hh c131
  · exact row_sound (by decide) hs hh c132
  · exact row_sound (by decide) hs hh c133
  · exact row_sound (by decide) hs hh c134
  · exact row_sound (by decide) hs hh c135
theorem short_separation {n m k : ℕ} (hk : 2≤k) (hs : n+k≤m) (hh : 2*(m-n)≤3*k) :
    (25:ℚ) ≠ (∏ i ∈ Finset.Icc 1 k, (m+i)) / (∏ i ∈ Finset.Icc 1 k, (n+i)) := by
  intro ee
  have eq := (ratio_iff n m k).mp ee
  obtain ⟨d, rfl⟩ := Nat.exists_eq_add_of_le (show n≤m by omega)
  rw [Nat.add_sub_cancel_left] at hh
  have hkd : k≤d := by omega
  have cap := length_cap (by omega : 0<k) hkd hh eq
  by_cases h2 : k<10
  · exact range2 (by omega) h2 hkd hh eq
  by_cases h10 : k<18
  · exact range10 (by omega) h10 hkd hh eq
  by_cases h18 : k<26
  · exact range18 (by omega) h18 hkd hh eq
  by_cases h26 : k<34
  · exact range26 (by omega) h26 hkd hh eq
  by_cases h34 : k<42
  · exact range34 (by omega) h34 hkd hh eq
  by_cases h42 : k<50
  · exact range42 (by omega) h42 hkd hh eq
  by_cases h50 : k<58
  · exact range50 (by omega) h50 hkd hh eq
  by_cases h58 : k<66
  · exact range58 (by omega) h58 hkd hh eq
  by_cases h66 : k<74
  · exact range66 (by omega) h66 hkd hh eq
  by_cases h74 : k<82
  · exact range74 (by omega) h74 hkd hh eq
  by_cases h82 : k<90
  · exact range82 (by omega) h82 hkd hh eq
  by_cases h90 : k<98
  · exact range90 (by omega) h90 hkd hh eq
  by_cases h98 : k<106
  · exact range98 (by omega) h98 hkd hh eq
  by_cases h106 : k<114
  · exact range106 (by omega) h106 hkd hh eq
  by_cases h114 : k<122
  · exact range114 (by omega) h114 hkd hh eq
  by_cases h122 : k<130
  · exact range122 (by omega) h122 hkd hh eq
  exact range130 (by omega) cap hkd hh eq
#print axioms short_separation
end Ratio25.CloseBlocks

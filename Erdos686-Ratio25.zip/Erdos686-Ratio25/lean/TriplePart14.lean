import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem cell58_0 {n k d : ℕ} (ak : 58≤k) (kb : k≤58) (sd : k≤d) (lo : 58≤d) (hi : d≤165) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=58) (b:=58) (f:=58) (s:=222) (U':=71168947243747441838927276793711536968235214767668176422286721624536377810802929304135312000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell58_1 {n k d : ℕ} (ak : 58≤k) (kb : k≤58) (sd : k≤d) (lo : 166≤d) (hi : d≤174) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=58) (b:=58) (f:=166) (s:=231) (U':=825005310759494289012189328393554022247008970746695943736019934996445219685790014305761100984208000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row58 {n k d : ℕ} (ak : 58≤k) (kb : k≤58) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤165
  · exact cell58_0 ak kb sd (by omega) c0
  exact cell58_1 ak kb sd (by omega) (by omega)
private theorem cell59_0 {n k d : ℕ} (ak : 59≤k) (kb : k≤59) (sd : k≤d) (lo : 59≤d) (hi : d≤164) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=59) (b:=59) (f:=59) (s:=222) (U':=71168947243747441838927276793711536968235214767668176422286721624536377810802929304135312000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell59_1 {n k d : ℕ} (ak : 59≤k) (kb : k≤59) (sd : k≤d) (lo : 165≤d) (hi : d≤177) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=59) (b:=59) (f:=165) (s:=235) (U':=192226237406962169339840113515698087183553090183980154890492644854171736186789073333242336529320464000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row59 {n k d : ℕ} (ak : 59≤k) (kb : k≤59) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤164
  · exact cell59_0 ak kb sd (by omega) c0
  exact cell59_1 ak kb sd (by omega) (by omega)
private theorem cell60_0 {n k d : ℕ} (ak : 60≤k) (kb : k≤60) (sd : k≤d) (lo : 60≤d) (hi : d≤167) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=60) (b:=60) (f:=60) (s:=226) (U':=15870675235355679530080782724997672743916452893190003342169938922271612251809053234822174576000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell60_1 {n k d : ℕ} (ak : 60≤k) (kb : k≤60) (sd : k≤d) (lo : 168≤d) (hi : d≤180) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=60) (b:=60) (f:=168) (s:=239) (U':=45942070740263958472221787130251842836869188553971257018827742120147044948642588526644918430507590896000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row60 {n k d : ℕ} (ak : 60≤k) (kb : k≤60) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤167
  · exact cell60_0 ak kb sd (by omega) c0
  exact cell60_1 ak kb sd (by omega) (by omega)
private theorem cell61_0 {n k d : ℕ} (ak : 61≤k) (kb : k≤61) (sd : k≤d) (lo : 61≤d) (hi : d≤168) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=61) (b:=61) (f:=61) (s:=228) (U':=3602643278425739253328337678574471712869034806754130758672576135355655981160655084304633628752000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
private theorem cell61_1 {n k d : ℕ} (ak : 61≤k) (kb : k≤61) (sd : k≤d) (lo : 169≤d) (hi : d≤183) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=61) (b:=61) (f:=169) (s:=243) (U':=33216117145210841975416352095172082371056423324521218824612457552866313497868591504764276025256988217808000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row61 {n k d : ℕ} (ak : 61≤k) (kb : k≤61) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  by_cases c0 : d≤168
  · exact cell61_0 ak kb sd (by omega) c0
  exact cell61_1 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

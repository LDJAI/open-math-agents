import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem cell155_0 {n k d : ℕ} (ak : 155≤k) (kb : k≤181) (sd : k≤d) (lo : 155≤d) (hi : d≤543) : block (n+d) k≠25*block n k := by
  apply Rect.exclude (a:=155) (b:=181) (f:=155) (s:=723) (U':=1339025580487488400628371874750212003481946172485388265762202772716928373275878997237571909715322656366872336142398229974721617691127058633833416998833423625681334928166428093462246753064255331087309188329874428925109059210313845525455321886929348500728485687333901791479507738245398934429797898106561465305280000) (by decide) ak kb lo sd (by omega) (by decide)
  · apply Rect.common
    decide +kernel
  · decide +kernel
theorem row155 {n k d : ℕ} (ak : 155≤k) (kb : k≤181) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  exact cell155_0 ak kb sd (by omega) (by omega)
end Ratio25.TripleBlocks

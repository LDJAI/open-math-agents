import Rect
import TripleBlocks
namespace Ratio25.TripleBlocks
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private theorem small18 : allGaps 18 = true := by decide +kernel
theorem row18 {n k d : ℕ} (ak : 18≤k) (kb : k≤18) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=18 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small18
private theorem small19 : allGaps 19 = true := by decide +kernel
theorem row19 {n k d : ℕ} (ak : 19≤k) (kb : k≤19) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=19 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small19
private theorem small20 : allGaps 20 = true := by decide +kernel
theorem row20 {n k d : ℕ} (ak : 20≤k) (kb : k≤20) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=20 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small20
private theorem small21 : allGaps 21 = true := by decide +kernel
theorem row21 {n k d : ℕ} (ak : 21≤k) (kb : k≤21) (sd : k≤d) (gap : d≤3*k) : block (n+d) k≠25*block n k := by
  have h : k=21 := by omega
  subst k
  exact allGaps_sound (by decide) sd gap small21
end Ratio25.TripleBlocks

import CloseBlocks
namespace Ratio25.Rect
open Erdos677Valuation Erdos677UpperBound Ratio25.CloseBlocks Ratio25.Window Finset

/-- A supplied positive common multiple certifies the window LCM upper bound. -/
theorem common {s U' : ℕ}
    (h : (List.range s).all (fun j => decide (U' % (j+1) = 0)) = true) : U s ∣ U' := by
  apply Finset.lcm_dvd
  intro i hi
  obtain ⟨lo,up⟩ := mem_Icc.mp hi
  have hs := List.all_eq_true.mp h (i-1) (List.mem_range.mpr (by omega))
  have eq : i-1+1=i := by omega
  exact Nat.dvd_of_mod_eq_zero (by simpa [eq] using hs)

def floorStart (a b f : ℕ) := (4*(a/8)*f-(b+1))/2

theorem exclude {a b f s U' k n d : ℕ} (ha : 0<a) (ak : a≤k) (kb : k≤b)
    (fd : f≤d) (hs : k≤d) (ts : d+k-1≤s) (pos : 0<U') (com : U s ∣ U')
    (test : U'*a.factorial < a*block (floorStart a b f) a) :
    block (n+d) k ≠ 25*block n k := by
  intro h
  have hwin := upperLCM (by omega) hs h
  have lp := uniform_bound (l:=8) (c:=2) (by decide) (by decide) h
  change 4*(k/8)*d < 2*n+k+1 at lp
  have lower : 4*(a/8)*f ≤ 4*(k/8)*d := Nat.mul_le_mul (Nat.mul_le_mul_left 4 (Nat.div_le_div_right ak)) fd
  have hn : floorStart a b f ≤ n := by dsimp [floorStart];omega
  have ub : U (d+k-1) ∣ U s := by
    apply Finset.lcm_dvd
    intro i hi
    exact Finset.dvd_lcm (f:=id) (mem_Icc.mpr (by have := mem_Icc.mp hi;omega))
  have hup := hwin.trans (Nat.le_of_dvd pos (ub.trans com))
  have cm1 := Nat.choose_le_choose a (Nat.add_le_add_right hn a)
  have cm2 : (n+a).choose a ≤ (n+k).choose k := by
    rw [← Nat.choose_symm_add (a:=n) (b:=a), ← Nat.choose_symm_add (a:=n) (b:=k)]
    exact Nat.choose_le_choose n (Nat.add_le_add_left ak n)
  have lb := Nat.mul_le_mul ak (cm1.trans cm2)
  change U'*a.factorial < a*(floorStart a b f+1).ascFactorial a at test
  rw [Nat.ascFactorial_eq_factorial_mul_choose] at test
  have test' : U' < a*(floorStart a b f+a).choose a :=
    Nat.lt_of_mul_lt_mul_right (by simpa only [Nat.mul_comm,Nat.mul_assoc,Nat.mul_left_comm] using test : U'*a.factorial < (a*(floorStart a b f+a).choose a)*a.factorial)
  omega
end Ratio25.Rect

# A necessary separation for ratio 25

Let P(n,k) be the product of n+1 through n+k, let d=m-n, and suppose k≥2 and d≥k. This argument rules out every witness with d≤25k. It also gives d>k²/280 whenever k≥10000. The finite part of the first result is computer-assisted.

## The common divisor

If P(n+d,k)=25P(n,k), cancellation of k! gives the same identity for the corresponding binomial coefficients. As in the work on Erdős 677, k times the binomial coefficient divides the least common multiple of the block. Consequently
\[
B=k\binom{n+k}{k}
\]
divides the LCM of each block. Every prime power of B occurs in some integer of each block. The difference of those integers lies between d-k+1 and d+k-1, both endpoints included. Thus B divides
\[
L=\operatorname{lcm}(d-k+1,\ldots,d+k-1).
\]

Write w=2k-1, T=d+k-1, and U(w)=lcm(1,...,w). For any prime p whose maximum exponent in L is e, every p-power p^i with log_p(w)<i≤e occurs in the difference interval. Each such level contributes 1 to the valuation of the binomial coefficient binom(T,w), by Legendre's formula for factorials. The lower powers are covered by U(w). This proves
\[
L\mid U(w)\binom{T}{w}.
\]
The existing elementary estimates U(w)≤4^w and w^w≤4^w w! now give L≤(16T/w)^w.

If a positive integer A satisfies 16T≤Aw, then (n+1)^k≤P(n,k)=k! binom(n+k,k)≤k^k A^w. In particular
\[
n+1\le k A^2.
\]

## The lower bound from the centered product

For x=2n+k+1, the function P(n,k)/x^k increases with n. Indeed, each symmetric pair of factors divided by x² contributes a fixed positive constant times 1-c²/x². The unmatched central factor at odd lengths contributes a constant. Thus (1+2d/x)^k≤25 at a witness.

If positive integers c,l satisfy (1+1/c)^l>25, Bernoulli's inequality gives 2c floor(k/l)d < x. Otherwise (1+2d/x)^floor(k/l)≥1+1/c, and raising both sides to l contradicts the upper bound. The choices (l,c)=(8,2) and (256,79) are both valid by exact integer exponentiation. The general inequality and the latter specialization are proved in Center.lean.

## The infinite tail

Suppose k≥10000 and k≤d≤25k. Put j=floor(d/k), between 1 and 25. Then 16T≤10(j+2)w, since d<(j+1)k and 5(2k-1)≥8k. Also (j+2)^2≤30j in this range. The upper bound just proved gives
\[
n+1\le 100k(j+2)^2\le3000d.
\]
The centered lower bound gives 6162d≤158 floor(k/256)d <2n+k+1, since floor(k/256)≥39. But 2n+k+1≤6000d+k-1≤6001d. This contradiction excludes the entire tail.

For the quadratic refinement, a witness at k≥10000 must already have d>25k, so j=floor(d/k)≥25. Here 16T≤9j(2k-1). Indeed, 16T≤16(j+2)k and (2j-32)k≥9j when j≥25 and k≥10000. Thus (n+1)k≤81(jk)^2≤81d². The bound 3k≤790 floor(k/256) follows from floor(k/256)≥(k-255)/256 and k≥10000. Combining it with 158 floor(k/256)d<2n+k+1 and d≥50 gives 29kd<100(n+1). Hence 29k²d<8100d², and k²<280d.

## The finite rectangle

For 2≤k≤9999 there are exactly 1,199,889,974 eligible pairs (k,d). The generator covers their integer lattice points with disjoint cells. Within a cell a≤k≤b and f≤d≤g, the centered lower bound implies n≥max(0,floor((4 floor(a/8) f-b-1)/2)). Denote the latter bound by N.

Two lower bounds for B are a binom(N+a,a) and (1+floor(N/b))^a. The second follows by multiplying the inequalities (n+i)/i≥1+floor(N/b) for i=1,...,k. Compare them to the exact LCM of the larger interval max(1,f-b+1) through g+b-1. Alternatively the preceding analytic bound is at most ceil(16(g+b-1)/(2a-1))^(2b-1). A strict comparison proves that the whole cell is empty.

For 536,747 remaining pairs the verifier checks the sign of binom(n+d+k,k)-25 binom(n+k,k). At fixed k,d the quotient is strictly decreasing in n because each positive factor 1+d/(n+i) is strictly decreasing. Five pairs were already below 25 at n=0. For each other pair, two consecutive starts gave opposite strict signs. This rules out every integer n. The primary generator uses a floating-point estimate only to locate a candidate crossing. All decisions are exact. A second C++ verifier reads the saved certificate, checks every sign using GMP, computes each LCM from prime powers, and checks that the covered intervals partition every row without omissions or overlap.

## Prime gaps

For k≥3, the Lean theorem gap_prime_power in Transfer.lean proves (p^e)^2<25(k-1)d whenever p>k and p^e divides d. If d itself is such a prime power, this implies d<25k, already excluded. A prime gap equal to k is also covered by the short-gap argument. The separate Lean proof excludes k=2 for all gaps. It follows that the gap cannot be prime for any length.

The proof in `ThreeFactors.lean` also rules out gaps equal to twice or three times a prime once the finite certificate is applied. More generally, suppose \(d=q t\), where \(1\le t\le3\) and \(q=p^e\) has prime base \(p>k\). Assume \(d>25k\). As in the prime-gap proof, one lower-block entry is \(q u=n+1+i\), with \(0\le i<k\). If \(n+1\ge kq\), each ratio of corresponding entries is at most \(1+3/k\), giving \(25\le(1+3/k)^k\le e^3<25\). Therefore \(n+1<kq\), and \(u\le k\) since \(q>k\). The squared divisibility in the diagonal transport implies \(q^2\mid 24qu-d\), so \(q\mid24u-t\). Since \(t\mid24\) and \(t\) is coprime to \(q\), the full gap \(qt\) divides the positive integer \(24u-t<25k\). This is impossible. For \(q=p\) with \(p\le k\), the gap is already at most \(3k\).

## Kernel verification and the fixed-cofactor family

For gaps up to three times the length, every step runs in the Lean kernel. The upper LCM bound is at most \(4^{4k}=256^k\), so \(n+1\le256k\). The centered lower bound gives \(k<1032\). For that finite range Lean verifies exact common multiples of the difference windows and binomial lower bounds for whole ranges of lengths and gaps. For small lengths it checks strict product crossings. The final rational-quotient statement is `Ratio25.TripleBlocks.short_separation`.

This gives \(k^2<3333d\) at every length. For \(k<10000\), use \(k\le9999\) and \(3k<d\). For larger lengths use \(k^2<280d\). For a prime factor \(p\) of the gap we have \(p^2<25kd\). If \(p>k\) this follows from the prime-power result, and if \(p\le k\) it follows from \(p\le d\). Length two is already excluded.

Squaring and substituting the length bound gives \(p^4<625\cdot3333d^3\). Hence for \(d=pt\), canceling \(p^3\) gives \(d<2083125t^4\). Taking \(A=32d\) in the earlier height inequality gives \(n+1\le1024d^3\). The theorem `finite_prime_family` proves the equivalence with an explicitly bounded search in all four unknowns. Combining the separately certified \(25k<d\) with \(k^2<280d\) for large lengths gives \(k^2<400d\) uniformly and improves the quartic coefficient to 250,000.

## Reproduction

From the numerics directory, run the following commands. The checker does not rely on the generator's choice of cells or floating-point estimates.

```sh
python window_boxes.py 2 9999
g++ -O3 -std=c++17 replay_windows.cpp -lgmpxx -lgmp -o replay-windows
gzip -dc window-certificate.txt.gz | ./replay-windows
```

To regenerate the certificate, run `python export_windows.py 2 9999`. The coverage statement leaves the unbounded domain d>25k open.

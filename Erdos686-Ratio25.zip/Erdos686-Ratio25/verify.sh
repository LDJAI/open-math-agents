#!/usr/bin/env bash
set -eu
root=$(cd "$(dirname "$0")" && pwd)
mathlib=$(cd "${1:?Pass the path to a built checkout of mathlib}" && pwd)
objects=$(mktemp -d)
trap 'rm -rf "$objects"' EXIT
cd "$mathlib"
lake env bash -eu -c '
  root=$1
  objects=$2
  export LEAN_PATH="$objects:$LEAN_PATH"
  for name in $(cat "$root/modules.txt"); do
    echo "Checking $name"
    lean -j1 -M3500 -R "$root/lean" -o "$objects/$name.olean" "$root/lean/$name.lean"
  done
' verify "$root" "$objects"

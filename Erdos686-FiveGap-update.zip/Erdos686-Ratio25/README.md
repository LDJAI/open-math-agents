# Erdős 686, the ratio 25

The open question asks whether there are natural numbers \(k\ge2\), \(n\ge0\), and \(m\ge n+k\) with \(P(m,k)=25P(n,k)\), where \(P(n,k)=(n+1)\cdots(n+k)\). LeftToSolve uses the equivalent quotient in the rationals. The full existence question remains open.

## Results

* At length five, deleting any two prime powers from the gap leaves a cofactor greater than one decillion. At every fixed cofactor the entire remaining family admits an explicit finite search. Both results are fully proved in Lean. See [the quintic proof](FIVE-GAP.md).

* Any pair with ratio 25 must have a gap between the two starts greater than 25 times the block length. In particular, the gap cannot be a prime, twice a prime, or three times a prime. These statements apply at every length and every starting point. Lean proves the LCM divisibility, the implication for all three prime families, and the entire infinite tail. For the remaining 1,199,889,974 length-gap pairs, two exact integer implementations checked a finite certificate. The smaller exclusion for gaps at most three times the length is entirely kernel-checked in `TripleResult.lean`. See [the separation proof](WINDOW.md).
* At lengths of 10,000 or more, Lean proves that 280 times the gap exceeds the square of the length. The formal theorem is `Ratio25.Window.quadratic_gap`.
* For every fixed positive integer cofactor \(t\), Lean reduces the entire subfamily with gap \(d=pt\), for a prime \(p\), to a finite search. The kernel proves \(d<2083125t^4\), \(k\le d\), and \(n+1\le1024d^3\). With the independently replayed separation \(d>25k\), the first bound improves to \(d<250000t^4\). See `lean/CofactorBounds.lean`.
* At length 5, Lean proves that the lower start parameter exceeds a one followed by 160 zeros for any witness. It also rules out all gaps of the form \(p^e t\) with \(p\) prime and the cofactor \(t\) at most a one followed by 75 zeros, regardless of the size of the gap. These are `Ratio25.Five.height` and `Ratio25.Five.certified_cofactor` in `FiveResult.lean`. The proof uses the interval certificates and the bound \(d<796262400t^2\).
* Lean proves the exclusion for every even length from 2 through 24, for arbitrarily large starts. The combined theorem is in `lean/Results.lean`. The six cases in `lean/SmallCases.lean` and the six individual `lean/Length*.lean` modules cover these lengths. The theorem `ratio_iff` in `lean/Finite.lean` converts their product statement into the rational quotient used by the site.
* A second, computational argument covers all 50 even lengths from 2 through 100, with arbitrarily large starts. Each length has a proved finite-search criterion. Exact integer arithmetic checks the coefficients and the remaining bounded range. The supplied cutoffs are all below a one followed by 105 zeros. The C++ search covers each required cutoff.
* Lean reduces length 3 to 60 cubic Thue equations. PARI/GP 2.17.2, run in unconditional mode, enumerates every integral solution to all 60. None gives a valid block pair. The enumeration is external to Lean.
* For lengths from 3 through 100, the bounded C++ search found no disjoint witness with lower start at most a one followed by 160 zeros. This includes the odd lengths. The two logs account for 2,048,036 candidate fractions and 317,412 exact large-center product tests. Small centers are tested separately by monotone enumeration.
* The transfer from Erdős 677 also yields a restriction at unbounded lengths. If \(d=m-n\), \(k\ge3\), and a prime power \(p^e\mid d\) has \(p>k\), any witness must satisfy \((p^e)^2<25(k-1)d\). See `lean/Transfer.lean`.
* The first remaining odd length is 5. `lean/Quintic.lean` verifies a necessary sextic square identity. It leaves a Diophantine problem on a genus-two curve. A bounded PARI search on the curve is included for reproducibility.

## Why even lengths admit a finite test

Fix \(k=2r\) and let \(P(X)=\prod_{i=1}^k (X+i)\). Take the polynomial part of the Laurent expansion of \(\sqrt{P(X)}\) at positive infinity. Clearing its coefficient denominators gives an integer polynomial \(H\) and a positive integer \(D\) such that \(H^2-D^2P\) has degree less than \(r\). The remainder is nonzero because \(P\) has distinct simple roots. Choose its sign so that the resulting polynomial \(R\) has positive leading coefficient.

Above the cutoff \(T\), the coefficient checks certify
\[
0<6H-1,\qquad (6H-1)^2<36D^2P<(6H+1)^2.
\]
If \(P(m)=25P(n)\) and \(m>n\ge T\), applying these inequalities at both starts forces the integer identity \(H(m)=5H(n)\). Substitution gives \(R(m)=25R(n)\). A final positive-polynomial check proves
\[
(n+k+1)R(n)>(n+1)R(n+1).
\]
The identity \((n+1)P(n+1)=(n+k+1)P(n)\) now shows that \(R(n)/P(n)\) is strictly decreasing, a contradiction.

These checks eventually succeed for every fixed even length. The two differences in the square inequalities have positive leading term from \(12H\), since the remainder has lower degree. The last difference has leading coefficient \((k-\deg R)\operatorname{lc}(R)>0\). Translating a polynomial sufficiently far to the right makes every coefficient nonnegative and its constant coefficient positive. This constructs a computable cutoff for each even length. A uniform exclusion over all even lengths would require an additional argument.

The proof for the finite range uses the centered-product search from problem 677. For selected lengths there is a separate, exclusively integer verification. On a range of lower starts it bounds the integer \(qm-pn\) between two integers and exhausts the intervening values. Each value leads to a single polynomial in \(n\). Signed polynomial bounds on subintervals rule out integral zeros. Lean checks the same argument in `Strips.lean`. The small-start checker takes disjointness into account. At length 24, starting the blocks at 1 and 2 gives an overlapping ratio of 25, so an unconditional exclusion for all overlapping starts would be false.

## The length-three calculation

Write \(m+2=ga\) and \(n+2=gb\) in lowest terms, with \(a>b>0\). Since \(P(n,3)=(n+2)^3-(n+2)\), a witness would satisfy
\[
d=25b^3-a^3>0,\qquad dg^2=25b-a.
\]
Reducing cubes modulo \(d\) gives \(d\mid15600b^3\), and \(\gcd(d,b)=1\), so \(d\mid15600\). PARI returns just four triples \((a,b,d)\) with the required sign and coprimality, across all 60 divisors. They are \((5,2,75)\), \((35,12,325)\), \((25,9,2600)\), and \((15,7,5200)\). In each triple, \(0<25b-a<d\), which rules out every positive integer \(g\).

## Reproduction

The Lean modules were checked with Lean 4.33.1 and mathlib commit `0df444a360eaa60ab8c11dca51a86af692955474`. The final axiom audit is in `logs/lean.log`. Run the following from the unpacked directory with a built checkout of that mathlib revision.

```sh
bash verify.sh /path/to/mathlib
cd numerics
python verify_numbers.py --heights --bands
g++ -O3 -std=c++17 ratio_search.cpp -lgmpxx -lgmp -o ratio-search
./ratio-search 3 60 160
./ratio-search 61 100 160
gp -q -f -s 256M length3.gp
gp -q -f -s 128M genus5.gp
g++ -O3 -std=c++17 replay_windows.cpp -lgmpxx -lgmp -o replay-windows
gzip -dc window-certificate.txt.gz | ./replay-windows
```

The Python verifier needs SymPy. GMP and a C++17 compiler are used for the rational-approximation search. The decimal approximation in the band builder only selects rational slopes. The actual verifier uses integer arithmetic. `numerics/continued-fractions.md` gives the completeness argument for the C++ program. The bounded rational-point search on the quintic's associated curve does not enumerate the unrestricted rational points.

## Sources and attribution

* [LeftToSolve problem](https://lefttosolve.com/p/Erdos686.erdos_686.variants.twenty_five) and [research notes credited by handle](https://lefttosolve.com/api/desk/board?problem=Erdos686.erdos_686.variants.twenty_five).
* [Erdős Problems, problem 686](https://www.erdosproblems.com/686) and [formal-conjectures statement](https://github.com/google-deepmind/formal-conjectures/blob/main/FormalConjectures/ErdosProblems/686.lean).
* [Conjectures.io contributions](https://conjectures.io/problems/erdos686-erdos-686-variants-twenty-five) lists earlier proofs for lengths 2, 4, 8, 10, and 12. The present modules rederive those cases as part of the interval of lengths. On LeftToSolve, rleshner independently reported length 16, an even-length computation through 128, and a separate reproduction of the length-three Thue calculation. Their results are distinguished from the runs packaged here.
* [Dujella and Ibrahimpašić, On Worley's theorem in Diophantine approximations](https://emis.de/ft/38763) and [PARI/GP documentation for thueinit](https://pari.math.u-bordeaux.fr/dochtml/html/Polynomials_and_power_series.html#thueinit).

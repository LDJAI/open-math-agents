import FiveResult
import ThreeFactors
namespace Ratio25.FiveGap
open Erdos677PrimePower Erdos677Valuation Erdos677TransportSecond
def form (n d i : ℕ) := 24*(n+1+i)-d
abbrev C : ℕ := 7962624
private theorem weighted_dvd {n k d i A B q : ℕ} (hsep : k≤d) (hk : 2≤k)
    (hi : i<k) (ha : 0<A) (he : A*P (n+d) k=B*P n k)
    (hqd : q ∣ d) (hqi : q ∣ n+1+i) :
    q^2 ∣ (edgeWeight k i).natAbs * (B*(n+1+i)-A*(n+d+1+i)) := by
  have hs : n+k≤n+d := by omega
  have hqj : q ∣ n+d+1+i := by
    simpa [Nat.add_assoc,Nat.add_left_comm,Nat.add_comm] using Nat.dvd_add hqd hqi
  have hz := ascFactorial_square_transport (q:=(q:ℤ)) hi hi (by exact_mod_cast hqi)
    (by exact_mod_cast hqj : (q:ℤ) ∣ ((n+d:ℕ):ℤ)+1+(i:ℤ)) he
  have hlt := cross_scaled_entry_lt hs hk hi hi ha he
  let E := B*(n+1+i)-A*(n+d+1+i)
  have hsub : (B:ℤ)*edgeWeight k i*((n:ℤ)+1+i) - (A:ℤ)*edgeWeight k i*((↑(n+d):ℤ)+1+i) = edgeWeight k i*(E:ℤ) := by
    dsimp [E]
    rw [Nat.cast_sub hlt.le]
    push_cast
    ring
  rw [hsub] at hz
  obtain ⟨z,hz⟩ := hz
  have hdiv : q^2 ∣ (edgeWeight k i).natAbs*E := by
    exact ⟨z.natAbs,by simpa only [Int.natAbs_mul,Int.natAbs_natCast,Int.natAbs_pow] using congrArg Int.natAbs hz⟩
  exact hdiv
private theorem split_dvd {p e c L : ℕ} (hp : p.Prime) (hc : 0<c) (hL : 0<L)
    (hd : p^e ∣ c*L) : ∃ f≤e, p^f ∣ L ∧ p^e ∣ c*p^f := by
  let f := min e (L.factorization p)
  have hf : f≤e := min_le_left _ _
  have he' := (hp.pow_dvd_iff_le_factorization (Nat.mul_pos hc hL).ne').mp hd
  rw [Nat.factorization_mul hc.ne' hL.ne', Finsupp.add_apply] at he'
  have hcf : p^(e-f) ∣ c := (hp.pow_dvd_iff_le_factorization hc.ne').mpr (by dsimp [f]; omega)
  refine ⟨f,hf,(hp.pow_dvd_iff_le_factorization hL.ne').mpr (min_le_right _ _),?_⟩
  rw [show p^e=p^(e-f)*p^f by rw [←pow_add,Nat.sub_add_cancel hf]]
  exact Nat.mul_dvd_mul_right hcf _


theorem component {n d p e : ℕ} (hs : 5≤d) (he : block (n+d) 5=25*block n 5)
    (hp : p.Prime) (hd : p^e∣d) : ∃ i<5, (p^e)^2 ∣ C*form n d i := by
  have he' : 1*P (n+d) 5=25*P n 5 := by simpa [block,P] using he
  have u := (gap_dvd_difference_product (by decide : 2≤5) hs (by decide) he').2
  have h0 := Erdos677UpperBound.product_dvd_factorial_mul_L n 5 (by decide)
  have h1 : P n 5 ∣ 24*M n 5 := h0
  have hg : p^e ∣ 576*M n 5 := by
    have h := (hd.trans u).trans (Nat.mul_dvd_mul_left 24 h1)
    simpa [←Nat.mul_assoc] using h
  obtain ⟨f,hf,hm,hc⟩ := split_dvd hp (by decide : 0<576) (Nat.pos_of_ne_zero (M_ne_zero n 5)) hg
  obtain ⟨i,hi,own⟩ := owner (by decide : 0<5) hp hm
  have w := weighted_dvd hs (by decide : 2≤5) hi (by decide) he' ((pow_dvd_pow p hf).trans hd) own
  have ed : (edgeWeight 5 i).natAbs ∣ 24 := by interval_cases i <;> decide +kernel
  have eq : 25*(n+1+i)-1*(n+d+1+i)=form n d i := by unfold form;omega
  rw [eq] at w
  have w' := w.trans (Nat.mul_dvd_mul_right ed (form n d i))
  refine ⟨i,hi,?_⟩
  have hh := (pow_dvd_pow_of_dvd hc 2)
  rw [mul_pow] at hh
  apply Nat.dvd_trans hh
  change (576^2*(p^f)^2) ∣ (576^2*24)*form n d i
  rw [Nat.mul_assoc]
  exact Nat.mul_dvd_mul_left _ w'

abbrev B : ℕ := 1000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
abbrev A : ℕ := 1903653938715878489896147288119097778655062586108560552582361686972118263444605786944196225842223049985241176146626278766029031786996359629179500117799045948104
abbrev S : ℕ := 100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
abbrev lo : ℕ := 20351542950305175166741615083191459740126588484408128491993574990520328385811737990245656805247533879581890974951189930617225855046757355537070036950265705
abbrev hi : ℕ := 20351542950305175166741615083191459740126588484408128491993574990520328385811737990245656805247533879581890974951189930617225855046757355537070036950265710
abbrev z : ℕ := 41418530045811627
private theorem ratio_bounds {n d : ℕ} (he : block (n+d) 5=25*block n 5) :
    A*(n+1)<B*(n+d+5) ∧ B*(n+d+1)<(A+1)*(n+5) := by
  have l (x : ℕ) : (x+1)^5≤block x 5 := Nat.pow_succ_le_ascFactorial _ _
  have u (x : ℕ) : block x 5≤(x+5)^5 := Nat.ascFactorial_le_pow_add _ _
  have f : A^5<25*B^5 := by decide +kernel
  have g : 25*B^5<(A+1)^5 := by decide +kernel
  constructor
  · apply (Nat.pow_lt_pow_iff_left (by decide : 5≠0)).mp
    rw [mul_pow,mul_pow]
    calc A^5*(n+1)^5 < (25*B^5)*(n+1)^5 := Nat.mul_lt_mul_of_pos_right f (by positivity)
         _ = B^5*(25*(n+1)^5) := by ring
         _ ≤ _ := Nat.mul_le_mul_left _ ((Nat.mul_le_mul_left 25 (l n)).trans (he ▸ u (n+d)))
  · apply (Nat.pow_lt_pow_iff_left (by decide : 5≠0)).mp
    rw [mul_pow,mul_pow]
    calc B^5*(n+d+1)^5 ≤ B^5*(25*(n+5)^5) := Nat.mul_le_mul_left _ ((l (n+d)).trans (he.symm ▸ Nat.mul_le_mul_left 25 (u n)))
         _ = (25*B^5)*(n+5)^5 := by ring
         _ < _ := Nat.mul_lt_mul_of_pos_right g (by positivity)

theorem strip {n d i : ℕ} (hs : 5≤d) (he : block (n+d) 5=25*block n 5) (hi' : i<5) :
    lo*d < S*(C*form n d i) ∧ S*(C*form n d i)<hi*d := by
  have big : 10^160<n := by
    by_contra! h
    exact Five.height _ _ h (by omega) he
  have dn := length5_lower_start he
  obtain ⟨a,b⟩ := ratio_bounds he
  dsimp [A,B] at a b
  unfold form
  dsimp [lo,S,C,hi]
  omega

theorem two_prime_powers {n d p q e f : ℕ} (hs : 5≤d) (hp : p.Prime) (hq : q.Prime)
    (dt : d=p^e*q^f) : block (n+d) 5 ≠ 25*block n 5 := by
  intro he
  obtain ⟨i,hi',wi⟩ := component hs he hp (show p^e∣d from ⟨_,dt⟩)
  obtain ⟨j,hj',wj⟩ := component hs he hq (show q^f∣d from ⟨_,by rw [dt,Nat.mul_comm]⟩)
  let x := C*form n d i
  let y := C*form n d j
  have dvd : d^2 ∣ x*y := by rw [dt,mul_pow];exact Nat.mul_dvd_mul wi wj
  obtain ⟨u,hu⟩ := dvd
  obtain ⟨li,ui⟩ : lo*d<S*x ∧ S*x<hi*d := strip hs he hi'
  obtain ⟨lj,uj⟩ : lo*d<S*y ∧ S*y<hi*d := strip hs he hj'
  have l := Nat.mul_lt_mul_of_lt_of_lt li lj
  have h := Nat.mul_lt_mul_of_lt_of_lt ui uj
  have eq : (S*x)*(S*y)=(S^2*d^2)*u := by rw [show (S*x)*(S*y)=S^2*(x*y) by ring,hu];ring
  rw [eq,show lo*d*(lo*d)=lo^2*d^2 by ring] at l
  rw [eq,show hi*d*(hi*d)=hi^2*d^2 by ring] at h
  have lz : z*S^2<lo^2 := by decide +kernel
  have uz : hi^2<(z+1)*S^2 := by decide +kernel
  have a := (Nat.mul_le_mul_right (d^2) lz.le).trans_lt l
  have b := h.trans_le (Nat.mul_le_mul_right (d^2) uz.le)
  have a' : z<u := Nat.lt_of_mul_lt_mul_right (show z*(S^2*d^2)<u*(S^2*d^2) by simpa only [Nat.mul_assoc,Nat.mul_comm,Nat.mul_left_comm] using a)
  have b' : u<z+1 := Nat.lt_of_mul_lt_mul_right (show u*(S^2*d^2)<(z+1)*(S^2*d^2) by simpa only [Nat.mul_assoc,Nat.mul_comm,Nat.mul_left_comm] using b)
  omega

#print axioms two_prime_powers

abbrev al : ℕ := 34047401888188478058202073235091255571528383205361949618265373289224199094489368833
abbrev bl : ℕ := 822033081582803756028477252640001244855424114634480237407700517763
abbrev ar : ℕ := 14814750261071051494859067469218288350698147550421224057081955265476894334479498139
abbrev br : ℕ := 357684114928389783794750429293129256759628291868715234030236778832

/-- Adjacent fractions with determinant one bound the denominator of every
strictly intermediate fraction, even when the latter is unreduced. -/
private theorem farey {a b c d u v : ℕ} (det : b*c=a*d+1)
    (l : a*v<b*u) (h : d*u<c*v) : b+d≤v := by
  have l' := Nat.mul_le_mul_left d (show a*v+1≤b*u by omega)
  have h' := Nat.mul_le_mul_left b (show d*u+1≤c*v by omega)
  have id := congrArg (·*v) det
  nlinarith only [l',h',id]

/-- Two arbitrary prime powers times a small cofactor cannot form a quintic gap. -/
theorem two_powers_cofactor {n d p q e f t : ℕ} (hs : 5≤d) (hp : p.Prime) (hq : q.Prime)
    (dt : d=(p^e*q^f)*t) (ht : t≤10^33) : block (n+d) 5 ≠ 25*block n 5 := by
  intro he
  let Q := p^e*q^f
  have dQ : d=Q*t := dt
  have pd : p^e∣d := ⟨q^f*t,by rw [dt,Nat.mul_assoc]⟩
  have qd : q^f∣d := ⟨p^e*t,by rw [dt];ac_rfl⟩
  obtain ⟨i,ui,wi⟩ := component hs he hp pd
  obtain ⟨j,uj,wj⟩ := component hs he hq qd
  let x := C*form n d i
  let y := C*form n d j
  have dvd : Q^2∣x*y := by dsimp [Q];rw [mul_pow];exact Nat.mul_dvd_mul wi wj
  obtain ⟨u,hu⟩ := dvd
  obtain ⟨li,hi'⟩ : lo*d<S*x ∧ S*x<hi*d := strip hs he ui
  obtain ⟨lj,hj'⟩ : lo*d<S*y ∧ S*y<hi*d := strip hs he uj
  have ll := Nat.mul_lt_mul_of_lt_of_lt li lj
  have rr := Nat.mul_lt_mul_of_lt_of_lt hi' hj'
  have eq : S*x*(S*y)=S^2*(Q^2*u) := by rw [←hu];ring
  rw [eq,show lo*d*(lo*d)=lo^2*(Q^2*t^2) by rw [dQ];ring] at ll
  rw [eq,show hi*d*(hi*d)=hi^2*(Q^2*t^2) by rw [dQ];ring] at rr
  have low : lo^2*t^2<S^2*u := Nat.lt_of_mul_lt_mul_right (a:=Q^2)
    (by simpa only [Nat.mul_comm,Nat.mul_left_comm,Nat.mul_assoc] using ll)
  have high : S^2*u<hi^2*t^2 := Nat.lt_of_mul_lt_mul_right (a:=Q^2)
    (by simpa only [Nat.mul_comm,Nat.mul_left_comm,Nat.mul_assoc] using rr)
  have l₁ := Nat.mul_le_mul_right (t^2) (show al*S^2≤bl*lo^2 by decide +kernel)
  rw [Nat.mul_assoc bl] at l₁
  have l := l₁.trans_lt (Nat.mul_lt_mul_of_pos_left low (by decide +kernel : 0<bl))
  have h₁ := Nat.mul_le_mul_right (t^2) (show br*hi^2≤ar*S^2 by decide +kernel)
  rw [Nat.mul_assoc br] at h₁
  have h := (Nat.mul_lt_mul_of_pos_left high (by decide +kernel : 0<br)).trans_le h₁
  have la : al*t^2<bl*u := Nat.lt_of_mul_lt_mul_right (a:=S^2)
    (by simpa only [Nat.mul_comm,Nat.mul_left_comm,Nat.mul_assoc] using l)
  have ha : br*u<ar*t^2 := Nat.lt_of_mul_lt_mul_right (a:=S^2)
    (by simpa only [Nat.mul_comm,Nat.mul_left_comm,Nat.mul_assoc] using h)
  have impossible := farey (show bl*ar=al*br+1 by decide +kernel) la ha
  exact (not_le_of_gt (show (10^33)^2<bl+br by decide +kernel)) (impossible.trans (Nat.pow_le_pow_left ht 2))

#print axioms two_powers_cofactor
end Ratio25.FiveGap

import FiveCertificates
import Mathlib.Tactic.LinearCombination
namespace Ratio25.FiveEffective
open Ratio25.FiveGap

private theorem hom (a x y : ℤ) : G (a*x) (a*y) = a^5*G x y := by unfold G;ring

/-- At any specified cofactor, only finitely many starts, gaps and prime powers can occur. -/
theorem effective {n d p q e f t : ℕ} (hs : 5≤d) (hp : p.Prime) (hq : q.Prime)
    (dt : d=(p^e*q^f)*t) (he : block (n+d) 5=25*block n 5) :
    d < 10^92*t^10 ∧ n<2*d := by
  have hn := length5_lower_start he
  refine ⟨?_,hn⟩
  let K := p^e*q^f
  let V := C^2*t^2
  have ht : 0<t := by
    by_contra! ht
    have ht' : t=0 := by omega
    simp [ht'] at dt
    omega
  have posV : 0<V := by dsimp [V,C];positivity
  obtain ⟨i,hi,wi⟩ := component hs he hp (show p^e∣d from ⟨q^f*t,by rw [dt,Nat.mul_assoc]⟩)
  obtain ⟨j,hj,wj⟩ := component hs he hq (show q^f∣d from ⟨p^e*t,by rw [dt];ac_rfl⟩)
  let W := form n d i * form n d j
  have dvd : K^2 ∣ (C*form n d i)*(C*form n d j) := by
    dsimp [K];rw [mul_pow];exact Nat.mul_dvd_mul wi wj
  obtain ⟨z,hz⟩ := dvd
  have zz : V*W=d^2*z := calc
    _ = t^2*((C*form n d i)*(C*form n d j)) := by dsimp [V,W];ring
    _ = _ := by rw [hz,dt];dsimp [K];ring
  have low (l : ℕ) (hl : l<5) : d≤24*(n+1+l) := by
    have ee : 1*Erdos677Valuation.P (n+d) 5=25*Erdos677Valuation.P n 5 := by simpa [block,Erdos677Valuation.P] using he
    have hh := Erdos677TransportSecond.cross_scaled_entry_lt (by omega : n+5≤n+d) (by decide : 2≤5) hl hl (by decide) ee
    omega
  have li (l : ℕ) (hl : l<5) : (form n d l : ℤ)=lin n d l := by
    unfold form lin
    rw [Nat.cast_sub (low l hl)]
    push_cast;ring
  have eq : equation n d=0 := by
    have e := congrArg (fun t : ℕ => (t:ℤ)) he
    simp [block,Nat.ascFactorial] at e
    unfold equation
    linear_combination e
  have hB := uniform hn.le (by omega : 1≤d) hi hj
  have hw : (W:ℤ)=lin n d i*lin n d j := by dsimp [W];rw [li i hi,li j hj]
  simp only [residual,eq,mul_zero,sub_zero,←hw] at hB
  have zz' : (V:ℤ)*W=(d:ℤ)^2*z := by exact_mod_cast zz
  have id : ((d:ℤ)^2)^5*G z V=(V:ℤ)^5*G W ((d:ℤ)^2) := by
    rw [←hom,←hom,←zz',mul_comm ((d:ℤ)^2) (V:ℤ)]
  have ab := congrArg Int.natAbs id
  simp only [Int.natAbs_mul,Int.natAbs_pow,Int.natAbs_natCast] at ab
  have non := nonzero z V posV
  have nz : 0<(G z V).natAbs := by omega
  have h1 : (d^2)^5≤ V^5*(G W ((d:ℤ)^2)).natAbs := ab ▸ Nat.le_mul_of_pos_right _ nz
  have bound := h1.trans (Nat.mul_le_mul_left (V^5) hB)
  have h2 : d≤(2*10^22)*V^5 := Nat.le_of_mul_le_mul_right
    (show d*d^9≤((2*10^22)*V^5)*d^9 by simpa only [show (d^2)^5=d*d^9 by ring, Nat.mul_left_comm, Nat.mul_comm, Nat.mul_assoc] using bound) (by positivity : 0<d^9)
  calc d ≤ (2*10^22)*V^5 := h2
       _ = ((2*10^22)*C^10)*t^10 := by dsimp [V];ring
       _ < _ := Nat.mul_lt_mul_of_pos_right (by decide +kernel) (by positivity)

#print axioms effective
end Ratio25.FiveEffective

import FiveGap
import Mathlib.Data.ZMod.Basic
namespace Ratio25.FiveEffective
open Ratio25.FiveGap

def G (x y : ℤ) : ℤ := x^5-500*x^4*y-100250*x^3*y^2-1562500*x^2*y^3+1332190625*x*y^4-165567610000*y^5

theorem nonzero (x y : ℕ) (hy : 0<y) : G x y ≠ 0 := by
  induction y using Nat.strong_induction_on generalizing x with
  | h y ih =>
    intro eq
    have hh : ∀ a b : ZMod 11, a^5-500*a^4*b-100250*a^3*b^2-1562500*a^2*b^3+1332190625*a*b^4-165567610000*b^5=0 → a=0 ∧ b=0 := by decide +kernel
    have cast := congrArg (Int.castRingHom (ZMod 11)) eq
    simp [G] at cast
    obtain ⟨hx,hy'⟩ := hh (x:ZMod 11) (y:ZMod 11) cast
    obtain ⟨x',xx⟩ := (ZMod.natCast_eq_zero_iff x 11).mp hx
    obtain ⟨y',yy⟩ := (ZMod.natCast_eq_zero_iff y 11).mp hy'
    have pos : 0<y' := by omega
    have smaller := ih y' (by omega) x' pos
    apply smaller
    subst x y
    push_cast at eq
    have hmul : G (11*(x':ℤ)) (11*(y':ℤ)) = 11^5*G x' y' := by unfold G;ring
    rw [hmul] at eq
    omega

abbrev Term := ℕ × ℕ × ℤ
def val (n d : ℕ) (l : List Term) : ℤ :=
  match l with
  | [] => 0
  | (a,b,c)::r => c*(n:ℤ)^a*(d:ℤ)^b+val n d r
def cost (l : List Term) : ℕ :=
  match l with
  | [] => 0
  | (a,_,c)::r => c.natAbs*2^a+cost r
def small (l : List Term) : Bool := l.all (fun v => decide (v.1+v.2.1≤9))
theorem estimate (l : List Term) {n d : ℕ} (hn : n≤2*d) (hd : 1≤d) (h : small l) :
    (val n d l).natAbs ≤ cost l*d^9 := by
  induction l with
  | nil => simp [val,cost]
  | cons entry tail ih =>
    obtain ⟨a,b,c⟩ := entry
    simp [small] at h
    have hc : a+b≤9 := h.1
    have ht := ih (by simpa [small] using h.2)
    have hterm : c.natAbs*n^a*d^b≤(c.natAbs*2^a)*d^9 := calc
      _ ≤ c.natAbs*(2*d)^a*d^b := Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hn _))
      _ = (c.natAbs*2^a)*d^(a+b) := by rw [pow_add,mul_pow];ring
      _ ≤ _ := Nat.mul_le_mul_left _ (Nat.pow_le_pow_right hd hc)
    change Int.natAbs (c*(n:ℤ)^a*(d:ℤ)^b+val n d tail)≤(c.natAbs*2^a+cost tail)*d^9
    rw [Nat.add_mul]
    exact (Int.natAbs_add_le _ _).trans (Nat.add_le_add (by simpa only [Int.natAbs_mul,Int.natAbs_pow,Int.natAbs_natCast] using hterm) ht)

def Q (n d : ℤ) : ℤ := let v := d-24*n; 331776*(v^5-250*v^3*d^2-6500*v^2*d^3-81375*v*d^4-406900*d^5)
def equation (n d : ℤ) := (n+d+1)*(n+d+2)*(n+d+3)*(n+d+4)*(n+d+5)-25*(n+1)*(n+2)*(n+3)*(n+4)*(n+5)
def lin (n d i : ℤ) := 24*(n+1+i)-d
def residual (i j n d : ℤ) := G ((lin n d i)*(lin n d j)) (d^2) - Q n d*equation n d

end Ratio25.FiveEffective

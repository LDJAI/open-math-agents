from pathlib import Path
import sympy as s
r=Path(__file__).parent
n,d=s.symbols('n d')
def poly(e):return s.Poly(e,n,d)
def G(x,y):return x**5-500*x**4*y-100250*x**3*y**2-1562500*x**2*y**3+1332190625*x*y**4-165567610000*y**5
def H(v,y):return v**5-250*v**3*y**2-6500*v**2*y**3-81375*v*y**4-406900*y**5
Q=331776*H(poly(d-24*n),poly(d))
eq=poly(s.prod(n+d+i for i in range(1,6))-25*s.prod(n+i for i in range(1,6)))
out=['import FiveEffective','namespace Ratio25.FiveEffective','set_option maxRecDepth 10000','set_option maxHeartbeats 0']
mx=0
for i in range(5):
 for j in range(i,5):
  E=G(poly((24*(n+i+1)-d)*(24*(n+j+1)-d)),poly(d*d))-Q*eq
  assert E.total_degree()<=9
  L=E.terms();cost=sum(abs(c)*2**a for (a,b),c in L);mx=max(mx,cost)
  t=', '.join(f'({a},{b},{c})' for (a,b),c in L)
  out.append(f'''private def t{i}{j} : List Term := [{t}]
private theorem b{i}{j} {{n d : ℕ}} (hn : n≤2*d) (hd : 1≤d) : (residual {i} {j} n d).natAbs≤(2*10^22)*d^9 := by
  have id : residual {i} {j} n d=val n d t{i}{j} := by simp only [residual,lin,equation,Q,G,val,t{i}{j}];ring
  rw [id]
  exact (estimate t{i}{j} hn hd (by decide +kernel)).trans (Nat.mul_le_mul_right _ (by decide +kernel))''')
out.append('''theorem uniform {n d i j : ℕ} (hn : n≤2*d) (hd : 1≤d) (hi : i<5) (hj : j<5) :
    (residual i j n d).natAbs≤(2*10^22)*d^9 := by
  have symm (a b : ℤ) : residual a b n d=residual b a n d := by unfold residual;rw [mul_comm (lin _ _ a) (lin _ _ b)]
  interval_cases i <;> interval_cases j''')
for i in range(5):
 for j in range(5):out.append('  · '+('rw [symm]\n    ' if i>j else '')+f'exact b{min(i,j)}{max(i,j)} hn hd')
out.append('end Ratio25.FiveEffective')
(r/'FiveCertificates.lean').write_text('\n'.join(out)+'\n')
print('maximum coefficient bound',mx)

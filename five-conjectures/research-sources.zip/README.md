# Five conjectures in voting, allocation and networks

LDJAI research notes with OpenAI Codex, November 26, 2026.

| Investigation | Status and source files |
|:--|:--|
| Voting | Full counterexample to the 2016 all-trees conjecture using three ballots. Eight candidates are necessary for the Banks-tree reversal. [Proof and conditional counts](voting/README.md) |
| Local auctions | A 2011 price rule answers the 2013 feasibility question in the original equal-value-per-buyer model, with a tight 1/k welfare guarantee. The local computation uses indexed demand lists from both sides. [Proof, earlier mechanism and input assumptions](auction/auction.md) |
| Mixed cake | Four queries suffice for two people, and a [public scalar-query construction for arbitrary group sizes](cake/scalar-protocol.md) answers the question in the normalized signed model. The all-population proof is a research manuscript for independent review. [Four-query construction and the public-history issue](cake/README.md), [direct-revelation proofs](cake-alt/direct-revelation.md), and [the sealed-batch construction for arbitrary group sizes](cake/BATCHED.md) |
| Network creation | Obstructions to two families of network blocks, and exact examples where every single-edge test passes and a multi-edge change succeeds. The proposed Nash equilibrium remains unresolved. [Structural proofs](network/README.md) and [greedy-equilibrium checks](net-alt/README.md) |
| Exact Steiner trees | A transfer of fixed-level Vertex Cover relaxation gaps to a Steiner flow formulation. General polynomial-time exactness and P versus NP remain open. [Proof and construction](steiner/README.md) |

## Reproduce

Run these commands from the directory containing this index. The Python checks below use the standard library. The voting minimum-size check also requires a C++20 compiler.

```sh
python3 voting/verify_banks.py
c++ -std=c++20 -O2 voting/verify_minimum.cpp -o /tmp/banks-minimum
/tmp/banks-minimum
python3 auction/verify.py
python3 cake/check.py
python3 network/verify.py
python3 net-alt/verify_greedy.py
python3 steiner/verify_steiner.py 0 1 2 3 4 5
```

The voting certificate uses Lean 4.33.1 and its standard library. The auction certificate imports Mathlib. With that toolchain and Mathlib on the Lean path, run `lean voting/BanksVoting.lean` and `lean auction/LocalAuction.lean`. The voting file prints the axiom audit. The notes specify the mathematical scope of each certificate. The optional search scripts in net-alt use SciPy and NumPy. Their floating-point results are distinct from the independently verified exact examples.

References to the proposing papers and the relevant earlier theorems are in the individual notes. [GitHub branch](https://github.com/LDJAI/open-math-agents/tree/five-conjectures-2026-11-26/five-conjectures) · [Left to Solve complexity target](https://lefttosolve.com/p/ComplexityTheory.P_ne_NP)

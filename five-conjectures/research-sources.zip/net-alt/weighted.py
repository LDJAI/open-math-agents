"""Weighted single-edge swap test for the sum network creation game."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'network'))
from screen import theta, cycle, make, complete, complete_bip, subdivide, all_edges, swap_rows, dis, plane
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import csr_matrix
from itertools import combinations, combinations_with_replacement
import json

def solve(A,limit=5):
 n=len(A); edges=list(all_edges(A)); m=len(edges); size=n+m+1
 D,changes=swap_rows(A)
 R=[];L=[];U=[]
 def row(w,low,high):
  R.append(w);L.append(low);U.append(high)
 row(np.r_[np.ones(n),np.zeros(m+1)],1,1)
 for i in range(n):
  v=np.zeros(size);v[i]=1;v[-1]=-1;row(v,0,np.inf)
 for e,(u,v) in enumerate(edges):
  for direction,(x,y) in enumerate([(u,v),(v,u)]):
   for delta in changes[x,y][1]:
    M=max(0,-delta.min())
    if M==0:continue
    co=np.zeros(size);co[:n]=delta
    if direction==0:
     co[n+e]=-M;row(co,-M,np.inf)
    else:
     co[n+e]=M;row(co,0,np.inf)
 c=np.zeros(size);c[-1]=-1
 result=milp(c,integrality=np.r_[np.zeros(n),np.ones(m),0],bounds=Bounds(0,1),constraints=LinearConstraint(csr_matrix(np.array(R)),L,U),options={'time_limit':limit,'mip_rel_gap':1e-7})
 if result.x is None:
  return result.status,0,None
 x=result.x
 opts={'w':x[:n].tolist(),'owners':[int(u if x[n+e]>0.5 else v) for e,(u,v) in enumerate(edges)],'edges':[[int(u),int(v)] for u,v in edges]}
 return result.status,x[-1],opts

def vary(base,lengths):
 n=len(base);out=[]
 for (u,v),le in zip(all_edges(base),lengths):
  p=[u,*range(n,n+le-1),v];n+=le-1;out+=list(zip(p[:-1],p[1:]))
 return make(n,out)

def cand():
 for n in range(6,13):yield f'cycle-{n}',cycle(n)
 for ps in combinations_with_replacement(range(1,7),3):
  if ps[0]+ps[1]>=6 and sum(ps)<=16:yield f'theta-{ps}',theta(ps)
 for ps in combinations_with_replacement(range(2,5),4):
  if ps[0]+ps[1]>=6 and sum(ps)<=16:yield f'theta-{ps}',theta(ps)
 # A weighted subdivision of the four-vertex complete graph, listed only up to vertex permutations.
 import itertools
 edges=list(all_edges(complete(4)))
 pidx=[tuple(edges.index(tuple(sorted([p[i],p[j]]))) for i,j in edges) for p in itertools.permutations(range(4))]
 for ls in itertools.product([1,2,3],repeat=6):
  if min(tuple(ls[ix] for ix in p) for p in pidx)!=ls:continue
  if any(sum(ls[edges.index(edge)] for edge in combinations(t,2))<6 for t in combinations(range(4),3)):continue
  if any(sum(ls[edges.index(tuple(sorted([p[k],p[(k+1)%4]])))] for k in range(4))<6 for p in itertools.permutations(range(4))):continue
  yield f'K4-{ls}',vary(complete(4),ls)

if __name__=='__main__':
 for name,A in cand():
  s,t,info=solve(A)
  print(name,s,'min_weight=',round(t,8),flush=True)
  if t>1e-6:
   slug=name.translate(str.maketrans(' (),','____')); Path(__file__).with_name(slug+'.json').write_text(json.dumps(info))

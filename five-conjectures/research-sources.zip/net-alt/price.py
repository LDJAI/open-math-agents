from weighted import *
from scipy.optimize import linprog
from functools import lru_cache

def priced(A, label, seconds=20):
 n=len(A); E=list(all_edges(A)); m=len(E);size=n+m+2
 D,ch=swap_rows(A); rows=[];lo=[];hi=[]
 def put(w,lb,ub=np.inf):
  rows.append(w);lo.append(lb);hi.append(ub)
 def addrow(delta,k,orient):
  # sum weights =1, thus a deletion can cost at most n in a cyclic block.
  big=max(0,-min(delta)-min(0,k*n))
  if big==0:return
  v=np.zeros(size);v[:n]=delta;v[-2]=k
  if orient is None:put(v,0);return
  e,flag=orient
  if flag==0: v[n+e]=-big;put(v,-big)
  else: v[n+e]=big;put(v,0)
 put(np.r_[np.ones(n),np.zeros(m+2)],1,1)
 for u in range(n):
  v=np.zeros(size);v[u]=1;v[-1]=-1;put(v,0)
 eye=np.eye(n,dtype=int)
 infos=[]
 for u in range(n):
  H=A.copy();H[u,:]=H[:,u]=0;D0=dis(H)
  nbs=frozenset(np.where(A[u])[0]);Dbase=D[u]
  possible=set(range(n))-{u}
  def calc(N):
   a=(1+D0[list(N)]).min(axis=0)-Dbase if N else np.full(n,4*n)
   a[u]=0; return a
  for z in possible-nbs:addrow(calc(nbs|{z}),1,None)
  for y in nbs:
   e=E.index(tuple(sorted((u,y))));orient=(e,int(y<u))
   if len(nbs)>1:addrow(calc(nbs-{y}),-1,orient)
   for z in possible-nbs:addrow(calc((nbs-{y})|{z}),0,orient)
  infos.append((D0,nbs))
 c=np.zeros(size);c[-1]=-1
 bounds=Bounds(0,np.r_[np.ones(n+m),n,1])
 # Iteratively separate more general deviations at each candidate optimum.
 for count in range(50):
  sol=milp(c,integrality=np.r_[np.zeros(n),np.ones(m),0,0],bounds=bounds,constraints=LinearConstraint(csr_matrix(np.array(rows)),lo,hi),options={'time_limit':seconds,'mip_rel_gap':1e-8})
  if sol.x is None or sol.x[-1]<1e-9:return sol.status,0,None
  x=sol.x;alpha=x[-2];w=x[:n];bits=x[n:n+m]>0.5
  new=0
  for u,(D0,nbs) in enumerate(infos):
   edgeids=[E.index(tuple(sorted((u,y)))) for y in nbs]
   held=frozenset(y for y,e in zip(nbs,edgeids) if bits[e]==(u<y))
   free=nbs-held; poss=sorted(set(range(n))-{u}-free)
   worst=[]
   for k in range(min(len(held)+2,len(poss))+1):
    for T in combinations(poss,k):
     N=free|set(T)
     if not N:continue
     a=(1+D0[list(N)]).min(axis=0)-D[u];a[u]=0
     diff=k-len(held);delta=a@w+diff*alpha
     if delta< -1e-7:worst.append((delta,diff,a))
   worst.sort(key=lambda z:z[0])
   for violation,diff,a in worst[:10]:
    M=max(0,-min(a)-min(0,diff*n))
    v=np.zeros(size);v[:n]=a;v[-2]=diff;lb=0
    for e in edgeids:
     if bits[e]:
      v[n+e]-=M;lb-=M
     else:v[n+e]+=M
    put(v,lb);new+=1
  if not new:
   info={'w':w.tolist(),'price':float(alpha),'edges':[[int(i),int(j)] for i,j in E],'owners':[int(i if x[n+e]>.5 else j) for e,(i,j) in enumerate(E)]}
   return sol.status,x[-1],info
 return 'iteration_limit',0,None

if __name__=='__main__':
 for name,A in cand():
  if not name.startswith('theta'):continue
  slug=name.translate(str.maketrans(' (),','____'))
  if not Path(__file__).with_name(slug+'.json').exists():continue
  code,t,info=priced(A,name)
  print(name,code,t,info,flush=True)

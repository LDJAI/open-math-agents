"""Add a short ear to weighted theta cores and repeat the necessary priced tests."""
from weighted import *
from price import priced

def stream():
 # Attach a new ear with two to four edges. Both endpoints must have belonged to the core.
 for ps in [(3,3,4),(4,4,4),(2,4,4),(3,4,4)]:
  A=theta(ps); n=len(A);D=dis(A);E=list(all_edges(A))
  seen=set()
  for z in [2,3,4]:
   for u,v in combinations(range(n),2):
    if D[u,v]+z<6:continue
    internal=list(range(n,n+z-1));p=[u,*internal,v]
    H=make(n+z-1,[*E,*zip(p[:-1],p[1:])])
    # Dedup via a distance signature. Skips possible colliding graphs, fine for sampling.
    Hdist=dis(H);deg=H.sum(axis=0)
    key=tuple(sorted(tuple(sorted((int(deg[w]),int(Hdist[i,w])) for w in range(len(H)))) for i in range(len(H))))
    if key in seen:continue
    seen.add(key)
    yield ps,z,u,v,H

if __name__=='__main__':
 for ps,z,u,v,H in stream():
  s,t,info=solve(H,1)
  if s==1 and t<1e-6:t='unknown'
  if t!='unknown' and t>1e-7:
   s2,t2,info2=priced(H,'ear',4)
   print(ps,z,u,v,'swaps',t,'priced',s2,t2,info2,flush=True)
  else:print(ps,z,u,v,'swaps',t,flush=True)

from __future__ import annotations
import itertools as it
import numpy as np
from scipy.sparse.csgraph import shortest_path

def make(n,edges):
    A=np.zeros((n,n),dtype=np.int8)
    for u,v in edges:A[u,v]=A[v,u]=1
    return A

def theta(paths):
    edges=[];n=2
    for length in paths:
        path=[0]+list(range(n,n+length-1))+[1];n+=length-1
        edges+=list(zip(path[:-1],path[1:]))
    return make(n,edges)

def cycle(n):
    return make(n,[(i,(i+1)%n) for i in range(n)])

def petersen(n,k):
    return make(n*2,[(i,(i+1)%n) for i in range(n)]+[(i+n,n+(i+k)%n) for i in range(n)]+[(i,i+n) for i in range(n)])

def hamming(dim,n):
    vertices=list(it.product(range(n),repeat=dim));return make(len(vertices),[(i,j) for i,p in enumerate(vertices) for j,r in enumerate(vertices[:i]) if sum(x!=y for x,y in zip(p,r))==1])

def complete(n): return make(n,it.combinations(range(n),2))
def complete_bip(n,m): return make(n+m,it.product(range(n),range(n,n+m)))

def subdivide(A,l=2):
    n=len(A); e=[]
    for u,v in all_edges(A):
        path=[u]+list(range(n,n+l-1))+[v];n+=l-1;e+=list(zip(path[:-1],path[1:]))
    return make(n,e)

def plane(q,what='full'):
    points=[(x,y,1) for x in range(q) for y in range(q)]+[(x,1,0) for x in range(q)]+[(1,0,0)]
    return make(2*len(points),[(i,j+len(points)) for i,p in enumerate(points) for j,l in enumerate(points) if sum(x*y for x,y in zip(p,l))%q==0])

def circulant(n, offsets):
    return make(2*n,[(i,n+(i+j)%n) for i in range(n) for j in offsets])

def all_edges(A):
    return zip(*np.nonzero(np.triu(A,1)))

def dis(A):
    z=shortest_path(A,directed=False,unweighted=True);return np.where(z==np.inf,4*len(A),z).astype(np.int32)

def swap_rows(A):
    n=len(A);D=dis(A); out={}
    for u in range(n):
        H=A.copy();H[u,:]=0;H[:,u]=0;D0=dis(H);nb=np.where(A[u])[0]
        for v in nb:
            others=nb[nb!=v];baseline=np.min(D0[others,:]+1,axis=0) if len(others) else np.full(n,4*n)
            delta=np.minimum(baseline,1+D0)-D[u,None,:]
            delta[:,u]=0
            choices=np.where(~A[u].astype(bool))[0];choices=choices[choices!=u]
            out[u,v]=(choices,delta[choices,:])
    return D,out

def bare(A):
    D,rows=swap_rows(A)
    E=list(all_edges(A));valid={}
    for uv in E:
        legal=lambda i,j: rows[i,j][1].sum(axis=1).min(initial=0)>=0
        a,b=uv
        valid[uv]=[i for i,j in [(a,b),(b,a)] if legal(i,j)]
    return sum(not options for options in valid.values()),len(E),valid

if __name__=='__main__':
 for n in range(3,9):
    for A,name in [(subdivide(complete(n)),f'K{n}'),(subdivide(complete_bip(n,n)),f'K{n},{n}'),(theta([3]*n),f'theta {n}'),(subdivide(petersen(n,1)),f'prism {n}'),(subdivide(cycle(n)),f'cycle {n}')]:
        print(name,len(A),bare(A)[:2])
 for n in range(5,18):
    for k in range(2,(n+1)//2):
        A=petersen(n,k)
        if k>=3 and n//np.gcd(n,k)>=6 and n not in [2*k-1,2*k+1] and (A@A).max()<=4:
            print('GP',n,k,bare(A)[:2])

def layer_plane(q,h=2, join='star'):
    base=plane(q);N=len(base);n=N//2
    E=[(k*N+i,k*N+j) for k in range(h) for i,j in all_edges(base)]
    E += [(i+k*N,i+(k+1)*N if join=='chain' else i) for i in range(n) for k in (range(h-1) if join=='chain' else range(1,h))]
    return make(N*h,E)
